/**
 * Atelier CLI capability catalog (Tasks #332 → #339).
 *
 * Single declarative registry of every "thing the CLI knows how to do".
 * Each entry binds a Claude tool surface (name, prompts, JSON Schema)
 * to a server backing-route handler, role gates, confirmation policy,
 * and result-card hints. The orchestrator merges these entries into
 * `TOOL_REGISTRY` at process boot so the model only ever sees the
 * filtered subset the persona is allowed to call.
 *
 * Task #339 — this file is now purely **loader + types**. Catalog
 * entries are no longer hand-curated in a sibling `capability-seed.ts`;
 * instead they are *derived from code* by:
 *
 *   1. `defineRouteCapability(...)` colocates a capability declaration
 *      with the route handler that implements it.
 *   2. `registerAgentCapabilities()` walks the @workspace/agents
 *      registry and auto-registers one capability per agent.
 *
 * The orchestrator imports `bootstrap-capabilities.ts` once at boot,
 * which side-effect-loads every route + agent registration. From that
 * point on, the catalog is read-only and the orchestrator sees the
 * filtered per-persona slice.
 *
 * Schema-drift detection: every entry's input schema is hashed
 * (sha-256 of canonical JSON) at registration time and stored as
 * `schemaHash`. Saved/pinned prompts that reference an older hash
 * surface a "review before running" warning instead of silently
 * re-executing against the new shape — see `pinnedPromptDrift()`.
 */

import { createHash } from "node:crypto";
import Ajv from "ajv";
import { and, eq } from "drizzle-orm";
import { db, atelierAgentRuns, atelierWorkItems } from "@workspace/db";
import type { CliPersona, ToolContext, ToolResult } from "./index.js";
import type { AtelierRole } from "../../routes/atelier/personaRoles.js";
import { assertCapabilityDivergences } from "./capability-divergences.js";

/**
 * Module families used for routing, role-filtering, and the surface
 * grouping shown in the slash-command palette.
 */
export type CapabilityModule =
  | "raid"
  | "engagement"
  | "deliverable"
  | "account"
  | "opportunity"
  | "wallet"
  | "ledger"
  | "roster"
  | "skill_graph"
  | "knowledge"
  | "report"
  | "firm_profile"
  | "win_loss"
  | "pricing"
  | "proposal"
  | "agent"
  | "admin"
  | "meta"
  // L2C Wave 1 (Task #360) — Codex/CLM, change orders, deliverable
  // acceptance. Restricted personas (contractor, partner_firm_resource,
  // recruiter) and board_observer are denied at the catalog gate
  // regardless of `requiredRoles`. See `capabilitiesForPersona` below.
  | "codex"
  | "change_order"
  | "deliverable_acceptance"
  // L2C Wave 2 (Task #361) — Revenue recognition, WIP, engagement
  // margin, leakage. board_observer is allow-listed onto the firm-wide
  // rollup capabilities (`wip_report`, `leakage_report`,
  // `revrec_compute_schedule` read-only) via the explicit
  // `BOARD_OBSERVER_ROLLUP_ALLOWLIST` set below — never module-wide.
  | "revrec"
  | "wip"
  | "margin"
  | "leakage"
  // L2C Wave 4 (Task #363) — cash application, bank reconciliation,
  // 13-week cash forecast, renewals & NRR. board_observer is allow-listed
  // onto `cash_forecast_13w` only via BOARD_OBSERVER_ROLLUP_ALLOWLIST.
  | "cash"
  | "bank"
  | "treasury"
  | "renewal"
  // Task #1251 — vendor tooling spend (line-item mining + project cost
  // allocation). Finance-leadership read surface `finance.tooling_spend`.
  | "finance";

/**
 * Outbound side-effect channel a capability fires when it commits.
 * `null` means the capability is contained to internal DB state and
 * the undo path can fully reverse it. Non-null channels (currently
 * just "email") block undo and are surfaced in the confirmation diff
 * so the user knows the write will leave the system.
 */
export type OutboundChannel = "email";
export type CapabilityPolicyClass =
  | "authenticated_read"
  | "role_restricted_read"
  | "confirmed_write"
  | "irreversible_write"
  | "outbound_write"
  | "legacy_write"
  | "unsupported";
export type CapabilityEffectClass = "read" | "internal_write" | "outbound_write";
export interface CapabilityPresentationContract {
  cardType: ResultCard | null;
  contractVersion: 1;
  renderer: "none" | "legacy-native-v1" | "semantic-v1";
  minimumDataVersion: 1;
}

/**
 * Result-card hint the orchestrator emits alongside a successful
 * tool result so the client can pick a typed renderer instead of
 * falling back to raw JSON. New cards must be added here so a typo
 * in a catalog entry breaks the build (Task #349).
 */
export type ResultCard =
  | "account_card"
  | "account_deleted"
  | "agent_run"
  | "asset_card"
  | "audit_timeline"
  | "brand_profile_draft"
  | "capability_list"
  | "cartographer_run"
  | "charter_card"
  | "contact_card"
  | "deliverable_card"
  | "document_chunk"
  | "document_search"
  | "email_sent"
  | "entity_card"
  | "expense_batch"
  | "expense_card"
  | "kpi_strip"
  | "meeting_card"
  | "opportunity_card"
  | "pov_card"
  | "profile_update_decision"
  | "proposal_card"
  | "qualification_rubric"
  | "qualifier_card"
  | "raid_batch"
  | "raid_item"
  | "ranked_list"
  | "section_card"
  | "time_series"
  | "timesheet_card"
  // Task #745 — guided flight-booking traveller picker.
  | "traveller_picker"
  | "undo_card"
  // L2C Wave 1 (Task #360) — typed renderers for the new Codex/CLM,
  // change-order and deliverable-acceptance result shapes. The cards
  // are declared up-front (W1-S9 will land the front-end renderers);
  // any cap referencing one of these names that ships before the
  // renderer must use the `assertNever` placeholder fallback.
  | "counterparty_card"
  | "clause_card"
  | "contract_card"
  | "redline_card"
  | "dpa_card"
  | "change_order_card"
  | "deliverable_acceptance_card"
  | "invoice_card"
  | "ar_aging_grid"
  | "dunning_card"
  // L2C Wave 4 (Task #363) — cash, bank reconciliation, forecast, renewals
  | "cash_receipt_card"
  | "bank_recon_card"
  | "cash_forecast_strip"
  | "renewal_card"
  // Task #406 — Chat Orchestrator coordinator cards.
  | "gate_report"
  | "entity_resolution"
  // Task #853 — universal entity lookups + AR rollups.
  | "statement_of_account"
  | "pending_invoices"
  // Task #1163 — account research brief (distilled view + executive tensions).
  | "account_brief"
  // Task #1183 — pre-formation cost pool summary card.
  | "preformation_pool";

export type SurfaceContext =
  | "engagement_dashboard"
  | "account_workspace"
  | "opportunity_workspace"
  | "wallet"
  | "ledger"
  | "roster"
  | "global"
  // Task #342 — explicit Home surface so the catalog can drive the
  // role-aware suggestion chips on the Home page (and the assistant's
  // empty-state chips when the user opened it from Home).
  | "home";

export interface SlashAlias {
  /** Free-form aliases the slash-command palette matches against. */
  en?: string[];
  fr?: string[];
  ar?: string[];
}

/**
 * Representative prompts in EN/AR/FR. Surfaced in the palette and used
 * as few-shot examples when the model is asked "what can you do here?".
 * Every entry should have at least one EN prompt; AR/FR are encouraged.
 */
export interface RepresentativePrompts {
  en: string[];
  ar?: string[];
  fr?: string[];
}

/**
 * Hint about which capabilities the orchestrator should suggest as a
 * follow-up after this one runs successfully (e.g. after raid.add, the
 * model can offer to /raid-list the engagement). Used by the
 * `proposed_plan` frame to chain reads after writes.
 */
export type FollowUpTrigger = string;

export interface CapabilityEntry {
  /** Stable identifier (`<module>.<verb>`) — used in audit + slash. */
  id: string;
  /**
   * Catalog/manifest version this entry was authored against. Bumped
   * deliberately for breaking changes to the entry SHAPE. Distinct from
   * `schemaHash` which tracks drift in the *input schema* of this
   * single entry.
   */
  schemaVersion: number;
  /**
   * Hash of the canonicalised input schema (sha-256, first 12 hex
   * chars). Auto-computed by `defineCapability` if not provided.
   * Pinned saved prompts compare against this — mismatch surfaces a
   * "review before running" warning.
   */
  schemaHash: string;
  /** Module family (used for role-filter + surface grouping). */
  module: CapabilityModule;
  /** Tool name as exposed to Claude. Convention: snake_case verb. */
  toolName: string;
  /** Short Claude-facing description (one sentence). */
  description: string;
  /** Slash-command aliases by locale. */
  slashAliases: SlashAlias;
  /**
   * Representative prompts used for palette previews + as inline
   * examples to the model. Keep one per locale so AR/FR users see the
   * capability surfaced in their language.
   */
  representativePrompts?: RepresentativePrompts;
  /** JSON Schema (Anthropic input_schema shape). */
  inputSchema: Record<string, unknown>;
  /** True if this capability mutates server state. */
  isWrite: boolean;
  /**
   * True if a successful run requires a separate `/confirm` POST
   * before the run callback fires (two-phase write). Read-only
   * capabilities should set this to `false`.
   */
  twoPhaseConfirm: boolean;
  /**
   * Outbound side-effect channel that fires when this capability
   * commits, or `null` for purely-internal mutations. Surfaced in the
   * confirmation diff and used by `undo` to refuse reversal.
   */
  outboundChannel: OutboundChannel | null;
  /**
   * Result-card hint used by the client to pick a typed renderer for
   * the tool result, or `null` when no card is appropriate.
   */
  resultCard: ResultCard | null;
  /**
   * True if the mutation is *not* trivially undoable (delete, revoke,
   * publish-to-Salon, send-to-client, lost-mark). Server requires
   * `{ confirm:true, typedName:"<entity name>" }` on the second
   * `/confirm` POST before the run callback executes.
   */
  irreversible: boolean;
  /** Personas allowed to invoke. Empty/omitted ⇒ everyone except `board_observer`. */
  requiredRoles?: AtelierRole[];
  /**
   * L2C Wave 2 (Task #361) — Personas allowed on the SECOND phase
   * (`/confirm`) of a two-phase write. Empty/omitted preserves the
   * pre-Wave-2 behaviour: the same `requiredRoles` are required for
   * both phases. Set this when the approver perimeter must be tighter
   * than the initiator perimeter (e.g. `revrec_post_period` is
   * initiated by `finance` but irrev-posted only by `founding_partner`).
   */
  approverRoles?: AtelierRole[];
  /** Surfaces where the slash-command palette should advertise this. */
  surfaceOn: SurfaceContext[];
  /**
   * Capability ids the orchestrator should propose as follow-ups after
   * this entry runs successfully. Declared here so a typo in the field
   * name (e.g. `followupTriggers`) fails the build instead of being
   * silently dropped at registration. See `FollowUpTrigger` above.
   */
  followUpTriggers?: FollowUpTrigger[];
  /**
   * Task #335/342 — optional per-locale natural-language phrasings that
   * the assistant client can show as suggestion chips (Home page,
   * assistant empty state, /help drawer). The first entry per locale
   * is treated as the canonical chip label.
   */
  examplePhrases?: { en?: string[]; ar?: string[]; fr?: string[] } | null;
  /**
   * Task #20 — opt-in promotion flag for the suggestion-chip strips
   * (chat-bar empty state + Home). Only capabilities that deliberately
   * set this to `true` contribute chips; everything else stays out of
   * the strips (but keeps its examplePhrases in the /help drawer,
   * where they have context). Default: off. Any capability marked
   * promotable MUST have a plain-language first example phrase per
   * locale — no chunk ids, opaque record ids, or slash syntax.
   */
  promoteAsSuggestion?: boolean;
  /**
   * Origin of the registration — used by lint/coverage tests to verify
   * every route file uses the framework rather than ad-hoc
   * `defineCapability` calls.
   */
  source: "route" | "agent" | "cli-only";
  /**
   * Unsupported entries remain in the reviewed manifest for compatibility,
   * but are never advertised to or dispatched by the orchestrator.
   */
  executionStatus?: "executable" | "unsupported" | "legacy_compat";
  /** Release-gated policy category derived at registration. */
  policyClass: CapabilityPolicyClass;
  /** Stable side-effect category used by policy and manifest parity checks. */
  effectClass: CapabilityEffectClass;
  /** Versioned card/empty-state rendering contract. */
  presentationContract: CapabilityPresentationContract;
  /** Transpilation-stable fingerprint of the executor authority contract. */
  implementationVersion: string;
  /** Approved, reviewed exceptions to full parity/execution requirements. */
  divergenceIds: string[];
  /**
   * Implementation. Receives the validated `input` and a `ToolContext`,
   * returns the standard `ToolResult` shape (with optional
   * `confirmation` + `disambiguation` envelopes).
   */
  run: (input: Record<string, unknown>, ctx: ToolContext) => Promise<ToolResult>;
}

/** Catalog/manifest version. Bump when the entry SHAPE changes. */
export const CATALOG_SCHEMA_VERSION = 3;

/**
 * Input shape for `defineCapability`. `schemaHash` and `source` are
 * computed/defaulted automatically when omitted.
 */
export type CapabilityInput =
  & Omit<
    CapabilityEntry,
    | "schemaHash"
    | "source"
    | "policyClass"
    | "effectClass"
    | "presentationContract"
    | "implementationVersion"
    | "divergenceIds"
  >
  & {
    schemaHash?: string;
    source?: CapabilityEntry["source"];
    divergenceIds?: string[];
  };

const REGISTRY: CapabilityEntry[] = [];
let REGISTRY_FINALIZED = false;
const JSON_SCHEMA_META_VALIDATOR = new Ajv({
  allErrors: true,
  strictSchema: true,
  validateSchema: true,
});

/**
 * Canonicalise a JSON-Schema-shaped object so two structurally
 * equivalent schemas hash identically (sorted keys, deterministic
 * stringify). We don't need full JSON-Schema canonicalisation — just
 * stable iteration order is enough to detect a real shape change.
 */
function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) {
    return `[${value.map((v) => canonicalJson(v)).join(",")}]`;
  }
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(obj[k])}`).join(",")}}`;
}

/**
 * Derive the schema hash an entry should carry. Exposed so callers
 * (saved-prompt persistence, migration scripts) can compute the same
 * fingerprint without going through `defineCapability`.
 */
export function hashSchema(schema: Record<string, unknown>): string {
  return createHash("sha256").update(canonicalJson(schema)).digest("hex").slice(0, 12);
}

export function assertValidCapabilityInputSchema(
  schema: Record<string, unknown>,
  id = "unknown",
): void {
  if (schema.type !== "object" || !JSON_SCHEMA_META_VALIDATOR.validateSchema(schema)) {
    const detail = JSON_SCHEMA_META_VALIDATOR.errors
      ?.map((error) => `${error.instancePath || "/"} ${error.message ?? "invalid"}`)
      .join("; ");
    throw new Error(`capability-invalid-json-schema:${id}${detail ? `:${detail}` : ""}`);
  }
}

function deriveExecutionStatus(
  entry: CapabilityInput,
): NonNullable<CapabilityEntry["executionStatus"]> {
  return entry.executionStatus ??
    (entry.isWrite && !entry.twoPhaseConfirm ? "legacy_compat" : "executable");
}

function derivePolicyClass(
  entry: CapabilityInput,
  status: NonNullable<CapabilityEntry["executionStatus"]>,
): CapabilityPolicyClass {
  if (status === "unsupported") return "unsupported";
  if (!entry.isWrite) {
    return entry.requiredRoles?.length ? "role_restricted_read" : "authenticated_read";
  }
  if (!entry.twoPhaseConfirm) return "legacy_write";
  if (entry.outboundChannel) return "outbound_write";
  if (entry.irreversible) return "irreversible_write";
  return "confirmed_write";
}

function derivePresentationContract(entry: CapabilityInput): CapabilityPresentationContract {
  const semantic =
    (entry.id === "roster.list" &&
      entry.toolName === "roster_list" &&
      entry.resultCard === "ranked_list") ||
    (entry.id === "roster.person_detail" &&
      entry.toolName === "person_detail" &&
      entry.resultCard === "contact_card");
  return {
    cardType: entry.resultCard,
    contractVersion: 1,
    renderer: entry.resultCard ? (semantic ? "semantic-v1" : "legacy-native-v1") : "none",
    minimumDataVersion: 1,
  };
}

function deriveDivergenceIds(
  entry: CapabilityInput,
  status: NonNullable<CapabilityEntry["executionStatus"]>,
): string[] {
  const ids = new Set(entry.divergenceIds ?? []);
  const source = entry.source ?? "cli-only";
  if (source === "cli-only") ids.add("cli-only-route-parity-v1");
  if (source === "agent" && status === "unsupported") {
    ids.add("agent-executor-unsupported-v1");
  }
  if (status === "legacy_compat") ids.add("legacy-confirmation-compat-v1");
  return [...ids].sort();
}

function assertRegistrationContract(entry: CapabilityEntry): void {
  if (!/^[a-z0-9_.-]+$/.test(entry.id)) throw new Error(`capability-invalid-id:${entry.id}`);
  if (!/^[a-z0-9_]+$/.test(entry.toolName)) {
    throw new Error(`capability-invalid-tool:${entry.id}`);
  }
  if (entry.schemaVersion !== CATALOG_SCHEMA_VERSION) {
    throw new Error(`capability-schema-version-mismatch:${entry.id}`);
  }
  assertValidCapabilityInputSchema(entry.inputSchema, entry.id);
  if (!entry.description.trim()) throw new Error(`capability-missing-description:${entry.id}`);
  if (typeof entry.run !== "function") throw new Error(`capability-missing-executor:${entry.id}`);
  if (!entry.isWrite && (entry.twoPhaseConfirm || entry.irreversible || entry.outboundChannel)) {
    throw new Error(`capability-read-effect-mismatch:${entry.id}`);
  }
  if (entry.presentationContract.cardType !== entry.resultCard) {
    throw new Error(`capability-presentation-contract-mismatch:${entry.id}`);
  }
  if (entry.executionStatus === "unsupported" && entry.divergenceIds.length === 0) {
    throw new Error(`capability-unsupported-without-divergence:${entry.id}`);
  }
  assertCapabilityDivergences(entry.divergenceIds);
}

/**
 * Task #511 — Runtime contract enforcement for the navigateTo hint.
 *
 * Every `isWrite: true` capability MUST return a `navigateTo` value on
 * commit-success: either `null` (no navigation) or
 * `{ path: string, when: "on_commit" }` (auto-navigate after the
 * mutation lands). This wrapper observes every commit-success result
 * and throws with the offending capability id when the contract is
 * violated, so a regression surfaces immediately at call-time instead
 * of silently breaking the chat client's auto-navigation.
 *
 * "Commit-success" = `ok: true` with a `data` payload AND no envelope
 * indicating the orchestrator is still mid-flight (no `confirmation`,
 * `disambiguation`, `clarification`, `refusal`, `asyncJob`, or
 * `needsAttachments`). Read-only caps (isWrite=false) are not
 * checked. The wrapper exposes a `__navContractWrapped` marker so
 * tests can assert every isWrite cap is wrapped.
 */
type ToolResultLike = ToolResult & {
  asyncJob?: unknown;
  needsAttachments?: unknown;
};
function isCommitSuccess(r: ToolResultLike): boolean {
  if (!r || r.ok !== true) return false;
  if (r.confirmation || r.disambiguation || r.clarification || r.refusal) return false;
  if (r.asyncJob || r.needsAttachments) return false;
  return r.data !== undefined && r.data !== null && typeof r.data === "object";
}
export function validateNavigateToShape(value: unknown): string | null {
  if (value === null) return null;
  if (value === undefined) return "missing `navigateTo` key on commit-success data";
  if (typeof value !== "object") {
    return `navigateTo must be an object or null (got ${typeof value})`;
  }
  const o = value as Record<string, unknown>;
  if (o.when !== "on_commit") {
    return `navigateTo.when must equal "on_commit" (got ${JSON.stringify(o.when)})`;
  }
  if (typeof o.path !== "string" || o.path.length === 0) {
    return `navigateTo.path must be a non-empty string (got ${JSON.stringify(o.path)})`;
  }
  return null;
}
export function assertNavigateToContract(id: string, result: ToolResult): void {
  if (!isCommitSuccess(result as ToolResultLike)) return;
  const data = result.data as Record<string, unknown>;
  if (!("navigateTo" in data)) {
    throw new Error(
      `[capability "${id}"] commit-success result is missing the \`navigateTo\` key. ` +
        `Add \`navigateTo: { path, when: "on_commit" }\` or explicit \`navigateTo: null\` to the returned data.`,
    );
  }
  const err = validateNavigateToShape(data.navigateTo);
  if (err) {
    throw new Error(
      `[capability "${id}"] navigateTo contract violation: ${err}. ` +
        `Expected null or { path: string, when: "on_commit" }.`,
    );
  }
}

/**
 * A generated id, audit row, or optimistic "dispatched" flag is not execution.
 * Real queued/running work must identify a persisted job explicitly; completed
 * synchronous work should return its durable run/record result instead.
 */
export async function assertExecutionProofContract(
  id: string,
  executionStatus: CapabilityEntry["executionStatus"],
  result: ToolResult,
  orgId?: string,
): Promise<void> {
  if (executionStatus !== "executable" || !isCommitSuccess(result as ToolResultLike)) return;
  const data = result.data as Record<string, unknown>;
  if (data.dispatched === true) {
    throw new Error(`capability-synthetic-dispatch:${id}`);
  }
  const status = typeof data.status === "string" ? data.status : null;
  const claimsDurableExecution =
    status === "queued" ||
    status === "running" ||
    data.agentRun !== undefined ||
    (status === "completed" && typeof data.runId === "string");
  if (!claimsDurableExecution) return;

  const execution =
    data.execution && typeof data.execution === "object"
      ? (data.execution as Record<string, unknown>)
      : null;
  if (
    !execution ||
    (execution.kind !== "work_item" && execution.kind !== "agent_run") ||
    typeof execution.id !== "string" ||
    !execution.id ||
    !orgId
  ) {
    throw new Error(`capability-unverified-execution:${id}`);
  }
  if (execution.kind === "work_item") {
    const [row] = await db
      .select({ id: atelierWorkItems.id })
      .from(atelierWorkItems)
      .where(and(eq(atelierWorkItems.id, execution.id), eq(atelierWorkItems.orgId, orgId)))
      .limit(1);
    if (!row) throw new Error(`capability-unverified-work-item:${id}`);
  } else {
    const [row] = await db
      .select({ id: atelierAgentRuns.id })
      .from(atelierAgentRuns)
      .where(and(eq(atelierAgentRuns.id, execution.id), eq(atelierAgentRuns.orgId, orgId)))
      .limit(1);
    if (!row) throw new Error(`capability-unverified-agent-run:${id}`);
  }
}

/**
 * Register a capability. Throws on duplicate `id`/`toolName` so a typo
 * can't silently clobber an entry. Auto-computes `schemaHash` if the
 * caller didn't pin one. For `isWrite: true` capabilities, wraps
 * `run` with the Task #511 navigateTo contract validator so commit
 * regressions throw at call-time.
 */
export function defineCapability(entry: CapabilityInput): CapabilityEntry {
  if (REGISTRY_FINALIZED) throw new Error("capability-catalog-finalized");
  const executionStatus = deriveExecutionStatus(entry);
  const policyClass = derivePolicyClass(entry, executionStatus);
  const effectClass: CapabilityEffectClass = !entry.isWrite
    ? "read"
    : entry.outboundChannel
      ? "outbound_write"
      : "internal_write";
  const presentationContract = derivePresentationContract(entry);
  const divergenceIds = deriveDivergenceIds(entry, executionStatus);
  const implementationVersion = createHash("sha256")
    .update(
      canonicalJson({
        executorContractVersion: 1,
        id: entry.id,
        toolName: entry.toolName,
        module: entry.module,
        source: entry.source ?? "cli-only",
        inputSchemaHash: entry.schemaHash ?? hashSchema(entry.inputSchema),
        policyClass,
        effectClass,
        presentationContract,
        requiredRoles: [...(entry.requiredRoles ?? [])].sort(),
        approverRoles: [...(entry.approverRoles ?? entry.requiredRoles ?? [])].sort(),
        confirmation: {
          required: entry.twoPhaseConfirm,
          irreversible: entry.irreversible,
          outboundChannel: entry.outboundChannel,
        },
      }),
    )
    .digest("hex")
    .slice(0, 12);
  const finalised: CapabilityEntry = {
    ...entry,
    source: entry.source ?? "cli-only",
    schemaHash: entry.schemaHash ?? hashSchema(entry.inputSchema),
    executionStatus,
    policyClass,
    effectClass,
    presentationContract,
    implementationVersion,
    divergenceIds,
  };
  if (REGISTRY.some((e) => e.id === finalised.id || e.toolName === finalised.toolName)) {
    throw new Error(
      `[capability-catalog] duplicate id/toolName: ${finalised.id}/${finalised.toolName}`,
    );
  }
  assertRegistrationContract(finalised);
  if (finalised.isWrite) {
    const inner = finalised.run;
    const wrapped = async (
      input: Record<string, unknown>,
      ctx: ToolContext,
    ): Promise<ToolResult> => {
      const result = await inner(input, ctx);
      await assertExecutionProofContract(
        finalised.id,
        finalised.executionStatus,
        result,
        ctx.persona.orgId,
      );
      assertNavigateToContract(finalised.id, result);
      return result;
    };
    (wrapped as unknown as { __navContractWrapped: true }).__navContractWrapped = true;
    finalised.run = wrapped;
  }
  REGISTRY.push(finalised);
  return finalised;
}

export function listCapabilities(): readonly CapabilityEntry[] {
  return REGISTRY;
}

export function finalizeCapabilityCatalog(): void {
  if (REGISTRY_FINALIZED) return;
  for (const entry of REGISTRY) {
    assertRegistrationContract(entry);
    Object.freeze(entry.divergenceIds);
    Object.freeze(entry.presentationContract);
    Object.freeze(entry);
  }
  REGISTRY_FINALIZED = true;
  Object.freeze(REGISTRY);
}

/**
 * Test-only reset hook. Catalog registration is normally one-shot at
 * process boot; tests that want to assert against a fresh registry use
 * this. Not exported from the public index.
 */
export function __resetCatalogForTests(): void {
  if (REGISTRY_FINALIZED) throw new Error("capability-catalog-finalized");
  REGISTRY.length = 0;
}

/**
 * Role-perimeter filter: returns only the capabilities the given
 * persona is allowed to invoke. Board observers see only `meta` +
 * read-only `raid` (mirrors the read-only UI shell they get).
 */
// L2C Wave 1 (Task #360, W1-S8) — modules a restricted persona
// (contractor / partner_firm_resource / recruiter) is never permitted
// to see in the CLI catalog. Mirrors the route-layer
// `canRead(role) = !isRestrictedPersona(role) && !isBoardObserver(role)`
// gate enforced by `codexRoutes`, `changeOrderRoutes` and
// `deliverableAcceptanceRoutes`. Defence-in-depth: even if a future
// `requiredRoles` declaration accidentally allows a restricted role,
// the catalog gate strips the entry from the per-persona slice the
// orchestrator ever sees.
const RESTRICTED_DENIED_MODULES: ReadonlySet<CapabilityModule> = new Set([
  "codex",
  "change_order",
  "deliverable_acceptance",
  // L2C Wave 2 — restricted personas (contractor / partner_firm_resource /
  // recruiter) never see revenue, WIP, margin, or leakage surfaces.
  "revrec",
  "wip",
  "margin",
  "leakage",
  // L2C Wave 4 — restricted personas never see cash, bank, treasury, renewal.
  "cash",
  "bank",
  "treasury",
  "renewal",
]);

/**
 * L2C Wave 2 (Task #361) — Allow-list of capability ids the
 * `board_observer` persona is permitted to call despite the strict
 * read-only/board-realm gate below. Hard-coded ids (NOT module-wide)
 * so individual invoice / receipt / dunning capabilities (Waves 3+4)
 * remain denied until the boardroom realm declares them.
 *
 * Wave-3 + Wave-4 ids are declared up-front per spec so the catalog
 * gate is the only thing that needs to change when those waves ship.
 */
export const BOARD_OBSERVER_ROLLUP_ALLOWLIST: ReadonlySet<string> = new Set([
  "wip_report",
  "leakage_report",
  "revrec_compute_schedule", // read-only invocation: returns cached schedule
  "ar_aging_report", // Wave 3 — declared up-front
  "cash_forecast_13w", // Wave 4 — declared up-front
]);

/**
 * Task #422 — self-only personas (employee / contractor) get chat access
 * strictly for the identity-locked `me.*` capabilities (Task #405).
 * Their entire REST world is the /me lens; the chat surface mirrors that
 * perimeter exactly so opening /cli/* to them cannot leak org-wide tools.
 */
export const SELF_ONLY_CHAT_ROLES: ReadonlySet<string> = new Set([
  "employee",
  "contractor",
  // Task #1297 — non_equity_partner chat is the same identity-locked me.*
  // perimeter; their only widening is entity.detail, whose in-run clamp
  // resolves their accessible accounts/opportunities through the NEP
  // grant/invite/ownership set (lib/atelier-nep-access.ts) instead of
  // engagement staffing.
  "non_equity_partner",
]);

/**
 * Task #583 — capability-miss protocol. Refusal frames must never leak
 * internal tool/capability identifiers to the user (they read as
 * gibberish and reveal surface internals). Replaces any registered
 * tool name or capability id — plus obvious snake_case tool tokens —
 * with a neutral phrase. Backticks around the identifiers are eaten.
 */
export function scrubToolIdentifiers(text: string | null | undefined): string | null {
  if (!text) return text ?? null;
  let out = text;
  for (const e of REGISTRY) {
    const names = [e.toolName, e.id];
    for (const n of names) {
      if (!n) continue;
      const esc = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      out = out.replace(new RegExp("`?" + esc + "`?", "g"), "that action");
    }
  }
  // Generic snake_case tool-token fallback (e.g. an unregistered or
  // hallucinated name the model produced): two+ underscore segments.
  out = out.replace(/`?\b[a-z][a-z0-9]*(?:_[a-z0-9]+){1,}\b`?/g, "that action");
  // Collapse doubled phrases produced by adjacent replacements.
  out = out.replace(/(that action)( \1)+/g, "$1").replace(/\s{2,}/g, " ").trim();
  return out;
}

/**
 * Task #644 — conservative narration scrub. Unlike scrubToolIdentifiers
 * (used for refusal frames), this replaces ONLY registered tool names /
 * capability ids — never the generic snake_case fallback — so entity
 * ids, references and file names in normal prose are left untouched.
 */
export function scrubKnownToolNames(text: string | null | undefined): string | null {
  if (!text) return text ?? null;
  let out = text;
  for (const e of REGISTRY) {
    for (const n of [e.toolName, e.id]) {
      if (!n) continue;
      const esc = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      out = out.replace(new RegExp("`?\\b" + esc + "\\b`?", "g"), "that action");
    }
  }
  out = out.replace(/(that action)( \1)+/g, "$1").replace(/[ \t]{2,}/g, " ");
  return out;
}

export function capabilitiesForPersona(persona: CliPersona): CapabilityEntry[] {
  const role = persona.role as AtelierRole;
  const executableRegistry = REGISTRY.filter((entry) => entry.executionStatus !== "unsupported");
  // Task #873 — external alliance-partner logins get EXACTLY the
  // partnerportal.* read capabilities (their granted opportunities +
  // redacted account overview). No me.* tools (they have no roster
  // identity), no entity.detail widening, no attachment/RAG retrieval,
  // no roster / finance / CRM tools — ever.
  if (role === "alliance_partner") {
    // Task #939 — meta.find_screen is allowed: its catalog slice for
    // alliance_partner contains ONLY the partner-portal screens.
    // Task #1175 — deliberately admit the SINGLE partner-portal write
    // tool (partnerportal.request_change): partners may PROPOSE a
    // review-gated change to their own firm profile. Every OTHER write
    // stays excluded (no me.*, no CRM, no entity writes — ever).
    return executableRegistry.filter(
      (e) =>
        (!e.isWrite &&
          (e.id.startsWith("partnerportal.") || e.id === "meta.find_screen")) ||
        e.id === "partnerportal.request_change",
    );
  }
  if (SELF_ONLY_CHAT_ROLES.has(role)) {
    // Task #583 — self-only personas now get the identity-locked me.*
    // WRITE capabilities too (leave request, expense create, timesheet
    // log/submit, profile edit, personal documents, notification
    // dismiss). Every me.* write resolves its subject from the session
    // persona, mirrors the /me/* REST ACLs, and is confirm-gated —
    // still strictly the /me lens, never an org-wide tool.
    // Task #853 — deliberate, narrowly-scoped widening: the generic
    // `entity.detail` lookup is allowed, and inside its run() self-only
    // personas are clamped to accounts / engagements / deliverables they
    // are staffed on (engagement grant or account-team membership).
    // Nothing else widens.
    // Task #939 — meta.find_screen is a second deliberate widening: the
    // screen catalog is role-sliced, so self-only personas only ever get
    // answers about Me-lens screens (plus chat itself).
    return executableRegistry.filter(
      (e) =>
        e.id.startsWith("me.") ||
        e.id === "entity.detail" ||
        e.id === "meta.find_screen",
    );
  }
  const restrictedSet: ReadonlySet<AtelierRole> = new Set([
    "contractor",
    "partner_firm_resource",
    "recruiter",
  ]);
  const isRestricted = restrictedSet.has(role);
  return executableRegistry.filter((e) => {
    if (role === "board_observer") {
      // Strict read-only perimeter — writes are denied regardless of
      // module so a future module classification mistake (e.g. an
      // agent mapped to `meta`) cannot leak a mutation onto the
      // observer surface.
      if (e.isWrite) return false;
      // L2C Wave 2 — explicit allow-list of firm-wide rollup ids the
      // board_observer is permitted to see. Checked BEFORE the
      // module-deny gate so the rollup capabilities can live in the
      // (otherwise denied) revrec / wip / leakage modules.
      if (BOARD_OBSERVER_ROLLUP_ALLOWLIST.has(e.id)) return true;
      // Task #362 — board_observer is allowed on the AR aging rollup
      // capability (rollup-only access; per-invoice rows are stripped
      // server-side). Detail capabilities in the wallet module remain
      // denied via `denyBoardObserver` in the capability handler.
      if (e.id === "wallet.ar.aging") return true;
      // Board observer also denied L2C surfaces (no contract / change-
      // order / acceptance visibility) until the boardroom realm ships.
      if (RESTRICTED_DENIED_MODULES.has(e.module)) return false;
      return e.module === "meta" || e.module === "raid";
    }
    // L2C Wave 1 restricted-set deny gate — applies to contractor /
    // partner_firm_resource / recruiter. They never see Codex, change-
    // order, or deliverable-acceptance verbs even if a downstream
    // entry forgets to declare `requiredRoles`.
    if (isRestricted && RESTRICTED_DENIED_MODULES.has(e.module)) {
      return false;
    }
    if (e.requiredRoles && e.requiredRoles.length > 0) {
      return e.requiredRoles.includes(role);
    }
    return true;
  });
}

/** Used by orchestrator to look up a capability by toolName. */
export function findByToolName(toolName: string): CapabilityEntry | undefined {
  return REGISTRY.find(
    (e) => e.toolName === toolName && e.executionStatus !== "unsupported",
  );
}

/** Task #335 — id-keyed lookup (used by undo + admin metrics). */
export function findById(id: string): CapabilityEntry | undefined {
  return REGISTRY.find((e) => e.id === id && e.executionStatus !== "unsupported");
}

// Task #340 — conversation depth: per-session ephemeral draft store.
// In-memory map keyed by sessionId. Holds the last referenced entities
// (for pronoun resolution + clarification merge) plus a snapshot of
// the most recent tool result so meta.refine_last / meta.explain_last
// / meta.undo_last can operate without re-querying the model.
// =====================================================================

export interface CliEntityRef {
  kind: string;
  id: string;
  label: string;
  href?: string | null;
  at: number;
}

export interface SessionDraft {
  entities: Record<string, CliEntityRef>;
  lastTurnId?: string;
  lastWriteTurnId?: string;
  lastWriteTool?: string;
  /** Most recent read tool + args, captured for refine_last re-runs. */
  lastReadTool?: string;
  lastReadArgs?: Record<string, unknown>;
  /** Captured raid item id for undo. */
  lastWriteRaidId?: string;
  lastResultKind?: string;
  lastResultRows?: Array<Record<string, unknown>>;
  lastResultSummary?: string;
  lastResultAt?: number;
  lastFeatureRequestAt?: number;
  pendingClarification?: {
    field: string;
    question: string;
    originalPrompt: string;
    partial: Record<string, unknown>;
    tool: string;
    /** Multi-field clarification: every missing field being asked for. */
    fields?: Array<{ field: string; label: string; hint?: string }> | null;
  } | null;
  /**
   * Task #799 — first-class disambiguation continuation. When a tool
   * emits `disambiguation` with a declared `field`, the orchestrator
   * stores the originating tool + partial input here; the user's pick
   * (chip tap or typed reply) is merged into `field` and the tool is
   * re-run server-side — no model extraction involved.
   */
  pendingDisambiguation?: {
    tool: string;
    /** The tool-input field the picked option id fills. */
    field: string;
    kind: string;
    options: Array<{ id: string; label: string }>;
    partial: Record<string, unknown>;
    originalPrompt: string;
  } | null;
}

const SESSION_DRAFTS = new Map<string, SessionDraft>();
const DRAFT_TTL_MS = 60 * 60 * 1000;
const DRAFT_MAX_SIZE = 1000;

export function getSessionDraft(sessionId: string): SessionDraft {
  let cur = SESSION_DRAFTS.get(sessionId);
  if (!cur) {
    cur = { entities: {} };
    SESSION_DRAFTS.set(sessionId, cur);
  }
  return cur;
}

export function recordSessionEntity(sessionId: string, ref: Omit<CliEntityRef, "at">): void {
  if (!ref.id || !ref.kind) return;
  const d = getSessionDraft(sessionId);
  d.entities[ref.kind] = { ...ref, at: Date.now() };
}

export function recordSessionResult(
  sessionId: string,
  patch: Partial<SessionDraft>,
): void {
  const d = getSessionDraft(sessionId);
  Object.assign(d, patch);
  d.lastResultAt = Date.now();
}

export function clearSessionDraft(sessionId: string): void {
  SESSION_DRAFTS.delete(sessionId);
}

export function pruneSessionDrafts(now: number = Date.now()): void {
  for (const [k, v] of SESSION_DRAFTS.entries()) {
    const at = v.lastResultAt ?? Math.max(0, ...Object.values(v.entities).map((e) => e.at));
    if (now - at > DRAFT_TTL_MS) SESSION_DRAFTS.delete(k);
  }
  if (SESSION_DRAFTS.size > DRAFT_MAX_SIZE) {
    const entries = [...SESSION_DRAFTS.entries()];
    entries.sort((a, b) => (a[1].lastResultAt ?? 0) - (b[1].lastResultAt ?? 0));
    for (const [k] of entries.slice(0, entries.length - DRAFT_MAX_SIZE)) {
      SESSION_DRAFTS.delete(k);
    }
  }
}

export function summarizeSessionDraft(sessionId: string): string {
  const d = SESSION_DRAFTS.get(sessionId);
  if (!d) return "";
  const ents = Object.entries(d.entities)
    .sort((a, b) => b[1].at - a[1].at)
    .slice(0, 6);
  const lines: string[] = [];
  if (ents.length > 0) {
    lines.push("Recent entities (resolve 'it'/'that one' to these):");
    for (const [k, v] of ents) lines.push(`- ${k}: "${v.label}" (id ${v.id})`);
  }
  if (d.lastResultKind && Array.isArray(d.lastResultRows)) {
    lines.push(`Last result: ${d.lastResultRows.length} ${d.lastResultKind}.`);
  }
  if (d.pendingClarification) {
    lines.push(
      `Awaiting clarification on field "${d.pendingClarification.field}" for ${d.pendingClarification.tool}.`,
    );
  }
  return lines.join("\n");
}

export function ingestEntitiesFromToolResult(
  sessionId: string,
  toolName: string,
  data: unknown,
): void {
  if (!data || typeof data !== "object") return;
  const o = data as Record<string, unknown>;
  const tryRef = (kind: string, id: unknown, label: unknown): void => {
    if (typeof id === "string" && id.length > 0) {
      recordSessionEntity(sessionId, {
        kind,
        id,
        label: typeof label === "string" && label.length > 0 ? label : id,
      });
    }
  };
  tryRef("account", o.accountId ?? (o.account as { id?: unknown })?.id, o.accountName ?? (o.account as { name?: unknown })?.name ?? o.name);
  tryRef("engagement", o.engagementId ?? (o.engagement as { id?: unknown })?.id, o.engagementName ?? (o.engagement as { name?: unknown })?.name);
  tryRef("raid_item", o.raidItemId ?? (toolName.startsWith("raid_") ? o.id : undefined), o.description ?? o.label);
  tryRef("deliverable", o.deliverableId, o.deliverableName ?? o.label);
  tryRef("opportunity", o.opportunityId, o.opportunityName ?? o.label);
  if (Array.isArray(o.options)) {
    for (const opt of o.options as Array<Record<string, unknown>>) {
      if (opt && typeof opt.id === "string") {
        recordSessionEntity(sessionId, {
          kind: "candidate",
          id: opt.id,
          label: typeof opt.label === "string" ? opt.label : opt.id,
        });
      }
    }
  }
  const rows: Array<Record<string, unknown>> | null = Array.isArray(o.items)
    ? (o.items as Array<Record<string, unknown>>)
    : Array.isArray(o.rows)
      ? (o.rows as Array<Record<string, unknown>>)
      : Array.isArray(o.results)
        ? (o.results as Array<Record<string, unknown>>)
        : null;
  if (rows && rows.length > 0) {
    recordSessionResult(sessionId, {
      lastResultRows: rows.slice(0, 200),
      lastResultKind: toolName,
    });
  }
}
