# Riser Flight & Hotel Search Export

This bundle contains the flight and hotel search functionality used by Riser in Cognirise Atelier, prepared for implementation in another application.

## Start here

1. Read `docs/IMPLEMENTATION_GUIDE.md`.
2. Use `portable-kit/` for the smallest runnable Node/TypeScript example.
3. Use `live-reference/` for the exact current production implementation, UI cards, chat protocol, preferences, generated types, and tests.

## Important

- No API keys or credential values are included.
- Keep all provider credentials on the server.
- Booking is intentionally deep-link-only; these modules do not purchase flights or hotel stays.
- The portable kit is an older isolated extraction. `live-reference/` is the source of truth for current behavior.
