# Implementation guide

## Architecture

Riser chat turn → governed capability catalogue → travel tool → server-side provider client → normalized semantic result → web/mobile result card → external booking/search deep link.

The guided planner returns a structured clarification payload. The client renders a planner form and sends completed values through the normal clarification flow. Flight and hotel searches return semantic cards rather than provider-specific payloads.

## Core server files

- `travel-providers.ts`: Ignav flight/airport client and StayingAPI hotel client, authentication, timeouts, polling, normalization, and errors.
- `travel-capabilities.ts`: planner, flight search/selection, hotel search, Airbnb links, fare options, itineraries, schemas, ACLs, currency display, and deep links.
- `capability-catalog.ts`: capability registration and persona filtering.
- `bootstrap-capabilities.ts`: startup registration imports.
- `travel-preferences.ts` and `travel-preferences-db.ts`: preference contract and Atelier DB adapter.
- `travel-companion-capabilities.ts`: additional-traveler selection.
- `atelier-travel-profile.ts`: profile validation, defaults, redaction, and wire format.

## Server-only provider configuration

- `IGNAV_API_KEY`: Ignav `X-Api-Key`.
- `STAYINGAPI_API_KEY`: StayingAPI Bearer token.
- `ATELIER_IGNAV_BASE_URL`: optional test/trusted-environment override.
- `ATELIER_STAYING_BASE_URL`: optional test/trusted-environment override.

Missing production keys fail explicitly with `travel_unavailable`; production does not silently return mock data.

## Flight behavior

- Airport text resolves through Ignav suggestions.
- One-way and symmetric returns use dedicated endpoints.
- Open-jaw and 3+ leg trips use flexible/multi-leg search.
- Original currency and amount are retained.
- AED display is approximate using a static table; use live FX for financial precision.
- Selection continues through chat and hands off to an external flight-search link.

## Hotel behavior

- StayingAPI may return HTTP 202; the client polls until completion or deadline.
- Preserve abort/timeout and body-read safeguards.
- Results deep-link to provider or Google Hotels pages; no booking write occurs.
- Airbnb support is link generation only.

## UI and chat contract

The server returns `ToolResult` variants including clarification, disambiguation, and ranked-list results. Web/mobile references show planner rendering, clarification submission, result cards, selection continuation, and external-link handling. If your app does not use Riser's protocol, retain provider/schema layers and map normalized results to your own API types.

## Preferences and companions

Core search is DB-free. Preferences and companion lookup require your own profile and directory adapters. Register preferences through `setTravelPreferencesResolver` and adapt travel roles/persona filtering to your authorization model.

## Security checklist

- Never expose provider keys to browser/mobile code.
- Restrict provider base-URL overrides to tests or trusted environments.
- Validate/allow-list outbound HTTPS links.
- Preserve organization/user scoping for preferences and companions.
- Do not log credentials, private profiles, or sensitive provider responses.
- Keep sandbox results visibly labelled.
- Treat provider responses as untrusted and retain normalization/validation.

## Testing

The portable probe runs local Ignav and StayingAPI stubs without keys, a database, or network. The current tests cover provider flow, companions, travel profiles, planner dates, and result rendering.

```bash
cd portable-kit/server
npm install
npm run typecheck
npm test
```
