/**
 * SWAP-IN CATEGORY TAXONOMY
 *
 * Replace the groups/subcategories below with your own expense taxonomy.
 * Everything in code/ derives its category lists, defaults, aliases and
 * validation from this single file — no other edits are needed to re-theme
 * the scanner for a different app (e.g. employee expense categories).
 */
export type CategoryIcon = string;

export interface Category {
  id: string;
  name: string;
  icon: CategoryIcon;
}

export interface CategoryGroup {
  title: string;
  categories: Category[];
}

export interface CategoryWithSubcategories {
  category: string;
  subcategories: string[];
}

export interface SeedCategory {
  name: string;
  icon: string;
  groupName: string;
  displayOrder: number;
}

// ============================================================
// EXPENSE CATEGORY GROUPS
// ============================================================

export const EXPENSE_CATEGORY_GROUPS: CategoryGroup[] = [
  {
    title: "Food & Dining",
    categories: [
      { id: "f1", name: "Food & Dining", icon: "coffee" },
      { id: "f2", name: "Groceries", icon: "shopping-cart" },
    ],
  },
  {
    title: "Housing & Utilities",
    categories: [
      { id: "h1", name: "Housing", icon: "home" },
      { id: "h2", name: "Utilities", icon: "zap" },
    ],
  },
  {
    title: "Transportation",
    categories: [
      { id: "t1", name: "Transportation", icon: "truck" },
    ],
  },
  {
    title: "Shopping",
    categories: [
      { id: "s1", name: "Shopping", icon: "shopping-bag" },
      { id: "s2", name: "Kids & Pets", icon: "users" },
    ],
  },
  {
    title: "Health & Fitness",
    categories: [
      { id: "m1", name: "Health & Fitness", icon: "activity" },
    ],
  },
  {
    title: "Entertainment & Leisure",
    categories: [
      { id: "e1", name: "Entertainment", icon: "film" },
      { id: "e2", name: "Subscriptions & Apps", icon: "play-circle" },
      { id: "e3", name: "Travel", icon: "navigation" },
    ],
  },
  {
    title: "Financial",
    categories: [
      { id: "b1", name: "Financial", icon: "dollar-sign" },
      { id: "b2", name: "Payment & Transfers", icon: "credit-card" },
      { id: "b3", name: "Taxes & Government", icon: "file-text" },
    ],
  },
  {
    title: "Other",
    categories: [
      { id: "o1", name: "Education", icon: "book" },
      { id: "o2", name: "Gifts & Donations", icon: "gift" },
      { id: "o3", name: "Home Maintenance", icon: "tool" },
      { id: "o4", name: "Other", icon: "more-horizontal" },
    ],
  },
];

// ============================================================
// INCOME CATEGORY GROUPS
// ============================================================

export const INCOME_CATEGORY_GROUPS: CategoryGroup[] = [
  {
    title: "Employment",
    categories: [
      { id: "p1", name: "Salary & Allowances", icon: "dollar-sign" },
    ],
  },
  {
    title: "Business & Self-Employed",
    categories: [
      { id: "b1", name: "Business / Self-Employed", icon: "trending-up" },
    ],
  },
  {
    title: "Property & Rental",
    categories: [
      { id: "r1", name: "Rental Income", icon: "home" },
    ],
  },
  {
    title: "Investments & Returns",
    categories: [
      { id: "i1", name: "Investments & Financial Gains", icon: "pie-chart" },
      { id: "i2", name: "Asset Sales", icon: "package" },
    ],
  },
  {
    title: "Gifts & Transfers",
    categories: [
      { id: "g1", name: "Gifts & Transfers", icon: "gift" },
    ],
  },
  {
    title: "Refunds & Adjustments",
    categories: [
      { id: "f1", name: "Refunds / Reimbursements", icon: "rotate-ccw" },
    ],
  },
  {
    title: "Other",
    categories: [
      { id: "x1", name: "Other", icon: "more-horizontal" },
    ],
  },
];

// ============================================================
// EXPENSE CATEGORY KEYS (for translations)
// Maps category name to translation key in locales/*/translation.json
// ============================================================

export const EXPENSE_CATEGORY_KEYS: Record<string, string> = {
  "Food & Dining": "foodDining",
  "Groceries": "groceries",
  "Housing": "housing",
  "Utilities": "utilities",
  "Transportation": "transportation",
  "Shopping": "shopping",
  "Kids & Pets": "kidsPets",
  "Health & Fitness": "healthFitness",
  "Entertainment": "entertainment",
  "Subscriptions & Apps": "subscriptionsApps",
  "Travel": "travel",
  "Financial": "financial",
  "Payment & Transfers": "paymentTransfers",
  "Taxes & Government": "taxesGovernment",
  "Education": "education",
  "Gifts & Donations": "giftsDonations",
  "Home Maintenance": "homeMaintenance",
  "Other": "other",
};

// ============================================================
// INCOME CATEGORY KEYS (for translations)
// Maps category name to translation key in locales/*/translation.json
// ============================================================

export const INCOME_CATEGORY_KEYS: Record<string, string> = {
  "Salary & Allowances": "salaryAllowances",
  "Business / Self-Employed": "businessSelfEmployed",
  "Rental Income": "rentalIncome",
  "Investments & Financial Gains": "investmentsFinancialGains",
  "Asset Sales": "assetSales",
  "Gifts & Transfers": "giftsTransfers",
  "Refunds / Reimbursements": "refundsReimbursements",
  "Other": "other",
};

// ============================================================
// EXPENSE CATEGORY ICONS (for ImportScreen and other UIs)
// Maps lowercase category name to Feather icon name
// ============================================================

export const EXPENSE_CATEGORY_ICONS: Record<string, string> = {
  "food & dining": "coffee",
  "groceries": "shopping-cart",
  "housing": "home",
  "utilities": "zap",
  "transportation": "truck",
  "shopping": "shopping-bag",
  "kids & pets": "users",
  "health & fitness": "activity",
  "entertainment": "film",
  "subscriptions & apps": "play-circle",
  "travel": "navigation",
  "financial": "dollar-sign",
  "payment & transfers": "credit-card",
  "taxes & government": "file-text",
  "education": "book",
  "gifts & donations": "gift",
  "home maintenance": "tool",
  "other": "more-horizontal",
};

// ============================================================
// INCOME CATEGORY ICONS (for ImportScreen and other UIs)
// Maps lowercase category name to Feather icon name
// ============================================================

export const INCOME_CATEGORY_ICONS: Record<string, string> = {
  "salary & allowances": "dollar-sign",
  "business / self-employed": "trending-up",
  "rental income": "home",
  "investments & financial gains": "pie-chart",
  "asset sales": "package",
  "gifts & transfers": "gift",
  "refunds / reimbursements": "rotate-ccw",
  "other": "more-horizontal",
};

// ============================================================
// GROUP TITLE KEYS (for translations)
// Maps group title to translation key
// ============================================================

export const EXPENSE_GROUP_TITLE_KEYS: Record<string, string> = {
  "Food & Dining": "foodDining",
  "Housing & Utilities": "housingUtilities",
  "Transportation": "transportation",
  "Shopping": "shopping",
  "Health & Fitness": "healthFitness",
  "Entertainment & Leisure": "entertainmentLeisure",
  "Financial": "financial",
  "Other": "other",
};

export const INCOME_GROUP_TITLE_KEYS: Record<string, string> = {
  "Employment": "employment",
  "Business & Self-Employed": "businessSelfEmployed",
  "Property & Rental": "propertyRental",
  "Investments & Returns": "investmentsReturns",
  "Gifts & Transfers": "giftsTransfers",
  "Refunds & Adjustments": "refundsAdjustments",
  "Other": "other",
};

// ============================================================
// FLAT CATEGORY ARRAYS (for AI prompts)
// ============================================================

export const EXPENSE_CATEGORIES_FLAT = EXPENSE_CATEGORY_GROUPS.flatMap(
  group => group.categories.map(cat => cat.name)
) as readonly string[];

export const INCOME_CATEGORIES_FLAT = INCOME_CATEGORY_GROUPS.flatMap(
  group => group.categories.map(cat => cat.name)
) as readonly string[];

export const VALID_EXPENSE_CATEGORY_SET: ReadonlySet<string> = new Set(EXPENSE_CATEGORIES_FLAT);
export const VALID_INCOME_CATEGORY_SET: ReadonlySet<string> = new Set(INCOME_CATEGORIES_FLAT);

export const DEFAULT_EXPENSE_CATEGORY: string = "Other";
export const DEFAULT_INCOME_CATEGORY: string = "Other";

export function isValidExpenseCategory(name: string): boolean {
  return VALID_EXPENSE_CATEGORY_SET.has(name);
}

export function isValidIncomeCategory(name: string): boolean {
  return VALID_INCOME_CATEGORY_SET.has(name);
}

// ============================================================
// EXPENSE GROUP TITLES (for dropdowns)
// ============================================================

export const EXPENSE_GROUP_TITLES: string[] = EXPENSE_CATEGORY_GROUPS.map(g => g.title);

export const INCOME_GROUP_TITLES: string[] = INCOME_CATEGORY_GROUPS.map(g => g.title);

// ============================================================
// CATEGORIES WITH SUBCATEGORIES (for merchant expansion)
// ============================================================

export const EXPENSE_CATEGORIES_WITH_SUBCATEGORIES: CategoryWithSubcategories[] = [
  { category: "Food & Dining", subcategories: ["Restaurant", "Fast Food", "Cafe", "Food Delivery", "Coffee Shop", "Bakery"] },
  { category: "Groceries", subcategories: ["Supermarket", "Hypermarket", "Convenience Store"] },
  { category: "Housing", subcategories: ["Rent", "Mortgage", "Home Loan"] },
  { category: "Utilities", subcategories: ["Electricity", "Water", "Gas", "Mobile Bill", "Internet Bill", "Telecom"] },
  { category: "Transportation", subcategories: ["Petrol Station", "Gas Station", "Taxi/Ride-hailing", "Limousine", "Airport Transfer", "Metro", "Bus", "Train", "Toll", "Car Maintenance", "Parking", "Car Loan", "Auto Lease", "Car Insurance"] },
  { category: "Shopping", subcategories: ["Fashion", "Electronics", "Home & Living", "Online Shopping", "Clothing", "Home & Garden", "Laundry & Dry Cleaning"] },
  { category: "Kids & Pets", subcategories: ["Childcare", "Pet", "Kids' Items", "Pet Supplies"] },
  { category: "Health & Fitness", subcategories: ["Hospital", "Clinic", "Dental", "Salon", "Spa", "Beauty", "Pharmacy", "Medication", "Prescription", "Gym", "Fitness Center", "Yoga", "Pilates"] },
  { category: "Entertainment", subcategories: ["Cinema", "Games", "Events", "Concerts", "Hobbies", "Sports"] },
  { category: "Subscriptions & Apps", subcategories: ["Streaming", "Software", "Membership", "App Subscription"] },
  { category: "Travel", subcategories: ["Airline", "Hotel", "Travel Agency", "Booking", "Vacation"] },
  { category: "Financial", subcategories: ["ATM Fee", "Service Charge", "Late Fee", "Loan Repayment", "Health Insurance", "Car Insurance", "Life Insurance"] },
  { category: "Payment & Transfers", subcategories: ["Credit Card Payment", "Bank Transfer", "Wire Transfer"] },
  { category: "Taxes & Government", subcategories: ["Income Tax", "Property Tax", "Sales Tax", "VAT", "License Fee", "Permit Fee", "Visa Fee", "Registration Fee"] },
  { category: "Education", subcategories: ["School", "University", "Training", "Online Course", "Certification"] },
  { category: "Gifts & Donations", subcategories: ["Donation", "Zakat", "Charity"] },
  { category: "Home Maintenance", subcategories: ["Plumbing", "Electrical", "Housekeeping", "Landscaping"] },
];

export const INCOME_CATEGORIES_WITH_SUBCATEGORIES: CategoryWithSubcategories[] = [
  { category: "Salary & Allowances", subcategories: ["Monthly Salary", "Bonus", "Commission", "Overtime", "Pension", "Allowance", "Severance"] },
  { category: "Business / Self-Employed", subcategories: ["Freelance", "Consulting", "Contract Work", "Side Hustle", "Business Revenue", "Royalties"] },
  { category: "Rental Income", subcategories: ["Long-term Rental", "Short-term Rental", "Property Lease", "Subletting"] },
  { category: "Investments & Financial Gains", subcategories: ["Dividends", "Interest", "Capital Gains", "Stock Sale", "Crypto Gains", "Profit Share"] },
  { category: "Asset Sales", subcategories: ["Property Sale", "Vehicle Sale", "Equipment Sale", "Personal Item Sale"] },
  { category: "Gifts & Transfers", subcategories: ["Gift Received", "Inheritance", "Family Transfer", "Zakat Received"] },
  { category: "Refunds / Reimbursements", subcategories: ["Purchase Refund", "Insurance Claim", "Tax Refund", "Expense Reimbursement", "Cashback", "Rewards"] },
  { category: "Other", subcategories: ["Government Benefit", "Scholarship", "Grant", "Prize", "Lottery", "Found Money"] },
];

// ============================================================
// SEED CATEGORIES (for database seeding)
// ============================================================

export const EXPENSE_SEED_CATEGORIES: SeedCategory[] = (() => {
  let order = 1;
  return EXPENSE_CATEGORY_GROUPS.flatMap(group =>
    group.categories.map(cat => ({
      name: cat.name,
      icon: cat.icon,
      groupName: group.title,
      displayOrder: order++,
    }))
  );
})();

export const INCOME_SEED_CATEGORIES: SeedCategory[] = (() => {
  let order = 1;
  return INCOME_CATEGORY_GROUPS.flatMap(group =>
    group.categories.map(cat => ({
      name: cat.name,
      icon: cat.icon,
      groupName: group.title,
      displayOrder: order++,
    }))
  );
})();

// ============================================================
// HELPER FUNCTIONS
// ============================================================

export function getExpenseCategoryIcon(categoryName: string): string {
  const key = categoryName.toLowerCase();
  return EXPENSE_CATEGORY_ICONS[key] || "more-horizontal";
}

export function getIncomeCategoryIcon(categoryName: string): string {
  const key = categoryName.toLowerCase();
  return INCOME_CATEGORY_ICONS[key] || "more-horizontal";
}

export function getCategoryIcon(categoryName: string, type: "expense" | "income"): string {
  return type === "expense" 
    ? getExpenseCategoryIcon(categoryName) 
    : getIncomeCategoryIcon(categoryName);
}
