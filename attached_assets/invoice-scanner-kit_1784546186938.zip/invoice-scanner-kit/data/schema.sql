-- Standalone schema for the invoice-scanner kit.
-- Only the merchant/category tables the matcher pipeline needs — no
-- users/households coupling. `user_id` columns are plain text; add a
-- foreign key to your own users table if desired.

-- Global merchant database (seeded from the CSVs in this folder,
-- grown over time by AI enrichment).
CREATE TABLE IF NOT EXISTS global_merchant_categories (
  id SERIAL PRIMARY KEY,
  merchant_id TEXT NOT NULL UNIQUE,
  merchant_name TEXT NOT NULL,
  normalized_name TEXT NOT NULL,
  variant TEXT,                          -- semicolon-separated raw-text variants
  category_group TEXT NOT NULL,
  category TEXT,
  subcategory TEXT,
  region TEXT DEFAULT 'global',
  confidence DECIMAL(3, 2) DEFAULT 1.00,
  source TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS global_merchant_normalized_idx
  ON global_merchant_categories (LOWER(normalized_name));

-- Per-user merchant → category corrections (tier 1 of the matcher).
CREATE TABLE IF NOT EXISTS merchant_category_mappings (
  id SERIAL PRIMARY KEY,
  user_id TEXT NOT NULL,
  normalized_merchant TEXT NOT NULL,
  display_merchant TEXT NOT NULL,
  category TEXT NOT NULL,
  category_icon TEXT,
  transaction_type TEXT NOT NULL DEFAULT 'expense',
  subcategory TEXT,
  use_count INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS merchant_cat_mappings_user_idx
  ON merchant_category_mappings (user_id);

-- Merchants that fell through every tier — feed these into AI enrichment.
CREATE TABLE IF NOT EXISTS unmatched_merchants (
  id SERIAL PRIMARY KEY,
  raw_merchant_text TEXT NOT NULL UNIQUE,
  normalized_merchant_text TEXT NOT NULL,
  region TEXT,
  first_seen_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_seen_at TIMESTAMP NOT NULL DEFAULT NOW(),
  count INTEGER NOT NULL DEFAULT 1
);
