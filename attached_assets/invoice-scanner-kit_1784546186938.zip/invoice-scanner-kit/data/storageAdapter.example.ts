/**
 * Example Postgres implementation of the MerchantStorage interface using
 * the `pg` driver directly (swap in Drizzle/Prisma as you prefer).
 *
 * Wire-up:
 *   const pool = new Pool({ connectionString: process.env.DATABASE_URL });
 *   const storage = new PgMerchantStorage(pool);
 *   const result = await matchMerchant(storage, "TESCO EXPRESS 1234 LONDON");
 */

import type { Pool } from "pg";
import type {
  MerchantStorage,
  GlobalMerchantRecord,
  UserMerchantMapping,
  UnmatchedMerchantEntry,
} from "../code/storage";

export class PgMerchantStorage implements MerchantStorage {
  constructor(private pool: Pool) {}

  async listGlobalMerchants(): Promise<GlobalMerchantRecord[]> {
    const { rows } = await this.pool.query(
      `SELECT merchant_id, merchant_name, normalized_name, variant,
              category_group, category, subcategory, region, confidence, source
       FROM global_merchant_categories`
    );
    return rows.map(mapRow);
  }

  async findGlobalMerchantByNormalizedName(normalizedName: string): Promise<GlobalMerchantRecord | null> {
    const { rows } = await this.pool.query(
      `SELECT merchant_id, merchant_name, normalized_name, variant,
              category_group, category, subcategory, region, confidence, source
       FROM global_merchant_categories
       WHERE LOWER(normalized_name) = LOWER($1)
       LIMIT 1`,
      [normalizedName]
    );
    return rows.length ? mapRow(rows[0]) : null;
  }

  async findUserMapping(userId: string, normalizedMerchant: string): Promise<UserMerchantMapping | null> {
    const { rows } = await this.pool.query(
      `SELECT user_id, normalized_merchant, display_merchant, category,
              subcategory, category_icon, transaction_type, use_count
       FROM merchant_category_mappings
       WHERE user_id = $1 AND LOWER(normalized_merchant) = LOWER($2)
       ORDER BY use_count DESC
       LIMIT 1`,
      [userId, normalizedMerchant]
    );
    if (!rows.length) return null;
    const r = rows[0];
    return {
      userId: r.user_id,
      normalizedMerchant: r.normalized_merchant,
      displayMerchant: r.display_merchant,
      category: r.category,
      subcategory: r.subcategory,
      categoryIcon: r.category_icon,
      transactionType: r.transaction_type,
      useCount: r.use_count,
    };
  }

  async logUnmatchedMerchant(entry: UnmatchedMerchantEntry): Promise<void> {
    await this.pool.query(
      `INSERT INTO unmatched_merchants (raw_merchant_text, normalized_merchant_text, region, count)
       VALUES ($1, $2, $3, 1)
       ON CONFLICT (raw_merchant_text)
       DO UPDATE SET count = unmatched_merchants.count + 1, last_seen_at = NOW()`,
      [entry.rawMerchantText, entry.normalizedMerchantText, entry.region]
    );
  }

  async insertGlobalMerchant(record: GlobalMerchantRecord): Promise<boolean> {
    const result = await this.pool.query(
      `INSERT INTO global_merchant_categories
         (merchant_id, merchant_name, normalized_name, variant, category_group,
          category, subcategory, region, confidence, source)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT (merchant_id) DO NOTHING`,
      [
        record.merchantId,
        record.merchantName,
        record.normalizedName,
        record.variant,
        record.categoryGroup,
        record.category,
        record.subcategory,
        record.region,
        record.confidence,
        record.source,
      ]
    );
    return (result.rowCount || 0) > 0;
  }

  async updateGlobalMerchantCategoryIfEmpty(
    normalizedName: string,
    category: string,
    categoryGroup: string,
    subcategory: string | null
  ): Promise<number> {
    const result = await this.pool.query(
      `UPDATE global_merchant_categories
       SET category = $2,
           category_group = $3,
           subcategory = COALESCE($4, subcategory),
           updated_at = NOW()
       WHERE LOWER(normalized_name) = LOWER($1)
         AND (category IS NULL OR category = '')`,
      [normalizedName, category, categoryGroup, subcategory]
    );
    return result.rowCount || 0;
  }
}

function mapRow(r: any): GlobalMerchantRecord {
  return {
    merchantId: r.merchant_id,
    merchantName: r.merchant_name,
    normalizedName: r.normalized_name,
    variant: r.variant,
    categoryGroup: r.category_group,
    category: r.category,
    subcategory: r.subcategory,
    region: r.region,
    confidence: Number(r.confidence) || 0.9,
    source: r.source,
  };
}
