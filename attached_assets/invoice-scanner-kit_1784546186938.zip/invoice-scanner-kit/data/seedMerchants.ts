/**
 * Merchant database seed script.
 *
 * Loads the two CSVs in this folder into `global_merchant_categories`:
 *   - merchants_north_america.csv  (pipe-separated variants, quoted columns:
 *       brand_id, normalized_brand_name, merchant_name_variations, category,
 *       subcategory, country_codes, region, is_global, primary_market)
 *   - merchants_eu.csv             (semicolon-separated variants:
 *       merchant_id, merchant_name, normalized_name, variant, category_group,
 *       category, region, confidence, source)
 *
 * Usage:
 *   DATABASE_URL=postgres://... npx tsx data/seedMerchants.ts
 *   (apply data/schema.sql first)
 *
 * Requires: pg, csv-parse
 */

import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { parse } from "csv-parse/sync";
import { Pool } from "pg";

const __dirname = dirname(fileURLToPath(import.meta.url));

interface SeedRow {
  merchantId: string;
  merchantName: string;
  normalizedName: string;
  variant: string | null;
  categoryGroup: string;
  category: string | null;
  subcategory: string | null;
  region: string | null;
  confidence: number;
  source: string;
}

function normalizeName(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\b\d{4,}\b/g, "")
    .replace(/[^\w\s*]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function loadNorthAmericaCsv(path: string): SeedRow[] {
  const records: Record<string, string>[] = parse(readFileSync(path, "utf8"), {
    columns: true,
    skip_empty_lines: true,
  });

  return records.map(r => ({
    merchantId: `NA_${r.brand_id}`,
    merchantName: r.normalized_brand_name,
    normalizedName: normalizeName(r.normalized_brand_name),
    // NA file uses pipe-separated variants; store semicolon-separated
    // (the format tokenMatcher.ts expects).
    variant: (r.merchant_name_variations || "")
      .split("|")
      .map(v => v.trim())
      .filter(Boolean)
      .join("; ") || null,
    categoryGroup: r.category,
    category: r.category || null,
    subcategory: r.subcategory || null,
    region: r.primary_market || r.region || "NA",
    confidence: 0.95,
    source: "seed_north_america",
  }));
}

function loadEuCsv(path: string): SeedRow[] {
  const records: Record<string, string>[] = parse(readFileSync(path, "utf8"), {
    columns: true,
    skip_empty_lines: true,
    relax_quotes: true,
  });

  return records.map(r => ({
    merchantId: `EU_${r.merchant_id}`,
    merchantName: r.merchant_name,
    normalizedName: r.normalized_name || normalizeName(r.merchant_name),
    variant: r.variant || null,
    categoryGroup: r.category_group,
    category: r.category || null,
    subcategory: null,
    region: r.region || "EU",
    confidence: Number(r.confidence) || 0.9,
    source: r.source || "seed_eu",
  }));
}

async function insertBatch(pool: Pool, rows: SeedRow[]): Promise<number> {
  let inserted = 0;
  const BATCH = 500;

  for (let i = 0; i < rows.length; i += BATCH) {
    const batch = rows.slice(i, i + BATCH);
    const values: unknown[] = [];
    const placeholders: string[] = [];

    batch.forEach((r, idx) => {
      const base = idx * 10;
      placeholders.push(
        `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4}, $${base + 5}, $${base + 6}, $${base + 7}, $${base + 8}, $${base + 9}, $${base + 10})`
      );
      values.push(
        r.merchantId,
        r.merchantName,
        r.normalizedName,
        r.variant,
        r.categoryGroup,
        r.category,
        r.subcategory,
        r.region,
        r.confidence,
        r.source
      );
    });

    const result = await pool.query(
      `INSERT INTO global_merchant_categories
         (merchant_id, merchant_name, normalized_name, variant, category_group,
          category, subcategory, region, confidence, source)
       VALUES ${placeholders.join(", ")}
       ON CONFLICT (merchant_id) DO NOTHING`,
      values
    );
    inserted += result.rowCount || 0;

    if ((i / BATCH) % 20 === 0) {
      console.log(`  ...${Math.min(i + BATCH, rows.length)}/${rows.length}`);
    }
  }

  return inserted;
}

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL is required");
    process.exit(1);
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });

  try {
    console.log("Loading North America merchants...");
    const na = loadNorthAmericaCsv(join(__dirname, "merchants_north_america.csv"));
    console.log(`  parsed ${na.length} rows`);
    const naInserted = await insertBatch(pool, na);
    console.log(`  inserted ${naInserted}`);

    console.log("Loading EU merchants (large file, may take a few minutes)...");
    const eu = loadEuCsv(join(__dirname, "merchants_eu.csv"));
    console.log(`  parsed ${eu.length} rows`);
    const euInserted = await insertBatch(pool, eu);
    console.log(`  inserted ${euInserted}`);

    console.log("Seed complete.");
  } finally {
    await pool.end();
  }
}

main().catch(err => {
  console.error("Seed failed:", err);
  process.exit(1);
});
