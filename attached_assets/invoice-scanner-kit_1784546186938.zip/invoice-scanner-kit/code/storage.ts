/**
 * Thin storage interface for the invoice-scanner kit.
 *
 * The original code queried Postgres directly through Drizzle ORM.
 * All database access is funneled through this interface instead, so you can
 * back it with any store (Drizzle, Prisma, raw SQL, or the in-memory
 * implementation below for tests / small deployments).
 *
 * See data/schema.sql for the reference table definitions.
 */

export interface GlobalMerchantRecord {
  merchantId: string;
  merchantName: string;
  normalizedName: string;
  /** Semicolon-separated raw transaction-text variants, e.g. "TESCO EXPRESS; TESCO PLC" */
  variant: string | null;
  categoryGroup: string;
  category: string | null;
  subcategory: string | null;
  region: string | null;
  confidence: number;
  source: string | null;
}

export interface UserMerchantMapping {
  userId: string;
  normalizedMerchant: string;
  displayMerchant: string;
  category: string;
  subcategory: string | null;
  categoryIcon: string | null;
  transactionType: string;
  useCount: number;
}

export interface UnmatchedMerchantEntry {
  rawMerchantText: string;
  normalizedMerchantText: string;
  region: string | null;
}

export interface MerchantStorage {
  /** All merchant rows used to build the in-memory fuzzy-match index. */
  listGlobalMerchants(): Promise<GlobalMerchantRecord[]>;

  /** Exact (case-insensitive) lookup by normalized merchant name. */
  findGlobalMerchantByNormalizedName(normalizedName: string): Promise<GlobalMerchantRecord | null>;

  /** Highest-useCount user-specific mapping for a normalized merchant, or null. */
  findUserMapping(userId: string, normalizedMerchant: string): Promise<UserMerchantMapping | null>;

  /** Record an unmatched merchant for future training (upsert: bump count on repeat). */
  logUnmatchedMerchant(entry: UnmatchedMerchantEntry): Promise<void>;

  /** Insert an AI-enriched merchant. Must be a no-op if merchantId already exists. Returns true if inserted. */
  insertGlobalMerchant(record: GlobalMerchantRecord): Promise<boolean>;

  /** Fill in category/categoryGroup on rows whose category is NULL/empty, matched by normalized name. Returns rows updated. */
  updateGlobalMerchantCategoryIfEmpty(
    normalizedName: string,
    category: string,
    categoryGroup: string,
    subcategory: string | null,
  ): Promise<number>;
}

/**
 * In-memory reference implementation. Useful for unit tests and for getting
 * the pipeline running before wiring a real database.
 */
export class InMemoryMerchantStorage implements MerchantStorage {
  private merchants = new Map<string, GlobalMerchantRecord>();
  private userMappings: UserMerchantMapping[] = [];
  private unmatched = new Map<string, { entry: UnmatchedMerchantEntry; count: number }>();

  constructor(seed: GlobalMerchantRecord[] = []) {
    for (const m of seed) this.merchants.set(m.merchantId, m);
  }

  addUserMapping(mapping: UserMerchantMapping): void {
    this.userMappings.push(mapping);
  }

  async listGlobalMerchants(): Promise<GlobalMerchantRecord[]> {
    return Array.from(this.merchants.values());
  }

  async findGlobalMerchantByNormalizedName(normalizedName: string): Promise<GlobalMerchantRecord | null> {
    const target = normalizedName.toLowerCase();
    for (const m of this.merchants.values()) {
      if (m.normalizedName.toLowerCase() === target) return m;
    }
    return null;
  }

  async findUserMapping(userId: string, normalizedMerchant: string): Promise<UserMerchantMapping | null> {
    const matches = this.userMappings
      .filter(m => m.userId === userId && m.normalizedMerchant.toLowerCase() === normalizedMerchant.toLowerCase())
      .sort((a, b) => b.useCount - a.useCount);
    return matches[0] ?? null;
  }

  async logUnmatchedMerchant(entry: UnmatchedMerchantEntry): Promise<void> {
    const existing = this.unmatched.get(entry.rawMerchantText);
    if (existing) {
      existing.count += 1;
    } else {
      this.unmatched.set(entry.rawMerchantText, { entry, count: 1 });
    }
  }

  async insertGlobalMerchant(record: GlobalMerchantRecord): Promise<boolean> {
    if (this.merchants.has(record.merchantId)) return false;
    this.merchants.set(record.merchantId, record);
    return true;
  }

  async updateGlobalMerchantCategoryIfEmpty(
    normalizedName: string,
    category: string,
    categoryGroup: string,
    subcategory: string | null,
  ): Promise<number> {
    let updated = 0;
    const target = normalizedName.toLowerCase();
    for (const m of this.merchants.values()) {
      if (m.normalizedName.toLowerCase() === target && (!m.category || m.category === "")) {
        m.category = category;
        m.categoryGroup = categoryGroup;
        if (subcategory) m.subcategory = subcategory;
        updated++;
      }
    }
    return updated;
  }
}
