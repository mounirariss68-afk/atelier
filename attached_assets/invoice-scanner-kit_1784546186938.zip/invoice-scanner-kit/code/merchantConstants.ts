export const PAYMENT_PREFIXES = new Set([
  "sp", "sq", "pp", "nfc", "pos", "atm", "txw", "pmt", "pymt", "pym",
  "izettle", "sumup", "zettle", "visa", "mc", "mastercard", "amex",
  "google", "apple", "samsung", "contactless", "tap", "imp", "iap",
  "mpos", "eftpos",
]);

export const LOCATION_SUFFIXES = new Set([
  "ae", "uae", "dubai", "abudhabi", "dhabi", "sharjah", "ajman", "fujairah",
  "rak", "quwain", "dxb",
  "uk", "gbr", "gb", "usa", "us", "london", "lnd", "ldn", "ny", "nyc", "la",
  "singapore", "sg", "sgp",
  "ksa", "sau", "saudi", "riyadh", "jeddah", "qatar", "qat", "doha", "bahrain", "bhr", "manama",
  "kuwait", "kwt", "oman", "omn", "muscat", "egypt", "egy", "cairo", "india", "ind", "mumbai", "delhi",
  "turkey", "tur", "istanbul", "ankara", "germany", "deu", "ger", "berlin", "france", "fra", "paris",
  "italy", "ita", "rome", "milan", "spain", "esp", "madrid", "barcelona",
  "netherlands", "nld", "amsterdam", "belgium", "bel", "brussels",
  "switzerland", "che", "zurich", "geneva", "austria", "aut", "vienna",
  "portugal", "prt", "lisbon", "ireland", "irl", "dublin",
  "scotland", "glasgow", "edinburgh", "wales", "cardiff",
  "dover", "fitzrovia", "westbourne", "oxford",
  "online", "mobile", "web", "terminal",
]);

export const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "of", "in", "at", "to", "for", "on", "by",
  "llc", "ltd", "inc", "co", "corp", "fzc", "fze", "fzco", "dmcc", "jlt",
  "plc", "wll", "pjsc", "psc", "est", "establishment",
  "enterprises", "services", "solutions", "holdings", "international", "intl",
  "pvt", "private", "limited", "company", "trading", "general", "group",
  "branch", "store", "shop", "outlet", "center", "centre",
]);

export const LEADING_CITY_NAMES = [
  "Dubai", "Riyadh", "Jeddah", "Abu Dhabi", "Sharjah", "Ajman",
  "Doha", "Manama", "Muscat", "Kuwait City",
  "London", "Amsterdam", "Paris", "Berlin", "Madrid", "Rome",
  "Zurich", "Geneva", "Brussels", "Frankfurt", "Vienna", "Lisbon",
  "Dublin", "Glasgow", "Edinburgh", "Manchester", "Birmingham",
  "Istanbul", "Ankara", "Singapore", "New York", "Los Angeles",
  "Toronto", "Sydney", "Melbourne", "Tokyo",
];

export const TRAILING_CITY_NAMES = [
  ...LEADING_CITY_NAMES,
  "Dover", "Fitzrovia", "Westbourne", "Oxford",
  "Leeds", "Liverpool", "Cardiff", "Warsaw", "Oslo",
  "Stockholm", "Copenhagen", "Helsinki",
];

export const COUNTRY_CODES = [
  "ARE", "SAU", "UAE", "GBR", "SGP", "DXB",
  "NLD", "DEU", "FRA", "ITA", "ESP", "CHE", "BEL",
  "AUT", "PRT", "IRL", "POL", "NOR", "SWE", "DNK", "FIN",
  "USA", "CAN", "AUS", "NZL", "JPN", "CHN", "HKG",
  "AE", "SA", "FR", "IT", "US", "GB",
];
