import {
  PAYMENT_PREFIXES,
  LOCATION_SUFFIXES,
  STOPWORDS,
} from "./merchantConstants";

export function normalizeMerchant(text: string): string {
  if (!text) return "";
  
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\b\d{4,}\b/g, "")
    .replace(/[^\w\s*]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function extractCoreMerchant(text: string): string {
  if (!text) return "";
  
  let normalized = text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\b\d+\b/g, "")
    .replace(/[#*\-_.,:;()[\]{}'"!@$%^&+=|\\/<>]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  
  const tokens = normalized.split(" ");
  
  let startIdx = 0;
  while (startIdx < tokens.length && PAYMENT_PREFIXES.has(tokens[startIdx])) {
    startIdx++;
  }
  
  const filtered = tokens.slice(startIdx).filter(t => 
    t.length > 1 && 
    !LOCATION_SUFFIXES.has(t) && 
    !STOPWORDS.has(t) &&
    !PAYMENT_PREFIXES.has(t)
  );
  
  return filtered.join(" ");
}

export function tokenize(text: string): string[] {
  if (!text) return [];
  
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\w\s]/g, " ")
    .split(/\s+/)
    .filter(t => t.length > 1);
}

export function extractSignificantTokens(text: string): string[] {
  const tokens = tokenize(text);
  return tokens.filter(t => 
    !LOCATION_SUFFIXES.has(t) && 
    !STOPWORDS.has(t) &&
    !/^\d+$/.test(t)
  );
}

export function generateBigrams(tokens: string[]): string[] {
  if (tokens.length < 2) return [];
  const bigrams: string[] = [];
  for (let i = 0; i < tokens.length - 1; i++) {
    bigrams.push(`${tokens[i]}_${tokens[i + 1]}`);
  }
  return bigrams;
}
