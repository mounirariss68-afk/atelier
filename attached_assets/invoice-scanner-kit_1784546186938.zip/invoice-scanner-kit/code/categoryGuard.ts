import {
  EXPENSE_CATEGORIES_FLAT,
  INCOME_CATEGORIES_FLAT,
  isValidExpenseCategory,
  isValidIncomeCategory,
  DEFAULT_EXPENSE_CATEGORY,
  DEFAULT_INCOME_CATEGORY,
  EXPENSE_CATEGORIES_WITH_SUBCATEGORIES,
  INCOME_CATEGORIES_WITH_SUBCATEGORIES,
} from "../config/categories";
export type SourceOfTruthExpenseCategory = typeof EXPENSE_CATEGORIES_FLAT[number];
export type SourceOfTruthIncomeCategory = typeof INCOME_CATEGORIES_FLAT[number];

const EXPENSE_CATEGORY_ALIASES: Record<string, SourceOfTruthExpenseCategory> = {
  "fees & charges": "Financial",
  "bank fees & charges": "Financial",
  "fees and charges": "Financial",
  "bank charges": "Financial",
  "banking fees": "Financial",
  "banking & payments": "Financial",
  "credit cards": "Financial",
  "loans": "Financial",
  "trading & crypto": "Financial",
  "atm fee": "Financial",
  "service charge": "Financial",
  "late fee": "Financial",
  "bank fee": "Financial",
  "bank fees": "Financial",
  "bank service fee": "Financial",
  "overdraft fee": "Financial",
  "wire transfer fee": "Financial",
  "annual fee": "Financial",
  "monthly fee": "Financial",
  "transaction fee": "Financial",
  "account fee": "Financial",
  "account maintenance fee": "Financial",
  "investments": "Financial",
  "other financial": "Financial",
  "other financial expenses": "Financial",
  "financial expenses": "Financial",
  "transfer": "Financial",
  "transfers": "Financial",
  "loan": "Financial",
  "loan payment": "Financial",
  "loan repayment": "Financial",
  "loan repayments": "Financial",
  "debt payment": "Financial",
  "emi": "Financial",
  "insurance": "Financial",
  "health insurance": "Financial",
  "car insurance": "Financial",
  "life insurance": "Financial",
  "insurance premium": "Financial",
  "insurance payment": "Financial",
  "auto insurance": "Financial",
  "home insurance": "Financial",
  "loans & insurance": "Financial",

  "pharmacy": "Health & Fitness",
  "pharmacy / medication": "Health & Fitness",
  "medication": "Health & Fitness",
  "prescription": "Health & Fitness",
  "medical": "Health & Fitness",
  "health": "Health & Fitness",
  "doctor": "Health & Fitness",
  "healthcare": "Health & Fitness",
  "healthcare / medical": "Health & Fitness",
  "hospital": "Health & Fitness",
  "clinic": "Health & Fitness",
  "dental": "Health & Fitness",
  "medical expenses": "Health & Fitness",
  "health expenses": "Health & Fitness",
  "doctor visit": "Health & Fitness",
  "medical bill": "Health & Fitness",
  "health care": "Health & Fitness",
  "wellness & therapy": "Health & Fitness",
  "salon & spa": "Health & Fitness",
  "salon": "Health & Fitness",
  "spa": "Health & Fitness",
  "barber": "Health & Fitness",
  "massage": "Health & Fitness",
  "beauty": "Health & Fitness",
  "beauty salon": "Health & Fitness",
  "hair salon": "Health & Fitness",
  "nail salon": "Health & Fitness",
  "spa & wellness": "Health & Fitness",
  "personal care": "Health & Fitness",
  "beauty & personal care": "Health & Fitness",
  "personal grooming": "Health & Fitness",
  "gym membership": "Health & Fitness",
  "gym": "Health & Fitness",
  "fitness": "Health & Fitness",
  "sports": "Health & Fitness",
  "gym & fitness": "Health & Fitness",
  "fitness & gym": "Health & Fitness",
  "sports & fitness": "Health & Fitness",
  "fitness center": "Health & Fitness",
  "sports club": "Health & Fitness",

  "restaurant": "Food & Dining",
  "restaurants": "Food & Dining",
  "dining": "Food & Dining",
  "dining / eating out": "Food & Dining",
  "eating out": "Food & Dining",
  "takeout": "Food & Dining",
  "food delivery": "Food & Dining",
  "fast food": "Food & Dining",
  "restaurant bill": "Food & Dining",
  "food & drink": "Food & Dining",
  "food & drinks": "Food & Dining",
  "food and drink": "Food & Dining",
  "food and drinks": "Food & Dining",
  "restaurant & bar": "Food & Dining",
  "restaurants & bars": "Food & Dining",
  "dining out": "Food & Dining",
  "dine out": "Food & Dining",
  "restaurant expenses": "Food & Dining",
  "bars & pubs": "Food & Dining",
  "alcohol & bars": "Food & Dining",
  "alcohol": "Food & Dining",
  "bar": "Food & Dining",
  "bars": "Food & Dining",
  "pub": "Food & Dining",
  "pubs": "Food & Dining",
  "nightclub": "Food & Dining",
  "brewery": "Food & Dining",
  "wine bar": "Food & Dining",
  "coffee": "Food & Dining",
  "cafe": "Food & Dining",
  "café": "Food & Dining",
  "snacks": "Food & Dining",
  "coffee & tea": "Food & Dining",
  "coffee shop": "Food & Dining",
  "coffee & snacks": "Food & Dining",

  "food": "Groceries",
  "supermarket": "Groceries",
  "grocery": "Groceries",
  "groceries & supermarket": "Groceries",
  "bakeries": "Groceries",
  "hypermarket": "Groceries",
  "convenience store": "Groceries",
  "grocery store": "Groceries",
  "grocery shopping": "Groceries",
  "food shopping": "Groceries",

  "rent": "Housing",
  "housing - rent": "Housing",
  "rent payment": "Housing",
  "monthly rent": "Housing",
  "house rent": "Housing",
  "apartment rent": "Housing",
  "mortgage": "Housing",
  "housing - mortgage": "Housing",
  "mortgage payment": "Housing",
  "home loan": "Housing",
  "rent / mortgage": "Housing",

  "bills": "Utilities",
  "electric": "Utilities",
  "electricity": "Utilities",
  "utilities": "Utilities",
  "utility bills": "Utilities",
  "power & water": "Utilities",
  "water": "Utilities",
  "electric bill": "Utilities",
  "electricity bill": "Utilities",
  "water bill": "Utilities",
  "gas bill": "Utilities",
  "utility": "Utilities",
  "internet": "Utilities",
  "phone": "Utilities",
  "mobile": "Utilities",
  "internet & mobile": "Utilities",
  "internet & phone": "Utilities",
  "phone & internet": "Utilities",
  "telecom": "Utilities",
  "mobile bill": "Utilities",
  "internet bill": "Utilities",
  "phone bill": "Utilities",
  "mobile phone": "Utilities",
  "cell phone": "Utilities",
  "telecommunications": "Utilities",

  "transport": "Transportation",
  "transit": "Transportation",
  "transportation": "Transportation",
  "public transportation": "Transportation",
  "public transport": "Transportation",
  "public transit": "Transportation",
  "bus": "Transportation",
  "metro": "Transportation",
  "subway": "Transportation",
  "train": "Transportation",
  "uber": "Transportation",
  "taxi": "Transportation",
  "taxi & rideshare": "Transportation",
  "ride hailing & taxis": "Transportation",
  "taxi/ride-hailing": "Transportation",
  "ride-hailing": "Transportation",
  "ride hailing": "Transportation",
  "rideshare": "Transportation",
  "ride share": "Transportation",
  "cab": "Transportation",
  "lyft": "Transportation",
  "car rental": "Transportation",
  "auto repair": "Transportation",
  "car repair": "Transportation",
  "car service": "Transportation",
  "vehicle maintenance": "Transportation",
  "car maintenance": "Transportation",
  "parking": "Transportation",
  "parking & tolls": "Transportation",
  "toll": "Transportation",
  "tolls": "Transportation",
  "parking fee": "Transportation",
  "parking fees": "Transportation",
  "road toll": "Transportation",
  "car financing": "Transportation",
  "car lease": "Transportation",
  "auto loan": "Transportation",
  "car loan": "Transportation",
  "auto lease": "Transportation",
  "car financing / leasing": "Transportation",
  "vehicle financing": "Transportation",
  "car payment": "Transportation",
  "vehicle lease": "Transportation",
  "car & parking": "Transportation",
  "gas": "Transportation",
  "petrol": "Transportation",
  "fuel": "Transportation",
  "fuel & gas": "Transportation",
  "gas & fuel": "Transportation",
  "petrol station": "Transportation",
  "gas station": "Transportation",
  "diesel": "Transportation",
  "fuel expenses": "Transportation",

  "movies": "Entertainment",
  "cinema": "Entertainment",
  "movies & cinema": "Entertainment",
  "events & concerts": "Entertainment",
  "attractions": "Entertainment",
  "events": "Entertainment",
  "games": "Entertainment",
  "concert": "Entertainment",
  "concerts": "Entertainment",
  "theater": "Entertainment",
  "theatre": "Entertainment",
  "amusement": "Entertainment",
  "hobby": "Entertainment",
  "hobbies": "Entertainment",
  "craft": "Entertainment",
  "crafts": "Entertainment",

  "streaming": "Subscriptions & Apps",
  "streaming services": "Subscriptions & Apps",
  "streaming & digital": "Subscriptions & Apps",
  "subscriptions": "Subscriptions & Apps",
  "gaming": "Subscriptions & Apps",
  "digital services": "Subscriptions & Apps",
  "membership": "Subscriptions & Apps",
  "subscription": "Subscriptions & Apps",
  "monthly subscription": "Subscriptions & Apps",
  "streaming & subscriptions": "Subscriptions & Apps",
  "software": "Subscriptions & Apps",
  "apps": "Subscriptions & Apps",
  "app store": "Subscriptions & Apps",
  "software & apps": "Subscriptions & Apps",

  "travel": "Travel",
  "flights": "Travel",
  "airlines": "Travel",
  "airline": "Travel",
  "travel (flights, hotels)": "Travel",
  "travel agencies": "Travel",
  "travel agency": "Travel",
  "hotels": "Travel",
  "hotel": "Travel",
  "hotels & lodging": "Travel",
  "accommodation": "Travel",
  "vacation": "Travel",
  "holiday": "Travel",
  "holidays & vacations": "Travel",
  "booking": "Travel",
  "travel expenses": "Travel",
  "flight": "Travel",
  "airfare": "Travel",
  "lodging": "Travel",
  "hotel booking": "Travel",
  "air travel": "Travel",
  "local activities": "Travel",
  "local activity": "Travel",
  "events & experiences": "Travel",
  "experience": "Travel",
  "experiences": "Travel",
  "holidays": "Travel",
  "vacations": "Travel",

  "gifts": "Gifts & Donations",
  "charity": "Gifts & Donations",
  "donations": "Gifts & Donations",
  "donation": "Gifts & Donations",
  "gifts & flowers": "Gifts & Donations",
  "zakat": "Gifts & Donations",
  "gift": "Gifts & Donations",
  "charitable donation": "Gifts & Donations",
  "charitable contributions": "Gifts & Donations",

  "shopping": "Shopping",
  "shopping (online)": "Shopping",
  "shopping (physical)": "Shopping",
  "online marketplaces": "Shopping",
  "online shopping": "Shopping",
  "department stores": "Shopping",
  "general retail": "Shopping",
  "fashion": "Shopping",
  "home & living": "Shopping",
  "retail": "Shopping",
  "retail shopping": "Shopping",
  "clothing & apparel": "Shopping",
  "clothing": "Shopping",
  "apparel": "Shopping",
  "clothes": "Shopping",
  "electronics": "Shopping",
  "electronic": "Shopping",
  "gadgets": "Shopping",
  "tech": "Shopping",
  "cleaning & maintenance": "Shopping",
  "home improvement": "Shopping",
  "garden": "Shopping",
  "gardening": "Shopping",
  "home & garden": "Shopping",

  "home maintenance & repairs": "Home Maintenance",
  "home repair": "Home Maintenance",
  "home repairs": "Home Maintenance",
  "home maintenance": "Home Maintenance",
  "maintenance": "Home Maintenance",
  "repairs": "Home Maintenance",

  "government & home repairs": "Taxes & Government",
  "government fee": "Taxes & Government",
  "government fees": "Taxes & Government",
  "government fees & payments": "Taxes & Government",
  "license fee": "Taxes & Government",
  "permit fee": "Taxes & Government",
  "registration fee": "Taxes & Government",
  "visa fee": "Taxes & Government",
  "government": "Taxes & Government",
  "government payment": "Taxes & Government",
  "taxes": "Taxes & Government",
  "tax": "Taxes & Government",
  "tax payment": "Taxes & Government",
  "income tax": "Taxes & Government",
  "property tax": "Taxes & Government",
  "sales tax": "Taxes & Government",
  "vat": "Taxes & Government",
  "government & taxes": "Taxes & Government",
  "tax expenses": "Taxes & Government",

  "education": "Education",
  "school": "Education",
  "schools & courses": "Education",
  "university": "Education",
  "training": "Education",
  "school fees": "Education",
  "education expenses": "Education",
  "tuition": "Education",
  "tuition fees": "Education",
  "school tuition": "Education",
  "university tuition": "Education",
  "certification": "Education",
  "online course": "Education",
  "online courses": "Education",
  "online learning": "Education",
  "certification & online courses": "Education",
  "professional development": "Education",
  "e-learning": "Education",
  "books": "Education",
  "books & supplies": "Education",
  "school supplies": "Education",
  "stationery": "Education",

  "daycare & nursery": "Kids & Pets",
  "daycare": "Kids & Pets",
  "nursery": "Kids & Pets",
  "babysitter": "Kids & Pets",
  "child care": "Kids & Pets",
  "childcare": "Kids & Pets",
  "nanny": "Kids & Pets",
  "pet care": "Kids & Pets",
  "pet expenses": "Kids & Pets",
  "pet": "Kids & Pets",
  "veterinary": "Kids & Pets",
  "vet": "Kids & Pets",
  "pet food": "Kids & Pets",
  "kids wallet": "Kids & Pets",
  "kids' wallet": "Kids & Pets",
  "kids money": "Kids & Pets",
  "pocket money": "Kids & Pets",

  "credit card payment": "Payment & Transfers",
  "card payment": "Payment & Transfers",
  "cc payment": "Payment & Transfers",
  "credit card bill": "Payment & Transfers",
  "credit card bill payment": "Payment & Transfers",
  "payment received": "Payment & Transfers",
  "payment recd": "Payment & Transfers",

  "other": DEFAULT_EXPENSE_CATEGORY,
  "general": DEFAULT_EXPENSE_CATEGORY,
  "uncategorized": DEFAULT_EXPENSE_CATEGORY,
  "misc": DEFAULT_EXPENSE_CATEGORY,
  "miscellaneous": DEFAULT_EXPENSE_CATEGORY,
  "miscellaneous expenses": DEFAULT_EXPENSE_CATEGORY,
  "other expenses": DEFAULT_EXPENSE_CATEGORY,
};

const INCOME_CATEGORY_ALIASES: Record<string, string> = {
  "salary": "Salary & Allowances",
  "wages": "Salary & Allowances",
  "paycheck": "Salary & Allowances",
  "salary / wages": "Salary & Allowances",
  "income": "Salary & Allowances",
  "monthly salary": "Salary & Allowances",
  "bonus payment": "Salary & Allowances",
  "bonus": "Salary & Allowances",
  "pension": "Salary & Allowances",
  "pension income": "Salary & Allowances",
  "allowance": "Salary & Allowances",

  "freelance": "Business / Self-Employed",
  "freelance / consulting": "Business / Self-Employed",
  "consulting": "Business / Self-Employed",
  "freelance income": "Business / Self-Employed",
  "consulting income": "Business / Self-Employed",
  "business": "Business / Self-Employed",
  "business income": "Business / Self-Employed",
  "self-employed": "Business / Self-Employed",
  "side income": "Business / Self-Employed",
  "side hustle": "Business / Self-Employed",
  "contract work": "Business / Self-Employed",

  "rent received": "Rental Income",
  "rent": "Rental Income",
  "housing - rent": "Rental Income",
  "rental": "Rental Income",
  "rental income": "Rental Income",
  "property rental": "Rental Income",
  "short-term rental income": "Rental Income",

  "property sale": "Asset Sales",
  "property sales": "Asset Sales",
  "real estate sale": "Asset Sales",
  "asset sale": "Asset Sales",

  "dividend": "Investments & Financial Gains",
  "dividends": "Investments & Financial Gains",
  "interest": "Investments & Financial Gains",
  "interest income": "Investments & Financial Gains",
  "interest earned": "Investments & Financial Gains",
  "financial income": "Investments & Financial Gains",
  "profit share": "Investments & Financial Gains",
  "profit sharing": "Investments & Financial Gains",
  "investment": "Investments & Financial Gains",
  "investment returns": "Investments & Financial Gains",
  "investment income": "Investments & Financial Gains",
  "capital gains": "Investments & Financial Gains",

  "gift": "Gifts & Transfers",
  "gifts received": "Gifts & Transfers",
  "gift received": "Gifts & Transfers",
  "inheritance": "Gifts & Transfers",

  "refund": "Refunds / Reimbursements",
  "refunds": "Refunds / Reimbursements",
  "reimbursement": "Refunds / Reimbursements",
  "reimbursements": "Refunds / Reimbursements",
  "cashback": "Refunds / Reimbursements",
  "cashback / rewards": "Refunds / Reimbursements",
  "rewards": "Refunds / Reimbursements",

  "other income": DEFAULT_INCOME_CATEGORY,
  "other": DEFAULT_INCOME_CATEGORY,
  "other one-time": DEFAULT_INCOME_CATEGORY,
  "miscellaneous": DEFAULT_INCOME_CATEGORY,
};

export function mapToSourceOfTruthCategory(
  categoryName: string | null | undefined,
  isIncome: boolean = false
): string {
  const result = mapToSourceOfTruthCategoryWithReason(categoryName, isIncome);
  return result.category;
}

export function mapToSourceOfTruthCategoryWithReason(
  categoryName: string | null | undefined,
  isIncome: boolean = false
): { category: string; attempted?: string; reason?: string } {
  const defaultCategory = isIncome ? DEFAULT_INCOME_CATEGORY : DEFAULT_EXPENSE_CATEGORY;

  if (!categoryName) {
    return { category: defaultCategory, reason: "empty_input" };
  }

  const normalizedName = categoryName.trim();

  if (!isIncome && (EXPENSE_CATEGORIES_FLAT as readonly string[]).includes(normalizedName)) {
    return { category: normalizedName, reason: "exact_valid" };
  }
  if (isIncome && (INCOME_CATEGORIES_FLAT as readonly string[]).includes(normalizedName)) {
    return { category: normalizedName, reason: "exact_valid" };
  }

  const lowerName = normalizedName.toLowerCase();

  if (!isIncome) {
    const mapped = EXPENSE_CATEGORY_ALIASES[lowerName];
    if (mapped) return { category: mapped, attempted: normalizedName, reason: "exact_alias" };
  } else {
    const mapped = INCOME_CATEGORY_ALIASES[lowerName];
    if (mapped) return { category: mapped, attempted: normalizedName, reason: "exact_alias" };
  }

  console.log(`[CATEGORY-GUARD] No exact mapping for "${normalizedName}" (${isIncome ? "income" : "expense"}). Using default.`);
  return { category: defaultCategory, attempted: normalizedName, reason: "no_match_default" };
}

const expenseSubcategoryMap = new Map<string, Set<string>>();
for (const entry of EXPENSE_CATEGORIES_WITH_SUBCATEGORIES) {
  expenseSubcategoryMap.set(entry.category.toLowerCase(), new Set(entry.subcategories.map(s => s.toLowerCase())));
}

const incomeSubcategoryMap = new Map<string, Set<string>>();
for (const entry of INCOME_CATEGORIES_WITH_SUBCATEGORIES) {
  incomeSubcategoryMap.set(entry.category.toLowerCase(), new Set(entry.subcategories.map(s => s.toLowerCase())));
}

const allExpenseSubcategories = new Map<string, { category: string; subcategory: string }>();
for (const entry of EXPENSE_CATEGORIES_WITH_SUBCATEGORIES) {
  for (const sub of entry.subcategories) {
    allExpenseSubcategories.set(sub.toLowerCase(), { category: entry.category, subcategory: sub });
  }
}

const allIncomeSubcategories = new Map<string, { category: string; subcategory: string }>();
for (const entry of INCOME_CATEGORIES_WITH_SUBCATEGORIES) {
  for (const sub of entry.subcategories) {
    allIncomeSubcategories.set(sub.toLowerCase(), { category: entry.category, subcategory: sub });
  }
}

export function mapToSourceOfTruthSubcategory(
  subcategoryName: string | null | undefined,
  category: string | null | undefined,
  isIncome: boolean = false
): string | null {
  if (!subcategoryName) return null;

  const normalizedSub = subcategoryName.trim().toLowerCase();
  if (!normalizedSub) return null;

  const subcatMap = isIncome ? incomeSubcategoryMap : expenseSubcategoryMap;
  const allSubcats = isIncome ? allIncomeSubcategories : allExpenseSubcategories;

  if (category) {
    const validSubs = subcatMap.get(category.toLowerCase());
    if (validSubs && validSubs.has(normalizedSub)) {
      const match = allSubcats.get(normalizedSub);
      return match ? match.subcategory : subcategoryName.trim();
    }
    return null;
  }

  const globalMatch = allSubcats.get(normalizedSub);
  if (globalMatch) {
    return globalMatch.subcategory;
  }

  return null;
}

export function validateAndCorrectCategory(
  category: string | null | undefined,
  isIncome: boolean,
  customCategoryNames?: Set<string>
): string | null | undefined {
  if (!category) return category;
  if (customCategoryNames?.has(category)) return category;
  const validator = isIncome ? isValidIncomeCategory : isValidExpenseCategory;
  if (validator(category)) return category;
  const result = mapToSourceOfTruthCategoryWithReason(category, isIncome);
  if (result.reason === "exact_alias") {
    console.warn(`[CATEGORY-GUARD] Auto-corrected "${category}" → "${result.category}" via ${result.reason} (${isIncome ? "income" : "expense"})`);
  } else if (result.reason === "no_match_default") {
    console.warn(`[CATEGORY-GUARD] No exact mapping for "${category}" (${isIncome ? "income" : "expense"}). Falling back to "${result.category}".`);
  }
  return result.category;
}

export function validateMerchantCategoryFields(
  category: string | null | undefined,
  categoryGroup: string | null | undefined
): { category: string | null | undefined; categoryGroup: string | null | undefined } {
  return {
    category: validateAndCorrectCategory(category, false),
    categoryGroup: validateAndCorrectCategory(categoryGroup, false),
  };
}
