/**
 * Three-tier merchant matcher.
 *
 * Resolution order:
 *   1. User-specific mapping (exact normalized match) — confidence 1.0
 *   2. Exact normalized match against the global merchant database
 *   3. Keyword-based category inference (checked before fuzzy matching to
 *      prevent false positives)
 *   4. Token-based fuzzy matching with negative guards (short strings,
 *      digit-heavy strings, transfer markers, ambiguous scores)
 *   5. Keyword fallback
 *   6. Log to unmatched merchants for future enrichment
 */

import type { MerchantStorage } from "./storage";
import { normalizeMerchant, extractCoreMerchant } from "./merchantNormalizer";
import { findBestMatch, buildMerchantIndex } from "./tokenMatcher";
import { matchByKeyword } from "./categoryKeywords";
import { mapToSourceOfTruthCategory } from "./categoryGuard";
import { DEFAULT_EXPENSE_CATEGORY } from "../config/categories";

export interface MatchResult {
  merchantId?: string;
  merchantName: string;
  categoryGroup: string;
  category: string;
  subcategory?: string | null;
  confidence: number;
  matchMethod: string;
  entity_type: "merchant" | "counterparty" | "operation";
  evidence: string[];
  alternative_candidates: Array<{ name: string; confidence: number }>;
  blocked_reason?: string;
}

const TRANSFER_MARKER_PATTERN = /\b(EFT|SWIFT|HAVALE|HVL|FAST|VİRMAN|VIRMAN|WIRE|CHAPS|BACS|SEPA|ACH|VIREMENT|TRANSFERENCIA|TRASPASO)\b/i;

function shouldSkipFuzzyMatching(cleanedKey: string): string | null {
  if (cleanedKey.length < 4) {
    return `too_short (${cleanedKey.length} chars)`;
  }

  const digitCount = (cleanedKey.match(/\d/g) || []).length;
  const nonSpaceLength = cleanedKey.replace(/\s/g, "").length;
  if (nonSpaceLength > 0 && digitCount / nonSpaceLength > 0.6) {
    return `mostly_digits (${Math.round(digitCount / nonSpaceLength * 100)}%)`;
  }

  if (TRANSFER_MARKER_PATTERN.test(cleanedKey)) {
    return `transfer_marker`;
  }

  return null;
}

export async function matchMerchant(
  storage: MerchantStorage,
  rawText: string,
  region: string = "global",
  userId?: string,
  options?: { skipFuzzy?: boolean }
): Promise<MatchResult> {
  const normalized = normalizeMerchant(rawText);
  void extractCoreMerchant(rawText);

  // 1. User-specific merchant mappings — exact normalized match only
  if (userId) {
    try {
      const m = await storage.findUserMapping(userId, normalized);
      if (m) {
        const normalizedCategory = mapToSourceOfTruthCategory(m.category, false);
        return {
          merchantName: m.displayMerchant,
          categoryGroup: normalizedCategory,
          category: normalizedCategory,
          subcategory: m.subcategory || null,
          confidence: 1.0,
          matchMethod: "USER_MAPPING",
          entity_type: "merchant",
          evidence: [`user_mapping:${m.normalizedMerchant}`, `user:${userId}`],
          alternative_candidates: []
        };
      }
    } catch (e) {
      console.log(`[MerchantMatcher] User mapping lookup error: ${e}`);
    }
  }

  // 2. Exact normalized match against global merchant database
  try {
    const m = await storage.findGlobalMerchantByNormalizedName(normalized);
    if (m) {
      const resolvedCategory = m.category ? mapToSourceOfTruthCategory(m.category, false) : null;
      if (resolvedCategory && resolvedCategory !== DEFAULT_EXPENSE_CATEGORY) {
        return {
          merchantId: m.merchantId,
          merchantName: m.merchantName,
          categoryGroup: mapToSourceOfTruthCategory(m.categoryGroup, false),
          category: resolvedCategory,
          subcategory: m.subcategory || null,
          confidence: Number(m.confidence) || 0.95,
          matchMethod: "EXACT_NORMALIZED",
          entity_type: "merchant",
          evidence: [`exact_normalized:${normalized}`],
          alternative_candidates: []
        };
      }
    }
  } catch (e) {
    // Continue
  }

  // 3. Keyword-based category inference (before token matching to prevent false positives)
  const keywordMatch = matchByKeyword(rawText);

  // 4. Token-based fuzzy matching (with negative guards)
  const skipFuzzy = options?.skipFuzzy === true;
  const guardReason = skipFuzzy ? "skip_fuzzy_income" : shouldSkipFuzzyMatching(normalized);
  if (guardReason) {
    console.log(`[MERCHANT-GUARD] Blocked fuzzy match for "${normalized}" — reason: ${guardReason}`);
    if (keywordMatch) {
      return {
        merchantName: rawText,
        categoryGroup: mapToSourceOfTruthCategory(keywordMatch.categoryGroup, false),
        category: mapToSourceOfTruthCategory(keywordMatch.category, false),
        confidence: 0.7,
        matchMethod: "KEYWORD",
        entity_type: "merchant",
        evidence: [`keyword:${keywordMatch.category}`, `guard_blocked:${guardReason}`],
        alternative_candidates: [],
        blocked_reason: guardReason
      };
    }
  } else {
    try {
      const tokenMatch = await findBestMatch(storage, rawText);
      if (tokenMatch && tokenMatch.confidence >= 0.5) {
        if (tokenMatch.secondBestScore !== undefined &&
            tokenMatch.confidence - tokenMatch.secondBestScore <= 0.05 &&
            tokenMatch.confidence < 0.85) {
          const ambiguousReason = `ambiguous (${tokenMatch.confidence.toFixed(3)} vs ${tokenMatch.secondBestScore.toFixed(3)})`;
          console.log(`[MERCHANT-GUARD] Blocked fuzzy match for "${normalized}" — reason: ${ambiguousReason}`);
          if (keywordMatch) {
            return {
              merchantName: rawText,
              categoryGroup: mapToSourceOfTruthCategory(keywordMatch.categoryGroup, false),
              category: mapToSourceOfTruthCategory(keywordMatch.category, false),
              confidence: 0.7,
              matchMethod: "KEYWORD",
              entity_type: "merchant",
              evidence: [`keyword:${keywordMatch.category}`, `guard_blocked:${ambiguousReason}`, ...tokenMatch.evidence],
              alternative_candidates: tokenMatch.alternative_candidates,
              blocked_reason: ambiguousReason
            };
          }
        } else {
          if (keywordMatch && tokenMatch.confidence < 0.85) {
            return {
              merchantName: rawText,
              categoryGroup: mapToSourceOfTruthCategory(keywordMatch.categoryGroup, false),
              category: mapToSourceOfTruthCategory(keywordMatch.category, false),
              confidence: 0.75,
              matchMethod: "KEYWORD_OVER_TOKEN",
              entity_type: "merchant",
              evidence: [`keyword_preferred:${keywordMatch.category}`, `token_candidate:${tokenMatch.merchantName}(${tokenMatch.confidence.toFixed(3)})`, ...tokenMatch.evidence],
              alternative_candidates: tokenMatch.alternative_candidates
            };
          }
          return {
            merchantId: tokenMatch.merchantId,
            merchantName: tokenMatch.merchantName,
            categoryGroup: mapToSourceOfTruthCategory(tokenMatch.categoryGroup, false),
            category: mapToSourceOfTruthCategory(tokenMatch.category, false),
            subcategory: tokenMatch.subcategory || null,
            confidence: tokenMatch.confidence,
            matchMethod: tokenMatch.matchMethod,
            entity_type: "merchant",
            evidence: tokenMatch.evidence,
            alternative_candidates: tokenMatch.alternative_candidates
          };
        }
      }
    } catch (e) {
      console.log(`[MerchantMatcher] Token matching error: ${e}`);
    }
  }

  // 5. Keyword fallback (if token matching failed entirely)
  if (keywordMatch) {
    return {
      merchantName: rawText,
      categoryGroup: mapToSourceOfTruthCategory(keywordMatch.categoryGroup, false),
      category: mapToSourceOfTruthCategory(keywordMatch.category, false),
      confidence: 0.7,
      matchMethod: "KEYWORD",
      entity_type: "merchant",
      evidence: [`keyword_fallback:${keywordMatch.category}`],
      alternative_candidates: []
    };
  }

  // 6. Final fallback — log to unmatched for future enrichment
  try {
    await storage.logUnmatchedMerchant({
      rawMerchantText: rawText,
      normalizedMerchantText: normalized,
      region
    });
  } catch (e) {
    // Logging failed, not critical
  }

  return {
    merchantName: rawText,
    categoryGroup: DEFAULT_EXPENSE_CATEGORY,
    category: DEFAULT_EXPENSE_CATEGORY,
    confidence: 0.3,
    matchMethod: "NONE",
    entity_type: "merchant",
    evidence: [`no_match:${normalized}`],
    alternative_candidates: [],
    blocked_reason: guardReason || undefined
  };
}

export async function warmupMerchantIndex(storage: MerchantStorage): Promise<void> {
  try {
    console.log("[MerchantMatcher] Warming up merchant index...");
    await buildMerchantIndex(storage);
    console.log("[MerchantMatcher] Warmup complete.");
  } catch (error) {
    console.error("[MerchantMatcher] Warmup failed:", error);
  }
}
