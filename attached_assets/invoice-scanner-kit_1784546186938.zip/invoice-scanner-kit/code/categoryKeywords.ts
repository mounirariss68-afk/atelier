/**
 * Unified Category Keywords Module
 * 
 * Single source of truth for keyword-based category inference.
 * Used by: merchantMatcher.ts, transactionProcessor.ts, statementParser.ts
 * 
 * Structure: Each entry has categoryGroup (broad), category (specific), 
 * priority (lower = checked first), and keywords array.
 */

import { EXPENSE_CATEGORIES_FLAT, INCOME_CATEGORIES_FLAT } from "../config/categories";

export interface UnifiedKeywordEntry {
  categoryGroup: string;
  category: string;
  priority: number;
  wordBoundary?: boolean;
  stemMatch?: boolean;
  keywords: string[];
}

export const UNIFIED_KEYWORDS: UnifiedKeywordEntry[] = [
  // ============ PHARMACY & HEALTH (Priority 1) ============
  {
    categoryGroup: "Health & Fitness",
    category: "Health & Fitness",
    priority: 1,
    wordBoundary: true,
    keywords: [
      "pharmacy", "pharmacie", "farmacia", "farmácia", "eczane",
      "chemist", "drugstore", "apothecary", "dispensary", "apotek", "apotheke",
      "medicine", "prescription", "rx",
      "boots", "boots pharmacy", "boots chemist",
      "lloyds pharmacy", "superdrug", "well pharmacy", "rowlands pharmacy",
      "cvs", "cvs pharmacy", "walgreens", "rite aid", "duane reade",
      "life pharmacy", "aster pharmacy", "bin sina", "mediclinic pharmacy", "nahdi", "al dawaa",
      "dm", "rossmann", "muller", "farmacias", "parafarmacia",
      "watsons", "guardian pharmacy", "manning", "matsumoto kiyoshi", "tsuruha", "sundrug", "cosmos",
      "shoppers drug mart", "pharmaprix", "jean coutu", "rexall", "london drugs",
      "priceline pharmacy", "chemist warehouse", "terry white", "amcal", "blooms chemist"
    ]
  },
  {
    categoryGroup: "Health & Fitness",
    category: "Health & Fitness",
    priority: 1,
    wordBoundary: true,
    keywords: [
      "hospital", "clinic", "medical", "healthcare", "health center", "health centre",
      "doctor", "physician", "specialist", "surgery", "emergency", "urgent care",
      "primary care", "family medicine", "general practice",
      "dentist", "dental", "orthodontist", "optician", "optical", "eye doctor",
      "dermatologist", "physiotherapy", "chiropractor", "psychologist", "psychiatrist",
      "podiatrist", "cardiologist",
      "nhs", "bupa", "nuffield", "spire", "hca", "mediclinic", "aster clinic", "thumbay",
      "cigna", "aetna", "united healthcare", "blue cross", "kaiser", "humana",
      "daman", "dubai health authority"
    ]
  },
  {
    categoryGroup: "Health & Fitness",
    category: "Health & Fitness",
    priority: 2,
    keywords: [
      "gym", "fitness", "fitness center", "fitness centre",
      "yoga", "pilates", "crossfit", "wellness", "wellbeing", "well-being", "health club",
      "planet fitness", "la fitness", "anytime fitness", "orangetheory", "f45",
      "equinox", "gold gym", "crunch fitness", "lifetime fitness"
    ]
  },

  // ============ COFFEE & SNACKS (Priority 1) ============
  // NOTE: wordBoundary=true prevents false positives like "COSTA MESA CITY" matching "costa"
  // Short keywords (<=4 chars) auto-use word boundary, but we set it explicitly for clarity
  {
    categoryGroup: "Food & Dining",
    category: "Food & Dining",
    priority: 1,
    wordBoundary: true,
    keywords: [
      // Coffee drinks & shops
      "coffee",
      "coffee shop", "coffee house", "coffeehouse", "coffee bar", "coffee roaster",
      "espresso", "cappuccino", "latte", "americano", "mocha", "macchiato",
      // Cafe variants (short words, word boundary protects them)
      "cafe", "café", "caffe", "caffè", "kahve", "kopi", "kafe",
      // Bakery (includes Turkish "fırın" = bakery/oven, transliterated to "firin")
      "bakery", "pastry", "patisserie", "pâtisserie", "confectionery",
      "firin", "fırın", "ekmek",
      "donut", "doughnut", "croissant", "muffin", "scone", "cookie", "biscuit",
      // Ice cream & frozen treats
      "gelato", "gelati", "gelateria", "ice cream", "icecream", "helado", "dondurma",
      "frozen yogurt", "froyo", "frogurt", "sorbet", "popsicle", "soft serve",
      // Nuts & snacks
      "nuts",
      // Smoothies & juice
      "smoothie", "juice bar", "acai", "açai",
      // Bubble tea
      "bubble tea", "boba", "milk tea", "matcha", "chai tea",
      // Pastries & sweets
      "crepe", "waffle", "pancake", "churro", "pretzel", "cinnamon roll", "cupcake", "macaron",
      "candy", "chocolate shop", "chocolatier", "fudge", "sweet shop", "dessert", "desserts",
      // Ice cream chains
      "baskin robbins", "baskin-robbins", "haagen dazs", "haagen-dazs", "cold stone", "coldstone",
      "dairy queen", "ben jerry", "ben and jerry", "magnum", "talenti",
      "pinkberry", "menchies", "yogurtland", "orange leaf", "tcby",
      // Bakery/donut chains
      "auntie anne", "wetzel pretzel", "cinnabon", "krispy kreme", "mister donut",
      "dunkin", "dunkin donuts",
      // Coffee chains (removed standalone "costa" - conflicts with city names like Costa Mesa)
      "starbucks", "costa coffee", "tim hortons", "nero", "caffe nero",
      "peet", "peets coffee", "caribou", "lavazza", "illy", "blue bottle",
      "intelligentsia", "stumptown", "gloria jeans", "coffee bean", "wild bean", "mccafe", "barista",
      "arabian coffee", "raw coffee", "%arabica", "arabica", "specialty coffee",
      // Bubble tea chains
      "gong cha", "tiger sugar", "coco tea", "happy lemon", "heytea", "nayuki",
      "the alley", "kung fu tea", "sharetea", "cha time", "cha for tea",
      // Bakery-cafe chains
      "le pain quotidien", "panera", "au bon pain", "corner bakery",
      "nothing bundt", "paris baguette", "tous les jours", "85c", "85 degrees",
      "beard papa", "cream puff"
    ]
  },

  // ============ GROCERIES (Priority 1) ============
  // NOTE: Removed standalone "market" - too generic, matches non-grocery contexts
  {
    categoryGroup: "Food & Dining",
    category: "Groceries",
    priority: 1,
    wordBoundary: true,
    keywords: [
      "grocery", "supermarket", "supermark", "hypermarket", "minimart", "convenience store",
      "food market", "fresh market", "farmers market", "fish market", "meat market",
      "walmart", "target", "costco", "whole foods", "trader joe", "kroger", "safeway",
      "albertsons", "publix", "wegmans", "heb", "meijer", "aldi", "lidl",
      "food lion", "giant", "stop shop", "shoprite", "winn dixie", "sprouts", "fresh market",
      "tesco", "sainsbury", "asda", "morrisons", "waitrose", "co-op",
      "marks spencer food", "iceland", "ocado", "farmfoods",
      "carrefour", "auchan", "leclerc", "intermarche", "casino", "monoprix", "franprix",
      "rewe", "edeka", "penny", "netto", "kaufland", "real",
      "mercadona", "el corte ingles", "dia", "eroski",
      "ahold", "delhaize", "albert heijn", "jumbo", "coop", "migros", "spar", "billa", "maxima", "rimi",
      "lulu", "lulu hypermarket", "spinneys", "al maya", "choithram", "geant", "carrefouruae",
      "union coop", "al safeer", "al madina", "nesto", "fathima", "day to day", "viva", "carrefour market",
      "aeon", "ito yokado", "daiei", "life", "summit", "maruetsu", "don quijote",
      "ntuc fairprice", "cold storage", "sheng siong",
      "7-eleven", "7 eleven", "family mart", "lawson", "ministop",
      "wellcome", "parknshop", "big c", "tops", "lotus", "villa market", "gourmet market", "maxvalu",
      "woolworths", "coles", "iga"
    ]
  },

  // ============ FOREX / CURRENCY EXCHANGE (Priority 1 — must be checked before Fuel to prevent "Mobil DÖVİZ" → Fuel) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 1,
    keywords: [
      "doviz satis", "doviz alis", "doviz havale", "doviz",
      "döviz satış", "döviz alış", "döviz havale", "döviz",
      "foreign exchange", "currency exchange", "forex",
      "cambio", "change devise", "صرف عملات"
    ]
  },

  // ============ FUEL & GAS (Priority 1) ============
  {
    categoryGroup: "Transportation",
    category: "Transportation",
    priority: 1,
    wordBoundary: true,
    keywords: [
      "petrol", "gasoline", "diesel", "fuel", "gas station", "filling station",
      "service station", "petroleum", "benzin", "benzina",
      "enoc", "adnoc", "eppco", "emarat", "woqod", "bapco", "aramco", "total energies",
      "shell", "bp", "exxon", "mobil", "exxonmobil", "chevron", "texaco",
      "total", "esso", "gulf", "caltex", "sinopec", "petrochina", "cnpc",
      "petrobras", "indian oil", "bharat petroleum", "hindustan petroleum", "reliance",
      "76", "arco", "valero", "marathon", "sunoco", "citgo", "phillips 66", "conoco",
      "murphy usa", "racetrac", "sheetz", "wawa", "quicktrip", "pilot flying j", "loves", "ta petro",
      "repsol", "cepsa", "galp", "mol", "pko", "orlen", "lukoil", "rosneft", "gazprom",
      "statoil", "circle k"
    ]
  },

  // ============ TRANSPORTATION (Priority 1-2) ============
  {
    categoryGroup: "Transportation",
    category: "Transportation",
    priority: 1,
    wordBoundary: true,
    keywords: [
      "uber", "lyft", "taxi", "cab", "rideshare", "ride share",
      "careem", "bolt", "grab", "gojek", "didi", "ola",
      "limousine", "limousinee", "limo",
      "chauffeur", "car service", "private car",
      "executive car", "black car",
      "airport transfer", "hotel transfer", "shuttle transfer",
      "dubai taxi", "mawasalat", "mwasalat"
    ]
  },
  // NOTE: Removed standalone "park" - matches theme parks, city names, etc.
  // "parking" and "car park" are specific enough
  {
    categoryGroup: "Transportation",
    category: "Transportation",
    priority: 1,
    wordBoundary: true,
    keywords: [
      "parking", "car park", "parking lot", "parking garage", "park and ride",
      "parking meter", "valet parking", "valet",
      "ncp", "q-park", "apcoa", "interparking"
    ]
  },
  {
    categoryGroup: "Transportation",
    category: "Transportation",
    priority: 2,
    wordBoundary: true,
    keywords: [
      "transport", "transit", "commute", "metro", "subway", "bus", "tram", "train", "railway",
      "rta", "salik", "nol",
      "tfl", "oyster", "tube", "underground", "national rail", "trainline",
      "south western", "great western", "avanti", "lner", "thameslink",
      "southeastern", "scotrail", "northern rail", "transpennine",
      "sncf", "eurostar", "thalys", "deutsche bahn", "db", "trenitalia", "renfe",
      "ns", "sbb", "bvg", "ratp", "stib", "atm milano",
      "amtrak", "bart", "mta", "cta", "mbta", "wmata", "septa", "metra", "nj transit",
      "mtr", "smrt", "jre", "jr east", "jr west", "keio", "odakyu", "tokyu", "seibu",
      "lime", "bird", "tier", "spin", "voi", "jump", "link"
    ]
  },

  // ============ TRAVEL (Priority 1) ============
  {
    categoryGroup: "Entertainment & Leisure",
    category: "Travel",
    priority: 1,
    keywords: [
      "hotel", "motel", "hostel", "resort", "lodge", "inn", "otel", "albergo",
      "hilton", "marriott", "sheraton", "westin", "hyatt", "intercontinental",
      "crowne plaza", "holiday inn", "doubletree", "hampton", "courtyard",
      "ritz carlton", "four seasons", "st regis", "w hotel", "waldorf",
      "mandarin oriental", "fairmont", "sofitel", "radisson", "wyndham", "ramada",
      "best western", "novotel", "premier inn", "travelodge", "ibis",
      "booking.com", "expedia", "hotels.com", "agoda", "airbnb"
    ]
  },
  {
    categoryGroup: "Entertainment & Leisure",
    category: "Travel",
    priority: 1,
    keywords: [
      "airline", "airways", "flight",
      "emirates", "etihad", "qatar airways", "flydubai", "air arabia", "saudia",
      "british airways", "lufthansa", "air france", "klm",
      "american airlines", "united", "delta", "southwest", "jetblue",
      "singapore airlines", "cathay pacific", "qantas", "virgin atlantic",
      "ryanair", "easyjet", "wizz air"
    ]
  },
  {
    categoryGroup: "Entertainment & Leisure",
    category: "Travel",
    priority: 2,
    keywords: [
      "travel", "tourism", "tours", "holidays", "vacation", "booking"
    ]
  },

  // ============ DINING & RESTAURANTS (Priority 2) ============
  {
    categoryGroup: "Food & Dining",
    category: "Food & Dining",
    priority: 2,
    keywords: [
      "restaurant", "restauran", "ristorante", "restoran", "lokanta",
      "bistro", "grill", "eatery", "diner", "dining", "food court", "qlub", "seafood",
      "kitchen", "catering", "brasserie", "tavern", "gastropub", "f&b",
      "steakhouse", "pizzeria", "trattoria", "cantina", "taqueria",
      "taverna", "osteria", "meyhane",
      "sushi", "ramen", "noodle", "dim sum", "pho", "korean bbq", "wok",
      "curry", "biryani", "kebab", "shawarma", "falafel", "hummus", "doner",
      "lahmacun", "pide", "kofte", "iskender",
      "borek", "gozleme", "manti", "dolma", "sarma", "meze",
      "tashas", "grand bazaar rest", "jones the grocer"
    ]
  },
  {
    categoryGroup: "Food & Dining",
    category: "Food & Dining",
    priority: 2,
    keywords: [
      "mcdonald", "mcdonalds", "kfc", "subway", "burger king", "burgerking",
      "wendy", "wendys", "taco bell", "tacobell", "chick-fil-a", "chickfila",
      "popeyes", "arby", "arbys", "domino", "dominos", "papa john", "pizza hut", "pizzahut",
      "little caesars", "sonic", "jack in the box", "carl jr", "hardee",
      "culver", "wingstop", "buffalo wild wings", "zaxby", "raising cane",
      "panda express", "qdoba", "del taco", "checkers", "white castle",
      "steak n shake", "cookout", "bojangles", "church chicken", "el pollo loco",
      "long john silver", "captain d", "a&w", "five guys", "shake shack",
      "in-n-out", "innout", "whataburger", "chipotle", "jollibee"
    ]
  },
  {
    categoryGroup: "Food & Dining",
    category: "Food & Dining",
    priority: 2,
    keywords: [
      "uber eats", "doordash", "grubhub", "postmates", "just eat", "menulog",
      "foodpanda", "swiggy", "rappi", "glovo", "wolt", "hungry panda",
      "fantuan", "chowbus", "weee", "deliveroo", "talabat", "zomato",
      "careem food", "noon food"
    ]
  },

  // ============ WELLNESS & THERAPY (Priority 2) ============
  {
    categoryGroup: "Health & Fitness",
    category: "Health & Fitness",
    priority: 2,
    keywords: [
      "hair", "barber", "barbershop", "hair salon", "hairdresser", "hairstylist",
      "salon", "beauty salon", "kuafor", "peluqueria", "friseur",
      "nail salon", "nails", "manicure", "pedicure",
      "spa", "hammam", "massage", "waxing", "threading", "facial", "skincare", "grooming",
      "supercuts", "great clips", "sports clips", "cost cutters", "fantastic sams",
      "drybar", "blowout", "european wax center",
      "massage envy", "elements massage", "hand and stone"
    ]
  },

  // ============ SHOPPING (Priority 3) ============
  {
    categoryGroup: "Shopping",
    category: "Shopping",
    priority: 3,
    keywords: [
      "electronics", "dyson", "apple store", "samsung", "best buy", "currys", "pc world",
      "mediamarkt", "media markt", "fnac", "micro center", "b&h photo", "newegg", "gamestop"
    ]
  },
  {
    categoryGroup: "Shopping",
    category: "Shopping",
    priority: 3,
    keywords: [
      "boutique", "fashion", "clothing", "apparel", "tailor", "tailoring", "tailori",
      "h&m", "zara", "uniqlo", "gap", "forever 21", "mango", "bershka",
      "pull bear", "stradivarius", "massimo dutti", "topshop", "river island",
      "new look", "boohoo", "prettylittlething", "shein", "fashion nova",
      "brandy melville", "subdued",
      "nike", "adidas", "puma", "reebok", "new balance", "under armour",
      "footlocker", "jd sports", "sports direct", "decathlon",
      "lululemon", "athleta", "fabletics", "alo yoga"
    ]
  },
  {
    categoryGroup: "Shopping",
    category: "Shopping",
    priority: 4,
    keywords: [
      "shopping mall", "outlet", "retail", "store", "shop", "emporium",
      "galleria", "plaza", "bazaar", "duty free",
      "amazon", "ebay", "alibaba", "aliexpress", "wish", "etsy", "rakuten",
      "noon", "souq", "namshi", "ounass", "mumzworld", "sivvi", "aramex",
      "nordstrom", "macy", "bloomingdale", "neiman marcus", "saks",
      "jcpenney", "kohl", "dillard", "belk", "ross", "marshalls", "burlington",
      "primark", "next", "marks spencer", "john lewis", "selfridges", "harrods", "tk maxx",
      "ikea", "home depot", "lowe", "bed bath beyond", "pottery barn",
      "williams sonoma", "crate barrel", "west elm", "wayfair"
    ]
  },

  // ============ LAUNDRY & DRY CLEANING (Priority 3) ============
  {
    categoryGroup: "Shopping",
    category: "Shopping",
    priority: 3,
    keywords: [
      "laundry", "dry cleaning", "dry cleaner", "laundromat", "laundrette",
      "wash and fold", "ironing", "pressing"
    ]
  },

  // ============ GIFTS (Priority 3) ============
  {
    categoryGroup: "Other",
    category: "Gifts & Donations",
    priority: 3,
    keywords: [
      "flower", "flowers", "florist", "floral", "bouquet", "rose", "roses",
      "gift shop", "gift store", "gift card", "greeting card",
      "hallmark", "fnp", "ferns n petals", "interflora", "1800flowers", "bloom", "bloomsybox",
      "florette"
    ]
  },

  // ============ ENTERTAINMENT (Priority 3) ============
  {
    categoryGroup: "Entertainment & Leisure",
    category: "Entertainment",
    priority: 3,
    keywords: [
      "cinema", "movie", "theatre", "theater", "imax", "vox", "reel",
      "amc", "regal", "cinemark", "odeon", "vue", "cineworld"
    ]
  },
  {
    categoryGroup: "Entertainment & Leisure",
    category: "Subscriptions & Apps",
    priority: 3,
    keywords: [
      "spotify", "disney", "disney plus", "hbo", "hulu",
      "amazon prime video", "prime video", "youtube premium",
      "xbox", "playstation", "steam", "nintendo"
    ]
  },

  // ============ SUBSCRIPTIONS (Priority 3) ============
  {
    categoryGroup: "Entertainment & Leisure",
    category: "Subscriptions & Apps",
    priority: 3,
    keywords: [
      "subscription", "membership",
      "netflix", "apple tv", "apple music", "audible", "kindle unlimited",
      "adobe", "microsoft 365", "dropbox", "icloud", "google one"
    ]
  },

  // ============ SOFTWARE & APPS (Priority 3) ============
  {
    categoryGroup: "Entertainment & Leisure",
    category: "Subscriptions & Apps",
    priority: 3,
    keywords: [
      "replit", "godaddy", "go daddy", "github", "gitlab", "bitbucket", "heroku", "vercel", "netlify",
      "jetbrains", "visual studio", "slack", "notion", "figma", "canva",
      "zoom", "webex", "teams"
    ]
  },

  // ============ UTILITIES (Priority 2) ============
  {
    categoryGroup: "Housing & Utilities",
    category: "Utilities",
    priority: 2,
    keywords: [
      "electricity", "water", "utility", "power", "energy", "gas bill", "sewage",
      "dewa", "sewa", "fewa", "addc"
    ]
  },
  {
    categoryGroup: "Housing & Utilities",
    category: "Utilities",
    priority: 2,
    keywords: [
      "etisalat", "vodafone", "telecom", "broadband", "internet",
      "du", "virgin mobile", "at&t", "verizon", "t-mobile", "sprint",
      "ee", "o2", "three"
    ]
  },

  // ============ EDUCATION (Priority 3) ============
  {
    categoryGroup: "Other",
    category: "Education",
    priority: 3,
    keywords: [
      "school", "university", "college", "tuition", "training",
      "udemy", "coursera", "skillshare", "masterclass", "linkedin learning", "duolingo"
    ]
  },
  {
    categoryGroup: "Other",
    category: "Education",
    priority: 3,
    keywords: [
      "certification", "certificate", "online course", "e-learning", "elearning",
      "professional development", "training course", "workshop",
      "udacity", "edx", "pluralsight", "codeacademy", "codecademy", "datacamp",
      "google certificate", "aws certification", "microsoft certification",
      "comptia", "cisco certification", "pmp certification"
    ]
  },

  // ============ BOOKS & SUPPLIES (Priority 3) ============
  {
    categoryGroup: "Other",
    category: "Education",
    priority: 3,
    keywords: [
      "kindle", "bookstore", "bookshop", "book store", "book shop",
      "waterstones", "barnes noble", "amazon books",
      "stationery", "office supplies", "school supplies"
    ]
  },

  // ============ TRANSPORTATION - CAR FINANCING (Priority 3) ============
  {
    categoryGroup: "Transportation",
    category: "Transportation",
    priority: 3,
    keywords: [
      "car loan", "auto loan", "vehicle financing", "car finance",
      "car lease", "auto lease", "vehicle lease", "car leasing",
      "car payment", "auto financing", "vehicle loan",
      "car installment", "vehicle installment"
    ]
  },

  // ============ GOVERNMENT FEES (Priority 3) ============
  {
    categoryGroup: "Financial",
    category: "Taxes & Government",
    priority: 3,
    keywords: [
      "government fee", "license fee", "permit fee", "registration fee",
      "passport", "visa fee", "visa application", "visa processing", "embassy", "mofa",
      "municipal fee", "city fee", "council fee", "dmv",
      "court fee", "legal fee", "notary", "stamp duty",
      "vehicle registration", "driving license", "driver license",
      "tasjeel", "vfs"
    ]
  },
  {
    categoryGroup: "Financial",
    category: "Taxes & Government",
    priority: 3,
    wordBoundary: true,
    keywords: [
      "gov"
    ]
  },

  // ============ TAXES (Priority 3) ============
  {
    categoryGroup: "Financial",
    category: "Taxes & Government",
    priority: 3,
    keywords: [
      "tax payment", "income tax", "property tax", "vat",
      "sales tax", "capital gains tax", "estate tax",
      "irs", "hmrc", "tax office", "tax authority",
      "tax filing", "tax return", "tax refund"
    ]
  },

  // ============ CHARITY (Priority 3) ============
  {
    categoryGroup: "Other",
    category: "Gifts & Donations",
    priority: 3,
    keywords: [
      "charity", "donation", "zakat", "sadaqah", "red cross", "unicef",
      "gofundme", "patreon"
    ]
  },

  // ============ INSURANCE (Priority 3) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 3,
    keywords: [
      "insurance", "life insurance", "health insurance", "car insurance",
      "home insurance", "travel insurance"
    ]
  },

  // ============ INVESTMENTS (Priority 3) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 3,
    keywords: [
      "investment", "stocks", "mutual fund", "crypto", "bitcoin",
      "coinbase", "binance", "robinhood", "etrade", "fidelity", "vanguard", "schwab"
    ]
  },

  // ============ CASHBACK & REWARDS (Priority 2) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 2,
    keywords: [
      "cashback", "cash back", "reward", "rewards", "loyalty",
      "points redemption", "rebate"
    ]
  },

  // ============ MOBILE / DIGITAL PAYMENTS (Priority 2) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 2,
    keywords: [
      "mobile payment", "digital payment", "online payment",
      "payment transfer", "fund transfer"
    ]
  },

  // ============ CREDIT CARD PAYMENT (Priority 1) ============
  {
    categoryGroup: "Financial",
    category: "Payment & Transfers",
    priority: 1,
    keywords: [
      "credit card payment", "payment recd", "payment received",
      "payment thank you", "autopay payment", "bill payment recd",
      "online payment received", "payment via mobile banking"
    ]
  },

  // ============ BANK FEES (Priority 2) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 2,
    keywords: [
      "bank fee", "atm fee", "service charge", "annual fee", "late fee",
      "interest charge", "overdraft fee", "wire fee", "transfer fee",
      "overlimit fee", "over limit fee", "over-limit fee", "excess limit fee",
      "finance charge", "cash advance fee", "penalty charge", "membership fee",
      "minimum balance fee", "returned payment fee", "nsf fee"
    ]
  },

  // ============ FOREX / CURRENCY EXCHANGE — moved to Priority 1 section above ============

  // ============ HOME SERVICES (Priority 3) ============
  {
    categoryGroup: "Other",
    category: "Home Maintenance",
    priority: 3,
    keywords: [
      "cleaning", "maid", "housekeeping",
      "plumber", "electrician", "handyman", "garden", "gardener", "landsca", "landscaping",
      "pest control", "moving", "storage",
      "merry maids", "molly maid", "handy", "taskrabbit", "angi", "thumbtack"
    ]
  },

  // ============ CHILDCARE (Priority 3) ============
  {
    categoryGroup: "Shopping",
    category: "Kids & Pets",
    priority: 3,
    keywords: [
      "daycare", "nursery", "preschool", "kindergarten",
      "babysitter", "nanny", "childcare", "after school"
    ]
  },

  // ============ BANK STATEMENT: HOUSING - RENT (Priority 1) ============
  // Multilingual rent payment keywords for bank statement descriptions
  {
    categoryGroup: "Housing & Utilities",
    category: "Housing",
    priority: 1,
    wordBoundary: true,
    stemMatch: true,
    keywords: [
      // English
      "rent", "rent payment", "rent transfer", "monthly rent", "apartment rent", "flat rent",
      "rental payment", "tenancy payment", "lease payment",
      // Turkish
      "kira", "kira ödemesi", "kira bedeli", "kira transferi", "ev kirası",
      "aylık kira", "daire kirası",
      // Arabic
      "إيجار", "دفع إيجار", "إيجار شهري", "إيجار شقة",
      // French
      "loyer", "paiement loyer", "loyer mensuel", "paiement du loyer",
      // Spanish
      "alquiler", "pago alquiler", "renta mensual", "pago de alquiler", "arriendo"
    ]
  },

  // ============ BANK STATEMENT: HOUSING - MORTGAGE (Priority 1) ============
  {
    categoryGroup: "Housing & Utilities",
    category: "Housing",
    priority: 1,
    wordBoundary: true,
    stemMatch: true,
    keywords: [
      // English
      "mortgage", "mortgage payment", "home loan", "housing loan",
      // Turkish
      "ipotek", "konut kredisi", "ev kredisi", "mortgage ödemesi",
      // Arabic
      "رهن عقاري", "قرض سكني", "قسط المنزل",
      // French
      "hypothèque", "prêt immobilier", "crédit immobilier", "prêt hypothécaire",
      // Spanish
      "hipoteca", "pago hipoteca", "préstamo hipotecario", "crédito hipotecario"
    ]
  },

  // ============ BANK STATEMENT: SALARY / INCOME (Priority 1) ============
  {
    categoryGroup: "Employment",
    category: "Salary & Allowances",
    priority: 1,
    wordBoundary: true,
    stemMatch: true,
    keywords: [
      // English
      "salary", "payroll", "wages", "monthly salary", "net salary", "gross salary",
      "pay check", "paycheck",
      // Turkish
      "maaş", "maaş ödemesi", "aylık maaş", "ücret", "bordro",
      // Arabic
      "راتب", "رواتب", "أجر", "مرتب",
      // French
      "salaire", "paie", "paye", "rémunération", "bulletin de paie",
      // Spanish
      "sueldo", "salario", "nómina", "pago salarial"
    ]
  },

  // ============ BANK STATEMENT: UTILITIES / BILLS (Priority 1) ============
  {
    categoryGroup: "Housing & Utilities",
    category: "Utilities",
    priority: 1,
    wordBoundary: true,
    stemMatch: true,
    keywords: [
      // Turkish
      "fatura", "fatura ödemesi", "elektrik faturası", "su faturası", "doğalgaz",
      "doğalgaz faturası", "telefon faturası",
      // Arabic
      "فاتورة", "فواتير", "فاتورة كهرباء", "فاتورة ماء", "فاتورة غاز",
      // French
      "facture", "facture électricité", "facture eau", "facture gaz",
      // Spanish
      "factura", "recibo", "factura de luz", "factura de agua", "factura de gas",
      "recibo de luz"
    ]
  },

  // ============ BANK STATEMENT: LOAN / INSTALLMENT (Priority 2) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 2,
    wordBoundary: true,
    stemMatch: true,
    keywords: [
      // English
      "loan payment", "loan installment", "instalment", "installment",
      "personal loan", "car loan payment", "student loan",
      // Turkish
      "taksit", "kredi taksiti", "kredi ödemesi", "bireysel kredi",
      "taşıt kredisi", "ihtiyaç kredisi",
      // Arabic
      "قسط", "أقساط", "قرض شخصي", "سداد قرض",
      // French
      "prêt", "mensualité", "échéance", "remboursement prêt", "crédit personnel",
      // Spanish
      "cuota", "cuota préstamo", "pago préstamo", "crédito personal", "préstamo personal"
    ]
  },

  // ============ BANK STATEMENT: BANK TRANSFER (Priority 3) ============
  // Generic bank transfers — lower priority so specific categories win first
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 3,
    wordBoundary: true,
    keywords: [
      // English
      "bank transfer", "wire transfer", "standing order", "direct debit",
      "account transfer", "outgoing transfer", "incoming transfer",
      // Turkish
      "havale", "eft", "virman", "para transferi", "hesap transferi",
      "otomatik ödeme", "düzenli ödeme",
      // Arabic
      "حوالة", "تحويل", "تحويل بنكي", "حوالة مصرفية", "أمر دائم",
      // French
      "virement", "virement bancaire", "prélèvement", "ordre permanent",
      "virement sortant", "virement entrant",
      // Spanish
      "transferencia", "transferencia bancaria", "domiciliación",
      "orden permanente", "débito directo"
    ]
  },

  // ============ BANK STATEMENT: MULTILINGUAL BANK FEES (Priority 2) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 2,
    keywords: [
      // Turkish
      "hesap işletim ücreti", "hesap ücreti", "komisyon", "masraf",
      "dönem faizi", "gecikme faizi", "kart aidatı", "kart ücreti",
      "ekstre ücreti", "havale masrafı", "eft masrafı",
      // Arabic
      "رسوم بنكية", "عمولة", "رسوم خدمة", "رسوم سنوية",
      "رسوم تحويل", "فائدة", "غرامة تأخير",
      // French
      "frais bancaires", "frais de service", "commission", "frais de tenue",
      "frais de gestion", "agios", "intérêts débiteurs", "frais de virement",
      "cotisation carte",
      // Spanish
      "comisión", "comisión bancaria", "cargo por servicio", "cuota anual",
      "cargo por mantenimiento", "intereses", "penalización",
      "comisión de transferencia"
    ]
  },

  // ============ BANK STATEMENT: ATM OPERATIONS (Priority 1) ============
  {
    categoryGroup: "Financial",
    category: "Financial",
    priority: 1,
    wordBoundary: true,
    keywords: [
      // English
      "atm withdrawal", "atm deposit", "cash withdrawal", "cash deposit",
      // Turkish
      "atm çekim", "atm yatırma", "nakit çekim", "nakit yatırma", "para çekme",
      "para yatırma",
      // Arabic
      "سحب نقدي", "إيداع نقدي", "سحب من الصراف",
      // French
      "retrait dab", "retrait distributeur", "dépôt espèces",
      // Spanish
      "retiro cajero", "depósito cajero", "retiro efectivo"
    ]
  }
];

let SORTED_KEYWORDS: UnifiedKeywordEntry[] = [...UNIFIED_KEYWORDS].sort((a, b) => a.priority - b.priority);

export function replaceActiveKeywords(keywords: UnifiedKeywordEntry[]): void {
  SORTED_KEYWORDS = [...keywords].sort((a, b) => a.priority - b.priority);
  console.log(`[CategoryKeywords] Active keywords replaced: ${SORTED_KEYWORDS.length} entries`);
}

export function resetToBuiltinKeywords(): void {
  SORTED_KEYWORDS = [...UNIFIED_KEYWORDS].sort((a, b) => a.priority - b.priority);
  console.log(`[CategoryKeywords] Reset to bundled keywords: ${SORTED_KEYWORDS.length} entries`);
}

const TRANSLITERATION_MAP: Record<string, string> = {
  'ö': 'o', 'ü': 'u', 'ç': 'c', 'ş': 's', 'ğ': 'g', 'ı': 'i',
  'İ': 'i', 'i̇': 'i',
  'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e',
  'á': 'a', 'à': 'a', 'â': 'a', 'ã': 'a',
  'ñ': 'n', 'ú': 'u', 'ù': 'u', 'û': 'u',
  'ó': 'o', 'ò': 'o', 'ô': 'o', 'î': 'i', 'ï': 'i',
};

function normalizeTextForKeyword(text: string): string {
  let result = text.toLowerCase();
  for (const [from, to] of Object.entries(TRANSLITERATION_MAP)) {
    result = result.replaceAll(from, to);
  }
  return result
    .replace(/[''`]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function matchesKeyword(text: string, keyword: string, useWordBoundary: boolean, useStemMatch: boolean = false): boolean {
  const normalizedKeyword = normalizeTextForKeyword(keyword);
  if (!normalizedKeyword) return false;
  
  const escapedKeyword = normalizedKeyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  if (useStemMatch && normalizedKeyword.length >= 4) {
    const regex = new RegExp(`\\b${escapedKeyword}\\w*`, 'i');
    return regex.test(text);
  }

  if (useWordBoundary || normalizedKeyword.length <= 4) {
    const regex = new RegExp(`\\b${escapedKeyword}\\b`, 'i');
    return regex.test(text);
  }
  
  return text.includes(normalizedKeyword);
}

/**
 * Infer category from merchant name and description using keyword matching.
 * Returns the category string for the first matching keyword entry.
 * Uses pre-sorted SORTED_KEYWORDS for performance (priority 1 checked first).
 */
export function inferCategoryFromKeywords(
  merchant: string, 
  isIncome: boolean, 
  description?: string
): string {
  if (!merchant && !description) return isIncome ? "Other" : "Other";
  
  const normalizedMerchant = normalizeTextForKeyword(merchant || "");
  const normalizedDescription = normalizeTextForKeyword(description || "");
  const combinedText = `${normalizedMerchant} ${normalizedDescription}`.trim();
  
  for (const entry of SORTED_KEYWORDS) {
    const useWordBoundary = entry.wordBoundary ?? false;
    const useStemMatch = entry.stemMatch ?? false;
    for (const keyword of entry.keywords) {
      if (matchesKeyword(combinedText, keyword, useWordBoundary, useStemMatch)) {
        return entry.category;
      }
    }
  }
  
  return isIncome ? "Other" : "Other";
}

/**
 * Match by keyword and return both categoryGroup and category.
 * Used by merchantMatcher.ts for fallback matching.
 * Uses pre-sorted SORTED_KEYWORDS for performance.
 */
export function matchByKeyword(text: string): { categoryGroup: string; category: string } | null {
  const normalizedText = normalizeTextForKeyword(text);
  
  for (const entry of SORTED_KEYWORDS) {
    const useWordBoundary = entry.wordBoundary ?? false;
    const useStemMatch = entry.stemMatch ?? false;
    for (const keyword of entry.keywords) {
      if (matchesKeyword(normalizedText, keyword, useWordBoundary, useStemMatch)) {
        return { categoryGroup: entry.categoryGroup, category: entry.category };
      }
    }
  }
  
  return null;
}

// ============================================================================
// SOURCE OF TRUTH: Category Definitions
// These match exactly what is seeded in expense_category_definitions and 
// income_category_definitions tables. Used for normalization and validation.
// ============================================================================

// Aliases and mapToSourceOfTruthCategory have been consolidated into code/categoryGuard.ts
