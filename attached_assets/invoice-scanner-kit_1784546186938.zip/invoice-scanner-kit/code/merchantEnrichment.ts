/**
 * AI merchant enrichment.
 *
 * Merchants that fail the three-tier matcher can be batch-classified with an
 * LLM (Anthropic Claude by default). Validated results are inserted into the
 * global merchant table through the MerchantStorage interface, so the next
 * lookup hits tier 2 (exact normalized match) without an AI call.
 *
 * Environment:
 *   ANTHROPIC_API_KEY  — required
 *   ANTHROPIC_BASE_URL — optional (custom gateway)
 */

import Anthropic from "@anthropic-ai/sdk";
import crypto from "crypto";
import type { MerchantStorage, GlobalMerchantRecord } from "./storage";
import { EXPENSE_CATEGORY_GROUPS } from "../config/categories";
import { mapToSourceOfTruthCategory, mapToSourceOfTruthSubcategory } from "./categoryGuard";

const VALID_GROUP_NAMES = new Set(EXPENSE_CATEGORY_GROUPS.map(g => g.title));

const MODEL = process.env.ENRICHMENT_MODEL || "claude-sonnet-4-5";
const SOURCE_TAG = "ai_enrichment_v1";
const CONFIDENCE = 0.75;

export interface MerchantToEnrich {
  rawDescription: string;
  normalizedName: string;
}

export interface EnrichmentResult {
  rawDescription: string;
  normalizedName: string;
  canonicalName: string;
  categoryGroup: string;
  category: string;
  subcategory?: string;
}

function buildCategoryTaxonomy(): string {
  return EXPENSE_CATEGORY_GROUPS.map(group => {
    const cats = group.categories.map(c => c.name).join(", ");
    return `  ${group.title}: [${cats}]`;
  }).join("\n");
}

function buildPrompt(merchants: MerchantToEnrich[], region: string): string {
  const taxonomy = buildCategoryTaxonomy();
  const merchantList = merchants.map((m, i) =>
    `${i + 1}. "${m.rawDescription}"`
  ).join("\n");

  return `You are a financial transaction categorization expert with deep knowledge of merchants worldwide. Classify each merchant/transaction description into the correct expense category.

CATEGORY TAXONOMY (you MUST use EXACTLY these category names):
${taxonomy}

RULES:
- Return a JSON array with one object per merchant
- "canonicalName": The clean, human-readable merchant/business name. Keep ALL words that are part of the brand identity (e.g., "FACEBK *MCZ768VPF2" → "Facebook Ads"). Only strip location codes, card numbers, terminal IDs, and payment noise — never strip words that are part of the merchant's actual name or brand prefix.
- "categoryGroup": Must be EXACTLY one of the group names listed above
- "category": Must be EXACTLY one of the category names listed under that group
- "subcategory": A freeform descriptor for the merchant's specific niche (e.g., "Fast Food", "E-Commerce", "Streaming Platform"). For restaurants, use the cuisine type
- If you are uncertain about a merchant, use categoryGroup: "Other", category: "Other"
- Do NOT invent categories. Only use the exact names provided above. subcategory is freeform
- Region context: ${region || "global"}
- Merchants may be in any language. Use your knowledge of local brands, retailers, telecoms, restaurants, etc.

MERCHANTS TO CLASSIFY:
${merchantList}

Respond with ONLY a JSON array, no other text:
[{"index": 1, "canonicalName": "...", "categoryGroup": "...", "category": "...", "subcategory": "..."}, ...]`;
}

export async function enrichUnknownMerchants(
  storage: MerchantStorage,
  merchants: MerchantToEnrich[],
  region: string = "global"
): Promise<EnrichmentResult[]> {
  if (!merchants.length) return [];

  const uniqueMerchants = deduplicateMerchants(merchants);
  if (!uniqueMerchants.length) return [];

  const unknowns = await filterAlreadyKnown(storage, uniqueMerchants);
  if (!unknowns.length) {
    console.log(`[MerchantEnrichment] All ${uniqueMerchants.length} merchants already in global DB — skipping AI call`);
    return [];
  }

  console.log(`[MerchantEnrichment] Enriching ${unknowns.length} unknown merchants (${uniqueMerchants.length - unknowns.length} already known)`);

  try {
    const anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
      baseURL: process.env.ANTHROPIC_BASE_URL || undefined,
    });

    const prompt = buildPrompt(unknowns, region);

    const response = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 4096,
      messages: [{ role: "user", content: prompt }],
    });

    const textBlock = response.content.find(b => b.type === "text");
    if (!textBlock || textBlock.type !== "text") {
      console.error("[MerchantEnrichment] No text in AI response");
      return [];
    }

    const jsonMatch = textBlock.text.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      console.error("[MerchantEnrichment] No JSON array found in response");
      return [];
    }

    const parsed: Array<{
      index: number;
      canonicalName: string;
      categoryGroup: string;
      category: string;
      subcategory?: string;
    }> = JSON.parse(jsonMatch[0]);

    const GROUP_TO_CATEGORIES = new Map<string, Set<string>>();
    for (const g of EXPENSE_CATEGORY_GROUPS) {
      GROUP_TO_CATEGORIES.set(g.title, new Set(g.categories.map(c => c.name)));
    }

    const seenIndices = new Set<number>();
    const results: EnrichmentResult[] = [];
    for (const item of parsed) {
      if (!item.index || !item.canonicalName || !item.category) continue;
      if (seenIndices.has(item.index)) continue;
      seenIndices.add(item.index);

      const merchant = unknowns[item.index - 1];
      if (!merchant) continue;

      const validatedCategory = mapToSourceOfTruthCategory(item.category, false);
      let validatedGroup = VALID_GROUP_NAMES.has(item.categoryGroup) ? item.categoryGroup : "Other";

      const groupCats = GROUP_TO_CATEGORIES.get(validatedGroup);
      if (groupCats && !groupCats.has(validatedCategory)) {
        for (const [gName, gCats] of GROUP_TO_CATEGORIES) {
          if (gCats.has(validatedCategory)) {
            validatedGroup = gName;
            break;
          }
        }
      }

      const validatedSubcategory = mapToSourceOfTruthSubcategory(item.subcategory, validatedCategory, false);
      results.push({
        rawDescription: merchant.rawDescription,
        normalizedName: merchant.normalizedName,
        canonicalName: item.canonicalName || merchant.rawDescription,
        categoryGroup: validatedGroup,
        category: validatedCategory,
        subcategory: validatedSubcategory || undefined,
      });
    }

    console.log(`[MerchantEnrichment] AI classified ${results.length}/${unknowns.length} merchants`);
    return results;
  } catch (error: any) {
    console.error(`[MerchantEnrichment] AI enrichment failed: ${error.message}`);
    return [];
  }
}

export async function insertEnrichedMerchants(
  storage: MerchantStorage,
  results: EnrichmentResult[],
  region: string = "global"
): Promise<number> {
  if (!results.length) return 0;

  let inserted = 0;
  let updated = 0;
  for (const r of results) {
    const merchantId = `AI_${region}_${crypto.createHash("md5").update(r.normalizedName).digest("hex").substring(0, 12)}`;

    const record: GlobalMerchantRecord = {
      merchantId,
      merchantName: r.canonicalName,
      normalizedName: r.normalizedName,
      variant: null,
      categoryGroup: r.categoryGroup,
      category: r.category,
      subcategory: r.subcategory || null,
      region,
      confidence: CONFIDENCE,
      source: SOURCE_TAG,
    };

    try {
      const wasInserted = await storage.insertGlobalMerchant(record);
      if (wasInserted) inserted++;
    } catch (error: any) {
      if (!error.message?.includes("duplicate") && !error.message?.includes("unique")) {
        console.error(`[MerchantEnrichment] Insert failed for "${r.canonicalName}": ${error.message}`);
      }
    }

    try {
      updated += await storage.updateGlobalMerchantCategoryIfEmpty(
        r.normalizedName,
        r.category,
        r.categoryGroup,
        r.subcategory || null,
      );
    } catch (error: any) {
      console.error(`[MerchantEnrichment] Update failed for "${r.normalizedName}": ${error.message}`);
    }
  }

  console.log(`[MerchantEnrichment] Inserted ${inserted} new, updated ${updated} existing merchants`);
  return inserted;
}

function deduplicateMerchants(merchants: MerchantToEnrich[]): MerchantToEnrich[] {
  const seen = new Set<string>();
  return merchants.filter(m => {
    if (seen.has(m.normalizedName)) return false;
    seen.add(m.normalizedName);
    return true;
  });
}

async function filterAlreadyKnown(storage: MerchantStorage, merchants: MerchantToEnrich[]): Promise<MerchantToEnrich[]> {
  if (!merchants.length) return [];

  try {
    const unknown: MerchantToEnrich[] = [];
    for (const m of merchants) {
      const existing = await storage.findGlobalMerchantByNormalizedName(m.normalizedName);
      if (existing && existing.category && existing.category.trim()) continue;
      unknown.push(m);
    }
    return unknown;
  } catch (error: any) {
    console.error(`[MerchantEnrichment] DB lookup failed: ${error.message}`);
    return merchants;
  }
}
