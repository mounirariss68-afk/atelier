import { execFile } from "child_process";
import { writeFileSync, readFileSync, unlinkSync, existsSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

const DEFAULT_DPI = 300;
const DEFAULT_LANGUAGES = ["eng"];

export interface OcrPageResult {
  pageNumber: number;
  text: string;
  confidence: number;
}

export interface OcrQualityAssessment {
  isUsable: boolean;
  dateCount: number;
  amountCount: number;
  garbleRatio: number;
  charCount: number;
}

const DATE_PATTERNS = [
  /\d{1,2}(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\d{4}/gi,
  /\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}/g,
  /\d{1,2}\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}/gi,
];

const AMOUNT_PATTERN = /\d{1,3}(?:,\d{3})*\.\d{2}\b/g;

const GARBLE_PATTERN = /[^\x20-\x7E\xA0-\xFF\n\r\t]/;

export async function renderPageImage(
  pdfData: Uint8Array,
  pageNumber: number,
  dpi: number = DEFAULT_DPI,
  password?: string
): Promise<Buffer> {
  const tempId = `ocr_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const pdfPath = join(tmpdir(), `${tempId}.pdf`);
  const outPrefix = join(tmpdir(), `${tempId}_out`);
  const outFile = `${outPrefix}-${String(pageNumber).padStart(6, "0")}.png`;
  const outFileSingle = `${outPrefix}.png`;

  try {
    writeFileSync(pdfPath, pdfData);

    const args: string[] = ["-png", "-r", String(dpi)];
    if (password) {
      args.push("-upw", password);
    }
    args.push(
      "-f", String(pageNumber),
      "-l", String(pageNumber),
      "-singlefile",
      pdfPath,
      outPrefix
    );

    await execFileAsync("pdftoppm", args, { timeout: 30000 });

    const actualOutFile = existsSync(outFileSingle) ? outFileSingle : outFile;
    if (!existsSync(actualOutFile)) {
      throw new Error(`pdftoppm did not produce output file for page ${pageNumber}`);
    }

    return readFileSync(actualOutFile);
  } finally {
    try { unlinkSync(pdfPath); } catch {}
    try { unlinkSync(outFile); } catch {}
    try { unlinkSync(outFileSingle); } catch {}
  }
}

export async function ocrPage(
  imageBuffer: Buffer,
  languages: string[] = DEFAULT_LANGUAGES
): Promise<{ text: string; confidence: number }> {
  const tempId = `ocr_img_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const imgPath = join(tmpdir(), `${tempId}.png`);

  try {
    writeFileSync(imgPath, imageBuffer);

    const langArg = languages.join("+");
    const { stdout } = await execFileAsync(
      "tesseract",
      [imgPath, "stdout", "-l", langArg, "--psm", "6"],
      { timeout: 30000, maxBuffer: 10 * 1024 * 1024 }
    );

    const text = stdout || "";
    const words = text.split(/\s+/).filter(w => w.length > 0);
    const totalWords = words.length;
    const garbledWords = words.filter(w => GARBLE_PATTERN.test(w)).length;
    const confidence = totalWords > 0 ? Math.max(0, 1 - (garbledWords / totalWords)) : 0;

    return { text, confidence };
  } finally {
    try { unlinkSync(imgPath); } catch {}
  }
}

export async function ocrPdfPages(
  pdfData: Uint8Array,
  pageNumbers: number[],
  dpi: number = DEFAULT_DPI,
  languages: string[] = DEFAULT_LANGUAGES,
  password?: string
): Promise<OcrPageResult[]> {
  const results: OcrPageResult[] = [];

  const tempId = `ocr_batch_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const pdfPath = join(tmpdir(), `${tempId}.pdf`);

  try {
    writeFileSync(pdfPath, pdfData);

    for (const pageNum of pageNumbers) {
      const outPrefix = join(tmpdir(), `${tempId}_p${pageNum}`);
      const outFile = `${outPrefix}.png`;

      try {
        const args: string[] = ["-png", "-r", String(dpi)];
        if (password) {
          args.push("-upw", password);
        }
        args.push(
          "-f", String(pageNum),
          "-l", String(pageNum),
          "-singlefile",
          pdfPath,
          outPrefix
        );

        await execFileAsync("pdftoppm", args, { timeout: 30000 });

        if (!existsSync(outFile)) {
          console.warn(`[OCR] pdftoppm produced no output for page ${pageNum}`);
          results.push({ pageNumber: pageNum, text: "", confidence: 0 });
          continue;
        }

        const imgBuffer = readFileSync(outFile);
        const { text, confidence } = await ocrPage(imgBuffer, languages);
        results.push({ pageNumber: pageNum, text, confidence });

        console.log(`[OCR] Page ${pageNum}: ${text.length} chars, confidence ${(confidence * 100).toFixed(1)}%`);
      } catch (err: any) {
        console.error(`[OCR] Failed to OCR page ${pageNum}:`, err.message);
        results.push({ pageNumber: pageNum, text: "", confidence: 0 });
      } finally {
        try { unlinkSync(outFile); } catch {}
      }
    }
  } finally {
    try { unlinkSync(pdfPath); } catch {}
  }

  return results;
}

export function assessOcrQuality(text: string): OcrQualityAssessment {
  const charCount = text.length;

  let dateCount = 0;
  for (const pattern of DATE_PATTERNS) {
    const matches = text.match(pattern);
    if (matches) dateCount += matches.length;
  }

  const amountMatches = text.match(AMOUNT_PATTERN);
  const amountCount = amountMatches ? amountMatches.length : 0;

  const garbleMatches = text.match(/[^\x20-\x7E\xA0-\xFF\n\r\t]/g);
  const garbleCount = garbleMatches ? garbleMatches.length : 0;
  const garbleRatio = charCount > 0 ? garbleCount / charCount : 1;

  const isUsable = charCount > 100 && garbleRatio < 0.15 && (dateCount >= 1 || amountCount >= 2);

  return { isUsable, dateCount, amountCount, garbleRatio, charCount };
}

export async function renderPageImageFromPath(
  pdfPath: string,
  pageNumber: number,
  dpi: number = DEFAULT_DPI,
  password?: string
): Promise<Buffer> {
  const tempId = `ocr_rp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const outPrefix = join(tmpdir(), `${tempId}_out`);
  const outFile = `${outPrefix}.png`;

  try {
    const args: string[] = ["-png", "-r", String(dpi)];
    if (password) {
      args.push("-upw", password);
    }
    args.push(
      "-f", String(pageNumber),
      "-l", String(pageNumber),
      "-singlefile",
      pdfPath,
      outPrefix
    );

    await execFileAsync("pdftoppm", args, { timeout: 30000 });

    if (!existsSync(outFile)) {
      throw new Error(`pdftoppm did not produce output file for page ${pageNumber}`);
    }

    return readFileSync(outFile);
  } finally {
    try { unlinkSync(outFile); } catch {}
  }
}
