/**
 * Single-receipt / invoice parser.
 *
 * Two entry points:
 *   - parseReceiptImage(...)  — AI vision parse of a photo/scan (base64 image)
 *   - parseReceiptPdf(...)    — PDF text extraction with automatic OCR
 *                               fallback, then AI parse of the extracted text
 *
 * Both return a ParsedReceipt:
 *   { merchant, normalizedMerchant, date, amount, currency, suggestedCategory }
 *
 * Environment:
 *   OPENAI_API_KEY  — required
 *   OPENAI_BASE_URL — optional (custom gateway)
 *   RECEIPT_MODEL   — optional, defaults to "gpt-4o"
 */

import OpenAI from "openai";
import { normalizeMerchant } from "../merchantNormalizer";
import { matchMerchant } from "../merchantMatcher";
import type { MerchantStorage } from "../storage";
import { mapToSourceOfTruthCategory } from "../categoryGuard";
import { EXPENSE_CATEGORIES_FLAT } from "../../config/categories";
import { extractPdfText } from "./pdfTextExtractor";

export interface ParsedReceipt {
  merchant: string;
  normalizedMerchant: string;
  /** ISO date YYYY-MM-DD */
  date: string;
  /** Grand total (always positive) */
  amount: number;
  /** ISO 4217 currency code */
  currency: string;
  suggestedCategory: string;
  /** 0..1 — AI extraction confidence */
  confidence: number;
  /** How the category was chosen: user_mapping | database | token | keyword | ai | default */
  categoryResolution: string;
}

const MODEL = process.env.RECEIPT_MODEL || "gpt-4o";

function buildSystemPrompt(): string {
  const categories = EXPENSE_CATEGORIES_FLAT.join(", ");
  return `You are a receipt parsing engine for an expense app.
Your job is to extract structured transaction details from a receipt or invoice.

CRITICAL RULE - ONE RECEIPT = ONE TRANSACTION:
A single receipt ALWAYS represents ONE transaction, regardless of how many items are listed.
Do NOT return line items separately — return only the grand total.

RECEIPT STRUCTURE:
1. HEADER: Merchant name, address, date, receipt number
2. LINE ITEMS: individual products/services (ignore for the amount)
3. TOTALS: subtotal, tax, service charge, GRAND TOTAL (use this)

RULES:
- The receipt can be in ANY language. Do not assume English.
- Extract the merchant/business name from the header.
- Detect the transaction date. Use ISO format YYYY-MM-DD. If multiple dates exist, choose the purchase date, not print date. For hotel invoices, use check-out date. If no date is visible, use an empty string.
- Extract the grand total as a positive number.
- Detect the currency (ISO 4217 code like USD, EUR, GBP, TRY, AED). Infer from symbols or context if not explicit.
- Suggest a category from EXACTLY this list: ${categories}
- "confidence": 0.0-1.0 for the overall extraction quality.

Respond with ONLY a JSON object:
{"merchant": "...", "date": "YYYY-MM-DD", "amount": 0.00, "currency": "USD", "suggestedCategory": "...", "confidence": 0.9}`;
}

interface RawAiReceipt {
  merchant?: string;
  date?: string;
  amount?: number;
  currency?: string;
  suggestedCategory?: string;
  confidence?: number;
}

async function finalizeParsedReceipt(
  raw: RawAiReceipt,
  storage: MerchantStorage | null,
  defaultCurrency: string,
  userId?: string
): Promise<ParsedReceipt> {
  const merchant = (raw.merchant || "Unknown").trim();
  const normalizedMerchant = normalizeMerchant(merchant);

  // Resolve category through the three-tier matcher when storage is provided;
  // fall back to the (validated) AI suggestion otherwise.
  let suggestedCategory = mapToSourceOfTruthCategory(raw.suggestedCategory, false);
  let categoryResolution = raw.suggestedCategory ? "ai" : "default";

  if (storage && merchant && merchant !== "Unknown") {
    const match = await matchMerchant(storage, merchant, "global", userId);
    if (match.matchMethod !== "NONE" && match.confidence >= 0.5) {
      suggestedCategory = match.category;
      categoryResolution =
        match.matchMethod === "USER_MAPPING" ? "user_mapping" :
        match.matchMethod === "EXACT_NORMALIZED" ? "database" :
        match.matchMethod.startsWith("TOKEN") ? "token" :
        "keyword";
    }
  }

  return {
    merchant,
    normalizedMerchant,
    date: raw.date && /^\d{4}-\d{2}-\d{2}$/.test(raw.date) ? raw.date : new Date().toISOString().split("T")[0],
    amount: typeof raw.amount === "number" ? Math.abs(raw.amount) : 0,
    currency: (raw.currency || defaultCurrency).toUpperCase(),
    suggestedCategory,
    confidence: typeof raw.confidence === "number" ? raw.confidence : 0.5,
    categoryResolution,
  };
}

function createClient(): OpenAI {
  return new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
    baseURL: process.env.OPENAI_BASE_URL || undefined,
  });
}

function parseAiJson(content: string | null | undefined): RawAiReceipt {
  if (!content) throw new Error("Empty AI response");
  return JSON.parse(content) as RawAiReceipt;
}

/**
 * Parse a receipt photo/scan. `imageBase64` may be a raw base64 string or a
 * full data URL.
 */
export async function parseReceiptImage(
  imageBase64: string,
  options: {
    storage?: MerchantStorage;
    defaultCurrency?: string;
    userId?: string;
  } = {}
): Promise<ParsedReceipt> {
  const openai = createClient();

  const response = await openai.chat.completions.create({
    model: MODEL,
    messages: [
      { role: "system", content: buildSystemPrompt() },
      {
        role: "user",
        content: [
          { type: "text", text: "Parse this receipt image and extract the expense details." },
          {
            type: "image_url",
            image_url: {
              url: imageBase64.startsWith("data:")
                ? imageBase64
                : `data:image/jpeg;base64,${imageBase64}`,
            },
          },
        ],
      },
    ],
    response_format: { type: "json_object" },
    max_tokens: 800,
    temperature: 0,
  });

  const raw = parseAiJson(response.choices[0]?.message?.content);
  return finalizeParsedReceipt(raw, options.storage ?? null, options.defaultCurrency || "USD", options.userId);
}

/**
 * Parse a PDF receipt/invoice. Extracts embedded text first; if the PDF is a
 * scan without a usable text layer, automatically falls back to OCR
 * (requires the `pdftoppm` and `tesseract` binaries — see ocrEngine.ts).
 */
export async function parseReceiptPdf(
  pdfData: Uint8Array,
  options: {
    storage?: MerchantStorage;
    defaultCurrency?: string;
    userId?: string;
    password?: string;
    ocrLanguages?: string[];
  } = {}
): Promise<ParsedReceipt> {
  const { text, method } = await extractPdfText(pdfData, {
    password: options.password,
    ocrLanguages: options.ocrLanguages,
  });

  if (!text.trim()) {
    throw new Error("Could not extract any text from the PDF (text layer empty and OCR produced nothing)");
  }

  console.log(`[ReceiptParser] PDF text extracted via ${method} (${text.length} chars)`);

  const openai = createClient();

  const response = await openai.chat.completions.create({
    model: MODEL,
    messages: [
      { role: "system", content: buildSystemPrompt() },
      {
        role: "user",
        content: `Parse this receipt/invoice text and extract the expense details:\n\n${text.slice(0, 12000)}`,
      },
    ],
    response_format: { type: "json_object" },
    max_tokens: 800,
    temperature: 0,
  });

  const raw = parseAiJson(response.choices[0]?.message?.content);
  return finalizeParsedReceipt(raw, options.storage ?? null, options.defaultCurrency || "USD", options.userId);
}
