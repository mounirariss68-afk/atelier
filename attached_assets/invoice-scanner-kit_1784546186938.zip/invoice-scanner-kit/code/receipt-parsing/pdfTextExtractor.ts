/**
 * PDF text extraction with automatic OCR fallback.
 *
 * 1. Try the PDF's embedded text layer via pdfjs-dist.
 * 2. Assess text quality (length, garble ratio, presence of dates/amounts).
 * 3. If unusable (scanned/image-only PDF), render pages with `pdftoppm` and
 *    OCR them with `tesseract` (see ocrEngine.ts for binary requirements).
 */

import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.mjs";
import { ocrPdfPages, assessOcrQuality } from "./ocrEngine";

export interface PdfTextResult {
  text: string;
  method: "text_layer" | "ocr";
  pageCount: number;
}

const MAX_PAGES = 5;

async function extractTextLayer(pdfData: Uint8Array, password?: string): Promise<{ text: string; pageCount: number }> {
  const loadingTask = pdfjsLib.getDocument({
    data: pdfData,
    password,
    useSystemFonts: true,
  });

  const doc = await loadingTask.promise;
  const pageCount = doc.numPages;
  const pages: string[] = [];

  for (let i = 1; i <= Math.min(pageCount, MAX_PAGES); i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items
      .map((item: any) => (typeof item.str === "string" ? item.str : ""))
      .join(" ");
    pages.push(pageText);
  }

  await doc.destroy();
  return { text: pages.join("\n\n"), pageCount };
}

export async function extractPdfText(
  pdfData: Uint8Array,
  options: { password?: string; ocrLanguages?: string[] } = {}
): Promise<PdfTextResult> {
  let textLayer = "";
  let pageCount = 1;

  try {
    const result = await extractTextLayer(pdfData, options.password);
    textLayer = result.text;
    pageCount = result.pageCount;
  } catch (error: any) {
    console.warn(`[PdfTextExtractor] Text-layer extraction failed: ${error.message}`);
  }

  const quality = assessOcrQuality(textLayer);
  if (quality.isUsable) {
    return { text: textLayer, method: "text_layer", pageCount };
  }

  console.log(
    `[PdfTextExtractor] Text layer unusable (chars=${quality.charCount}, garble=${quality.garbleRatio.toFixed(2)}, dates=${quality.dateCount}, amounts=${quality.amountCount}) — falling back to OCR`
  );

  const pagesToOcr = Array.from({ length: Math.min(pageCount, MAX_PAGES) }, (_, i) => i + 1);
  const ocrResults = await ocrPdfPages(
    pdfData,
    pagesToOcr,
    300,
    options.ocrLanguages || ["eng"],
    options.password
  );

  const ocrText = ocrResults.map(r => r.text).join("\n\n");
  return { text: ocrText, method: "ocr", pageCount };
}
