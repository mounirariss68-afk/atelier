/**
 * REFERENCE PATTERN — Expo receipt capture screen.
 *
 * A self-contained example showing the client-side flow that pairs with
 * code/receipt-parsing/:
 *
 *   1. Capture a photo (expo-image-picker camera) or pick from gallery,
 *      or pick a PDF (expo-document-picker).
 *   2. Compress/resize the image (expo-image-manipulator) to keep upload
 *      and AI-vision costs down.
 *   3. POST base64 payload to your backend parse endpoint.
 *   4. Show the parsed result (merchant, date, amount, currency, category)
 *      for user confirmation before saving.
 *
 * This file is NOT wired into any navigator — copy it into your app and
 * adapt the styling/endpoint. It intentionally avoids app-specific theme,
 * i18n and query-client dependencies.
 *
 * Expected packages (all Expo Go compatible):
 *   expo-image-picker, expo-image-manipulator, expo-document-picker,
 *   expo-file-system
 */

import React, { useState } from "react";
import {
  View,
  Text,
  Pressable,
  ActivityIndicator,
  StyleSheet,
  Alert,
  ScrollView,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";

// Point this at your backend. In Expo, prefer an env-injected base URL
// (e.g. process.env.EXPO_PUBLIC_API_URL) — never hardcode hostnames.
// REQUIRED: EXPO_PUBLIC_API_URL must be set to an absolute URL
// (e.g. https://api.example.com). `new URL(path, base)` throws at runtime
// if the base is empty or relative.
const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || "";

function apiUrl(path: string): string {
  if (!API_BASE_URL) {
    throw new Error(
      "EXPO_PUBLIC_API_URL is not set — point it at your backend base URL",
    );
  }
  return new URL(path, API_BASE_URL).toString();
}

interface ParsedReceipt {
  merchant: string;
  normalizedMerchant: string;
  date: string;
  amount: number;
  currency: string;
  suggestedCategory: string;
  confidence: number;
}

// Tip: for further size reduction (resizing to ~1280px wide), add
// expo-image-manipulator and run manipulateAsync before upload. Here we rely
// on the picker's built-in quality compression + base64 output.
const PICKER_OPTIONS: ImagePicker.ImagePickerOptions = {
  mediaTypes: ["images"],
  quality: 0.7,
  base64: true,
};

export default function ReceiptCaptureScreen() {
  const [cameraPermission, requestCameraPermission] = ImagePicker.useCameraPermissions();
  const [isParsing, setIsParsing] = useState(false);
  const [parsed, setParsed] = useState<ParsedReceipt | null>(null);

  async function parseImageBase64(imageBase64: string) {
    setIsParsing(true);
    setParsed(null);
    try {
      const res = await fetch(apiUrl("/api/parse-receipt"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageBase64 }),
      });
      if (!res.ok) throw new Error(`Parse failed (${res.status})`);
      const data: ParsedReceipt = await res.json();
      setParsed(data);
    } catch (err: any) {
      Alert.alert("Couldn't read the receipt", err.message ?? "Please try again with a clearer photo.");
    } finally {
      setIsParsing(false);
    }
  }

  async function handleTakePhoto() {
    if (!cameraPermission?.granted) {
      const result = await requestCameraPermission();
      if (!result.granted) {
        if (!result.canAskAgain && Platform.OS !== "web") {
          Alert.alert("Camera access needed", "Enable camera access in Settings to scan receipts.");
        }
        return;
      }
    }

    const picked = await ImagePicker.launchCameraAsync(PICKER_OPTIONS);
    if (picked.canceled || !picked.assets?.[0]?.base64) return;

    await parseImageBase64(picked.assets[0].base64);
  }

  async function handlePickFromGallery() {
    const picked = await ImagePicker.launchImageLibraryAsync(PICKER_OPTIONS);
    if (picked.canceled || !picked.assets?.[0]?.base64) return;

    await parseImageBase64(picked.assets[0].base64);
  }

  async function handlePickPdf() {
    const picked = await DocumentPicker.getDocumentAsync({
      type: "application/pdf",
      copyToCacheDirectory: true,
    });
    if (picked.canceled || !picked.assets?.[0]?.uri) return;

    setIsParsing(true);
    setParsed(null);
    try {
      const pdfBase64 = await FileSystem.readAsStringAsync(picked.assets[0].uri, {
        encoding: "base64",
      });
      const res = await fetch(apiUrl("/api/parse-receipt"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pdfBase64 }),
      });
      if (!res.ok) throw new Error(`Parse failed (${res.status})`);
      const data: ParsedReceipt = await res.json();
      setParsed(data);
    } catch (err: any) {
      Alert.alert("Couldn't read the PDF", err.message ?? "Please try another file.");
    } finally {
      setIsParsing(false);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Scan a receipt</Text>
      <Text style={styles.subtitle}>
        Take a photo, choose an image, or upload a PDF invoice.
      </Text>

      <View style={styles.buttonRow}>
        <Pressable style={styles.button} onPress={handleTakePhoto} disabled={isParsing}>
          <Text style={styles.buttonText}>Take photo</Text>
        </Pressable>
        <Pressable style={styles.button} onPress={handlePickFromGallery} disabled={isParsing}>
          <Text style={styles.buttonText}>Gallery</Text>
        </Pressable>
        <Pressable style={styles.button} onPress={handlePickPdf} disabled={isParsing}>
          <Text style={styles.buttonText}>PDF</Text>
        </Pressable>
      </View>

      {isParsing ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" />
          <Text style={styles.loadingText}>Reading your receipt…</Text>
        </View>
      ) : null}

      {parsed ? (
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>{parsed.merchant}</Text>
          <ResultRow label="Date" value={parsed.date} />
          <ResultRow label="Amount" value={`${parsed.amount.toFixed(2)} ${parsed.currency}`} />
          <ResultRow label="Category" value={parsed.suggestedCategory} />
          <ResultRow label="Confidence" value={`${Math.round(parsed.confidence * 100)}%`} />
          <Pressable
            style={[styles.button, styles.confirmButton]}
            onPress={() => {
              // Save the confirmed expense to your backend here, then
              // navigate back / reset the form.
              Alert.alert("Saved", "Wire this button to your expense-create endpoint.");
              setParsed(null);
            }}
          >
            <Text style={styles.buttonText}>Confirm expense</Text>
          </Pressable>
        </View>
      ) : null}
    </ScrollView>
  );
}

function ResultRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.resultRow}>
      <Text style={styles.resultLabel}>{label}</Text>
      <Text style={styles.resultValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0f1115" },
  content: { padding: 20, paddingTop: 64, paddingBottom: 48 },
  title: { fontSize: 26, fontWeight: "700", color: "#ffffff" },
  subtitle: { fontSize: 15, color: "#9aa2b1", marginTop: 6, marginBottom: 20 },
  buttonRow: { flexDirection: "row", gap: 10 },
  button: {
    flex: 1,
    backgroundColor: "#2a67f4",
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
  },
  buttonText: { color: "#ffffff", fontWeight: "600", fontSize: 15 },
  loading: { alignItems: "center", marginTop: 40 },
  loadingText: { color: "#9aa2b1", marginTop: 12 },
  resultCard: {
    marginTop: 28,
    backgroundColor: "#1a1e27",
    borderRadius: 16,
    padding: 20,
  },
  resultTitle: { fontSize: 20, fontWeight: "700", color: "#ffffff", marginBottom: 12 },
  resultRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: "#2b3040",
  },
  resultLabel: { color: "#9aa2b1", fontSize: 14 },
  resultValue: { color: "#ffffff", fontSize: 14, fontWeight: "600" },
  confirmButton: { marginTop: 18, backgroundColor: "#1faa63" },
});
