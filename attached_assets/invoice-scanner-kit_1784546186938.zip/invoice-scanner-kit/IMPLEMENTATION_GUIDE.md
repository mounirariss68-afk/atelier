# Invoice Scanner Porting Kit

A self-contained port of the merchant-categorization and receipt-parsing
pipeline, packaged for reuse in a new app (e.g. an employee-expense tracker).
Everything typechecks standalone — no imports outside this folder.

## What's inside

```
invoice-scanner-kit/
├── IMPLEMENTATION_GUIDE.md      ← you are here
├── tsconfig.json                ← standalone typecheck config
├── config/
│   └── categories.ts            ← SWAP-IN category taxonomy (edit this first)
├── code/
│   ├── storage.ts               ← MerchantStorage interface + in-memory impl
│   ├── merchantConstants.ts     ← noise words, location suffixes, stopwords
│   ├── merchantNormalizer.ts    ← text normalization, tokenization, bigrams
│   ├── categoryKeywords.ts      ← multilingual keyword dictionary (~800 entries)
│   ├── categoryGuard.ts         ← category alias mapping + validation
│   ├── tokenMatcher.ts          ← IDF-weighted fuzzy matcher (in-memory index)
│   ├── merchantMatcher.ts       ← three-tier matcher (entry point)
│   ├── merchantEnrichment.ts    ← AI batch classification of unknown merchants
│   └── receipt-parsing/
│       ├── receiptParser.ts     ← single-receipt parse (image + PDF entry points)
│       ├── pdfTextExtractor.ts  ← PDF text layer → OCR fallback
│       └── ocrEngine.ts         ← pdftoppm + tesseract wrapper
├── data/
│   ├── schema.sql               ← standalone merchant/category tables
│   ├── seedMerchants.ts         ← CSV → Postgres seed script
│   ├── storageAdapter.example.ts← Postgres MerchantStorage implementation
│   ├── merchants_north_america.csv  (~750 brands, pipe-separated variants)
│   └── merchants_eu.csv             (~large, semicolon-separated variants)
└── client-pattern/
    └── ReceiptCaptureScreen.tsx ← reference Expo capture screen
```

## Quick start

### 1. Install dependencies

```bash
npm install openai @anthropic-ai/sdk pdfjs-dist pg csv-parse
npm install -D typescript tsx @types/node @types/pg
```

System binaries for scanned-PDF OCR (optional but recommended):

- `pdftoppm` (poppler-utils) — renders PDF pages to images
- `tesseract` (tesseract-ocr) — OCR engine; install language packs you need
  (e.g. `tesseract-ocr-eng`)

On Debian/Ubuntu: `apt install poppler-utils tesseract-ocr`
On Nix: `poppler_utils`, `tesseract`

### 2. Set environment variables

```
OPENAI_API_KEY=...        # receipt vision/text parsing (gpt-4o by default)
ANTHROPIC_API_KEY=...     # merchant enrichment (optional)
DATABASE_URL=postgres://... # for seeding + the Postgres storage adapter
```

Optional: `OPENAI_BASE_URL`, `ANTHROPIC_BASE_URL`, `RECEIPT_MODEL`,
`ENRICHMENT_MODEL`.

### 3. Swap in your taxonomy

Edit `config/categories.ts`. Everything (keyword dictionary validation, AI
prompts, category guards) derives its category names from this one file. For
an employee-expense app you might replace the household groups with e.g.
Travel, Meals & Entertainment, Office Supplies, Software, Lodging, Mileage.

After changing categories, also review:
- `code/categoryGuard.ts` — the alias maps translate legacy/AI-invented
  category names into your taxonomy. Update aliases to point at your new
  category names.
- `code/categoryKeywords.ts` — keyword entries reference category names;
  either update them or call `replaceActiveKeywords()` at startup with your
  own dictionary.

> **Seed data note:** the merchant CSVs use their own category labels (e.g.
> "Medical Services", "Supermarkets & Grocery", "General") that don't all
> match the default taxonomy. Unrecognized labels fall through the alias maps
> in `code/categoryGuard.ts` and degrade to "Other". After swapping in your
> taxonomy, extend those alias maps to cover the seed labels — a quick check
> is to query `SELECT DISTINCT category FROM global_merchant_categories` and
> confirm each value resolves via `resolveCategory()`.

### 4. Create tables and seed merchants

```bash
psql "$DATABASE_URL" -f data/schema.sql
npx tsx data/seedMerchants.ts
```

The seed handles both CSV formats (North America uses pipe-separated
variants; EU uses semicolon-separated) and normalizes them into one table.

### 5. Wire up storage

Implement `MerchantStorage` (see `code/storage.ts`) or use the ready-made
Postgres adapter:

```ts
import { Pool } from "pg";
import { PgMerchantStorage } from "./data/storageAdapter.example";
import { matchMerchant, warmupMerchantIndex } from "./code/merchantMatcher";

const storage = new PgMerchantStorage(new Pool({ connectionString: process.env.DATABASE_URL }));
await warmupMerchantIndex(storage); // optional: pre-build the fuzzy index at boot

const match = await matchMerchant(storage, "TESCO EXPRESS 1234 LONDON", "EU", userId);
// → { merchantName: "Tesco", category: "Groceries", confidence: 0.95, matchMethod: "EXACT_NORMALIZED", ... }
```

For tests or tiny deployments, `InMemoryMerchantStorage` works out of the box.

### 6. Parse receipts

```ts
import { parseReceiptImage, parseReceiptPdf } from "./code/receipt-parsing/receiptParser";

// Photo / scan (base64 JPEG or PNG, raw or data-URL)
const result = await parseReceiptImage(imageBase64, { storage, userId, defaultCurrency: "USD" });

// PDF (Uint8Array); falls back to OCR automatically for scanned PDFs
const result2 = await parseReceiptPdf(new Uint8Array(pdfBuffer), { storage, userId });

// Both return:
// { merchant, normalizedMerchant, date, amount, currency, suggestedCategory,
//   confidence, categoryResolution }
```

`categoryResolution` tells you where the category came from:
`user_mapping` → `database` → `token` → `keyword` → `ai` → `default`.

### 7. Example Express endpoint

```ts
app.post("/api/parse-receipt", async (req, res) => {
  try {
    const { imageBase64, pdfBase64 } = req.body;
    const opts = { storage, userId: req.user?.id, defaultCurrency: "USD" };
    const parsed = pdfBase64
      ? await parseReceiptPdf(new Uint8Array(Buffer.from(pdfBase64, "base64")), opts)
      : await parseReceiptImage(imageBase64, opts);
    res.json(parsed);
  } catch (err: any) {
    res.status(422).json({ error: err.message });
  }
});
```

> **Important:** the reference screen requires `EXPO_PUBLIC_API_URL` to be set
> to your backend's absolute base URL (e.g. `https://api.example.com`). It
> throws a clear error if unset rather than failing on URL construction.

The reference client (`client-pattern/ReceiptCaptureScreen.tsx`) posts to this
exact endpoint shape.

## How the three-tier matcher works

`matchMerchant(storage, rawText, region, userId)` resolves in order:

1. **User mapping** (confidence 1.0) — the user previously corrected this
   merchant; their choice always wins. Populate `merchant_category_mappings`
   whenever a user edits a category ("consensus write-back").
2. **Exact normalized match** against `global_merchant_categories`.
3. **Keyword inference** — multilingual dictionary in `categoryKeywords.ts`;
   run *before* fuzzy matching to guard against false positives.
4. **Token fuzzy matching** — IDF-weighted token containment + Levenshtein +
   bigram overlap over an in-memory index of all merchant name variants.
   Negative guards skip fuzzy matching for short strings, digit-heavy strings,
   bank-transfer markers, and ambiguous scores.
5. **Keyword fallback** if fuzzy matching found nothing.
6. **Unmatched log** — the merchant is recorded in `unmatched_merchants` so a
   periodic job can run AI enrichment.

## AI enrichment loop (optional but powerful)

Periodically classify accumulated unmatched merchants so tier 2 catches them
next time:

```ts
import { enrichUnknownMerchants, insertEnrichedMerchants } from "./code/merchantEnrichment";

const results = await enrichUnknownMerchants(storage, [
  { rawDescription: "FACEBK *MCZ768VPF2", normalizedName: "facebk" },
], "global");
await insertEnrichedMerchants(storage, results, "global");
```

Batch ~30–50 merchants per call. Results are validated against your taxonomy
before insertion — the model can never invent categories.

## Notes & gotchas

- **Index rebuilds**: the fuzzy index is built once per process. Call
  `resetIndex()` from `tokenMatcher.ts` after bulk merchant inserts, then
  `warmupMerchantIndex(storage)` to rebuild.
- **One receipt = one transaction**: the AI prompt intentionally ignores line
  items and extracts only the grand total.
- **Dates**: unparseable dates default to today; check `confidence` and let
  users confirm before saving.
- **OCR quality gate**: `assessOcrQuality()` decides whether the PDF text
  layer is usable (length, garble ratio, date/amount presence). Tune the
  thresholds in `ocrEngine.ts` if your invoices are unusual.
- **Typecheck**: `npx tsc -p . --noEmit` from the kit root (client-pattern
  requires the Expo packages installed; exclude it from `include` if you only
  use the backend pieces).
