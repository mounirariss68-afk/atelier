# MiOS Glassmorphism Kit

A portable description of the frosted-glass ("glassmorphism") system used in MiOS, packaged so it can be applied to **another Tailwind + shadcn/Radix app without changing that app's colors or fonts**.

Everything here is parameterized on the host app's own CSS variables (`--background`, `--card`, `--popover`, and their `*-foreground` / `*-border` companions). The kit adds *translucency, blur, layering, and shadow* — never hues or typefaces.

## The look, in one paragraph

The page body carries a fixed, full-bleed backdrop (a photo or gradient) under a translucent scrim. Everything above it floats as rounded frosted-glass cards: a header card, a nav card, a content card, and an assistant sidebar card, separated by small gaps that let the backdrop shine through. Surfaces are translucent tints of the host app's own card/popover colors, with real `backdrop-filter` blur, hairline light borders, and soft diffuse shadows. Dialogs, sheets, and drawers use the same glass surface over a gently blurred light scrim — never a near-black overlay.

## Files

| File | What it contains |
|---|---|
| `tokens.css` | The glass "knobs" (alpha levels light/dark), alpha-composed surface colors, body backdrop + scrim recipe, soft shadow scale |
| `glass.css` | The `.glass-panel` utility and blur guidance |
| `components.md` | Concrete class-string recipes: dialogs, alert dialogs, sheets, drawers, the stacked shell, composer pill, modal sticky headers |
| `gotchas.md` | Hard-won lessons — read before implementing |
| `prompt.md` | Ready-to-paste instructions for the agent working on your other app |

## How to apply (step by step)

1. **Keep your colors and fonts.** Do not copy any hue, font-family, or brand value from this kit. Your app's existing `--background`, `--card`, `--popover`, `--primary`, fonts, etc. stay exactly as they are.
2. **Add the glass knobs** from `tokens.css` to your `:root` and `.dark` blocks. These are pure alpha (opacity) values.
3. **Re-compose your surface colors with alpha.** In your Tailwind theme (v4 `@theme inline`, or v3 config), make `card`, `popover`, and `sidebar` colors include the knob alpha, e.g. `--color-card: hsl(var(--card) / var(--glass-card-alpha, 1))`. Every existing `bg-card` / `bg-popover` consumer instantly becomes frosted — no per-component sweep needed.
4. **Paint the backdrop on `body`** using the recipe in `tokens.css`, pointing `--app-backdrop` at *your* image (or omit the image and keep only a soft gradient). Layer the light/dark scrims exactly as shown.
5. **Add `.glass-panel`** from `glass.css` and wrap your shell regions (header, nav, main content, sidebar) as separate rounded cards with `gap-2 md:gap-3 p-2 md:p-3` on the page container.
6. **Update overlays and dialog surfaces** per `components.md` — this is what prevents the "grey dialog" and "solid white modal" problems.
7. **Verify** in light and dark mode: backdrop clearly visible between the cards, all text readable. If readability suffers, raise the panel/popover alpha a bit rather than darkening the whole page scrim.

## Compatibility notes

- Built for **Tailwind CSS** (v4 syntax shown; v3 equivalents noted inline) with **shadcn/ui + Radix** components. The concepts (alpha-composed surface tokens, backdrop-filter, light scrims) port to any CSS setup.
- Colors are expressed as `hsl(var(--token) / alpha)`. If your app stores colors in another format (hex, oklch), keep your format and just apply the same alpha levels.
