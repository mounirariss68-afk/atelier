# Ready-to-paste instructions for your other app's agent

Copy everything below the line into the chat of the app where you want this look.

---

I'm attaching a glassmorphism style kit (from another app of mine). Apply this frosted-glass look to this app, with these hard constraints:

1. **Keep this app's existing color scheme and fonts exactly as they are.** Do not import any hue, font, logo, or image from the kit. The kit's recipes are parameterized on my app's own CSS variables (`--background`, `--card`, `--popover`, etc.) — wire them to those.
2. Read `README.md` first for the overview and step order, and `gotchas.md` before touching any CSS — it lists mistakes that are easy to make.
3. Apply in this order:
   - Add the glass alpha knobs from `tokens.css` to `:root` and `.dark`.
   - Re-compose the `card`, `popover`, and `sidebar` colors with those alphas in the Tailwind theme so every `bg-card`/`bg-popover` surface becomes frosted automatically.
   - Paint a fixed backdrop with light/dark scrims on `body` per `tokens.css`. Use an existing brand-appropriate image of THIS app for the backdrop (or a soft gradient if there is none) — ask me if unsure which.
   - Add the `.glass-panel` utility from `glass.css` and restructure the app shell into separate rounded glass cards (header / nav / content / sidebar) with small gaps, per `components.md` section 5.
   - Update all dialogs, alert dialogs, sheets, drawers, and any hand-rolled modals per `components.md` sections 1-4 (light blurred overlay scrim, translucent popover surface, softened shadows). Sweep the codebase for custom `fixed inset-0` overlays so none keep an opaque or near-black style.
4. If text readability suffers anywhere, raise the panel/popover alpha knobs slightly — do not darken the page scrim or make surfaces opaque.
5. Verify visually when done: light and dark mode, desktop and mobile — backdrop clearly visible between/behind the glass cards, all dialogs translucent (not solid, not grey), all text readable.
