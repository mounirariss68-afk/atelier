# Gotchas — read before implementing

Lessons learned the hard way while building this system. Each one cost a debugging round.

## 1. Dark overlays turn glass grey
A translucent panel shows whatever is behind it. If your modal overlay is `bg-black/80`, a 30-40%-alpha white panel over it reads as **dirty grey**, not frosted ivory. Use a light, blurred scrim (`bg-background/40 backdrop-blur-sm`) behind glass modals. Same for heavy shadows: `shadow-xl` at the panel edges reads as grime — prefer a soft `shadow-lg` with low-opacity, high-blur layers.

## 2. Paint the page backdrop on `body`'s own background — not a pseudo-element
A `body::before { z-index: -1 }` layer is painted *behind* body's own background fill, so any opaque background on body hides the image entirely (and dev tooling can mask this until a production build). Put the image + scrim gradient directly in `body { background-image: … }` with `background-attachment: fixed`, keeping `background-color` as the base.

## 3. `backdrop-blur` needs real translucency — and takes no opacity modifier
- `backdrop-filter` shows nothing if the element's background is opaque. Glass = translucent fill **plus** blur.
- Tailwind blur utilities do not accept opacity modifiers: `backdrop-blur-xl/50` silently emits **nothing**. Write `bg-white/50 backdrop-blur-xl`.

## 4. Balancing scrim vs. readability
If the backdrop image is too faint, lower the **scrim** alpha (we use 0.52 light / 0.8 dark). If text then becomes hard to read, do NOT re-darken the scrim — raise the **panel/popover alphas** a bit instead (e.g. card 0.15 → 0.22). The image stays vivid between the cards while content surfaces do the readability work.

## 5. No nested translucent fills
A `bg-card` element inside a `.glass-panel` stacks two translucent fills and goes cloudy/milky. Inner sections of a glass panel stay transparent; only leaf-level chips get their own translucent background.

## 6. Base-path-safe backdrop URL
Never hardcode `url('/backdrop.jpg')` in CSS if your app can be served under a base path. Set it from JS:
`document.body.style.setProperty('--app-backdrop', url('${basePath}/backdrop.jpg'))` and reference `var(--app-backdrop)` in CSS.

## 7. Buttons inside pills: flex, not absolute
An absolutely-positioned send/action button inside an input pill (`absolute top-1/2 -translate-y-1/2`) drifts when class merging or sizing changes. Make the pill a flex container and the button a `shrink-0 self-center` flex child — it cannot misalign.

## 8. (RTL apps only) Radix primitives ignore `html[dir]`
Radix roots (Tabs, DropdownMenu, …) default to LTR regardless of the document direction. If your app supports RTL, pass `dir` explicitly to each Radix root (or wrap the app in Radix `DirectionProvider`), or a whole subtree will silently refuse to mirror.

## 9. Verify with a production build
Dev overlays and HMR styling can mask layering bugs (especially #2). Check the built app at least once in light **and** dark mode.
