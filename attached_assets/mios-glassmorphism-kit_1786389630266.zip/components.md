# Component Recipes

Concrete class-string recipes taken from the working MiOS implementation (shadcn/ui + Radix + Tailwind). Each shows the **key change**; keep the rest of your component's classes (animations, positioning) as-is.

## 1. Dialog & AlertDialog

### Overlay — the single most important fix
Near-black overlays bleed through translucent panels and make glass look **grey**. Use a soft, blurred, light scrim instead:

```diff
- 'fixed inset-0 z-50 bg-black/80 ...'
+ 'fixed inset-0 z-50 bg-background/40 backdrop-blur-sm ...'
```

### Content panel
Translucent popover surface + heavy frost + soft (not harsh) shadow:

```diff
- '... border bg-background p-6 shadow-xl ...'                 // opaque
- '... border bg-popover p-6 shadow-xl backdrop-blur-2xl ...'  // grey-ish
+ '... border border-popover-border bg-popover p-6 shadow-lg backdrop-blur-2xl ... sm:rounded-2xl'
```

(`bg-popover` must be the alpha-composed color from `tokens.css` — that's what makes it glass.)

## 2. Sheet (side panel)

Same surface as dialogs:

```
overlay: 'fixed inset-0 z-50 bg-background/40 backdrop-blur-sm ...'
panel:   '... gap-4 bg-popover backdrop-blur-2xl p-6 shadow-lg ...'
```

## 3. Drawer (bottom sheet)

shadcn's default drawer panel is opaque `bg-background` — replace it:

```diff
- 'fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background'
+ 'fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-2xl border border-popover-border bg-popover backdrop-blur-2xl shadow-lg'
```

## 4. Custom / hand-rolled modals

If a page builds its own modal (not the shared component), give it the **exact same** surface so it doesn't stand out as solid white:

```html
<!-- overlay -->
<div class="fixed inset-0 z-50 flex items-center justify-center bg-background/40 backdrop-blur-sm p-4">
  <!-- panel -->
  <div class="relative w-full max-w-lg rounded-2xl border border-popover-border bg-popover backdrop-blur-2xl shadow-lg max-h-[90vh] overflow-auto">
    <!-- sticky header INSIDE a scrolling modal: same translucent surface + its own blur,
         so scrolled content frosts underneath it instead of clashing -->
    <div class="flex items-center justify-between px-5 py-4 border-b sticky top-0 bg-popover backdrop-blur-xl z-10">…</div>
    <div class="px-5 py-4">…</div>
  </div>
</div>
```

Better still: migrate custom modals to the shared Dialog component so they inherit future changes.

## 5. Stacked glass shell (header / nav / content as separate cards)

The page is a flex column (or row with a sidebar) of **separate** rounded glass cards with small gaps that reveal the body backdrop:

```html
<div class="flex h-[100dvh] w-full overflow-hidden flex-col md:flex-row gap-2 md:gap-3 p-2 md:p-3">
  <aside class="glass-panel rounded-[24px] ...">sidebar</aside>
  <main class="flex-1 flex flex-col min-w-0 gap-2 md:gap-3">
    <header class="glass-panel rounded-[24px] h-16 flex items-center justify-between px-4 sm:px-6 shrink-0 z-10 relative overflow-hidden">…</header>
    <nav class="glass-panel rounded-[24px] shrink-0 z-10 relative">…</nav>
    <div class="glass-panel rounded-[24px] flex-1 min-h-0 overflow-y-auto p-4 sm:p-6 lg:p-8">page content</div>
  </main>
</div>
```

Rules:
- Radius `24px` on shell cards; `--radius: 1rem` for inner elements.
- **Inner strips inside a glass panel stay transparent** — no nested `bg-card`, or translucency doubles up and goes cloudy.
- Small translucent chips inside panels use direct utilities: `bg-white/40 dark:bg-white/5 border border-white/50` (e.g. pill buttons in the header).

## 6. Composer / input pill (chat-style input)

A compact translucent pill whose action button is a **flex child** (never absolutely positioned — it drifts):

```html
<div class="flex-1 min-w-0 flex items-center gap-1.5 min-h-[46px] rounded-[23px] bg-white/60 dark:bg-white/5 border border-white/50 shadow-sm focus-within:ring-2 focus-within:ring-primary/20 ps-4 pe-[6px] py-[6px]">
  <textarea rows="1" class="flex-1 min-w-0 h-5 min-h-[20px] max-h-[100px] leading-5 resize-none rounded-none border-none bg-transparent p-0 shadow-none text-sm outline-none focus:ring-0"></textarea>
  <button class="rounded-full h-8 w-8 shrink-0 self-center bg-gradient-to-br from-primary to-amber-500 text-white shadow-sm border-none">→</button>
</div>
```

(Swap the button gradient for your own primary color — `from-primary` already uses your token.)

## 7. Nav active pill

Active nav items get a translucent white pill with a hairline border and a small accent underline; idle items are text-only with a gentle translucent hover:

```
active pill: 'absolute inset-0 rounded-full bg-white/90 dark:bg-white/10 shadow-sm border border-card-border'
underline:   'absolute start-3 end-3 bottom-[2px] h-[3px] rounded-full bg-primary'
idle hover:  'hover:bg-white/40 dark:hover:bg-white/5'
```
